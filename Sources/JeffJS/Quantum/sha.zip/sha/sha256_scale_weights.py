#!/usr/bin/env python3
"""
Scale the SHA-256 weight matrix extraction from 8 to 16+ bits.
Watch how the structure evolves. Find the pattern.

Uses the Möbius transform (fast ANF extraction) instead of Gaussian elimination.
O(n * 2^n) per output bit vs O(2^3n). Scales to 16-18 bits.

At each scale: real SHA-256 (hashlib), varying the first N bits of the input byte(s).
"""

import hashlib
import numpy as np
from math import comb
import time
import struct

def sha256_of_int(val, n_bytes):
    """SHA-256 of val encoded as n_bytes little-endian bytes."""
    msg = val.to_bytes(n_bytes, 'little')
    return hashlib.sha256(msg).digest()

def mobius_transform(truth_table, n_bits):
    """Fast ANF extraction via Möbius transform.
    Input: truth_table[x] = f(x) for x in 0..2^n-1
    Output: anf[m] = coefficient of monomial m (1 if present, 0 if not)

    Runs in O(n * 2^n) time.
    """
    a = truth_table.copy()
    for i in range(n_bits):
        mask = 1 << i
        for x in range(len(a)):
            if x & mask:
                a[x] ^= a[x ^ mask]
    return a

def mobius_transform_vectorized(truth_table_matrix, n_bits):
    """Vectorized Möbius transform for multiple output bits simultaneously.
    Input: truth_table_matrix[x, b] = output bit b for input x
    Shape: (2^n, n_out_bits)
    """
    a = truth_table_matrix.copy()
    for i in range(n_bits):
        mask = 1 << i
        # For all x with bit i set: a[x] ^= a[x ^ mask]
        idx_with = np.arange(len(a))
        has_bit = (idx_with & mask) != 0
        partner = idx_with ^ mask
        a[has_bit] ^= a[partner[has_bit]]
    return a

def analyze_scale(n_bits, max_out_bits=256):
    """Run full analysis at a given input bit scale."""
    N = 1 << n_bits
    n_bytes = max(1, (n_bits + 7) // 8)

    print(f"\n{'='*70}")
    print(f"SCALE: {n_bits} input bits | {N} inputs | {N} monomials")
    print(f"{'='*70}")

    # Generate all hashes
    t0 = time.time()
    Y = np.zeros((N, max_out_bits), dtype=np.uint8)

    for val in range(N):
        digest = sha256_of_int(val, n_bytes)
        for byte_idx in range(32):
            for bit_idx in range(8):
                ob = byte_idx * 8 + bit_idx
                if ob < max_out_bits:
                    Y[val, ob] = (digest[byte_idx] >> bit_idx) & 1

    t_hash = time.time() - t0
    print(f"Hashing: {t_hash:.2f}s ({N/t_hash:.0f} hashes/sec)")

    # Extract ANF via Möbius transform
    t0 = time.time()
    W = mobius_transform_vectorized(Y, n_bits)
    t_anf = time.time() - t0
    print(f"ANF extraction: {t_anf:.2f}s")

    # Verify: reconstruct hashes from ANF
    # For a subset (first 100 and last 100)
    t0 = time.time()
    check_indices = list(range(min(100, N))) + list(range(max(0, N-100), N))
    n_verified = 0
    for val in check_indices:
        # Evaluate polynomial: for each monomial m, compute product of input bits
        # f(x) = XOR of W[m] for all m that are subsets of x
        # This is the inverse Möbius: f(x) = XOR_{m subset x} W[m]
        # Which is just: reapply Möbius transform to W
        pass  # Skip per-sample verify, do matrix verify below

    # Matrix verify: Y_reconstructed = mobius_transform(W) should give back Y
    Y_check = mobius_transform_vectorized(W, n_bits)
    match = np.array_equal(Y_check, Y)
    t_verify = time.time() - t0
    print(f"Verification: {'✓ EXACT MATCH' if match else '✗ MISMATCH'} ({t_verify:.2f}s)")

    if not match:
        n_wrong = np.sum(Y_check != Y)
        print(f"  {n_wrong} bits wrong out of {Y.size}")
        return None

    # ============ ANALYSIS ============

    total_terms = int(np.sum(W))
    total_possible = N * max_out_bits
    density = total_terms / total_possible

    print(f"\nWeight matrix: {W.shape}")
    print(f"Nonzero terms: {total_terms:,} / {total_possible:,} ({density*100:.1f}%)")
    print(f"Avg terms/output bit: {total_terms/max_out_bits:.1f}")

    # Degree distribution
    # Monomial index m has degree = popcount(m)
    degrees = {}
    terms_per_degree = np.zeros(n_bits + 1, dtype=np.int64)

    for m in range(N):
        deg = bin(m).count('1')
        count = int(np.sum(W[m, :]))  # how many output bits use this monomial
        if count > 0:
            terms_per_degree[deg] += count

    print(f"\nDegree distribution:")
    max_bar = 40
    max_count = max(terms_per_degree) if max(terms_per_degree) > 0 else 1
    for d in range(n_bits + 1):
        count = terms_per_degree[d]
        if count > 0 or d <= 2 or d >= n_bits - 1:
            pct = count / total_terms * 100 if total_terms > 0 else 0
            bar_len = int(count / max_count * max_bar)
            bar = "█" * bar_len
            n_possible_at_deg = int(comb(n_bits, d)) * max_out_bits
            fill_pct = count / n_possible_at_deg * 100 if n_possible_at_deg > 0 else 0
            print(f"  deg {d:2d}: {count:8,} terms ({pct:5.1f}%) "
                  f"[{count}/{n_possible_at_deg} = {fill_pct:.1f}% fill] {bar}")

    # Effective degree: highest degree with any terms
    eff_degree = 0
    for d in range(n_bits, -1, -1):
        if terms_per_degree[d] > 0:
            eff_degree = d
            break
    print(f"\nEffective degree: {eff_degree}")
    print(f"Degree-{eff_degree} terms: {terms_per_degree[eff_degree]:,} "
          f"(out of {int(comb(n_bits, eff_degree)) * max_out_bits:,} possible)")

    # Per-output-bit statistics
    terms_per_bit = np.sum(W, axis=0)
    print(f"\nTerms per output bit:")
    print(f"  Min: {int(np.min(terms_per_bit))}")
    print(f"  Max: {int(np.max(terms_per_bit))}")
    print(f"  Mean: {np.mean(terms_per_bit):.1f}")
    print(f"  Std: {np.std(terms_per_bit):.1f}")

    # Monomial popularity: how many output bits use each monomial
    mono_popularity = np.sum(W, axis=1)
    print(f"\nMonomial popularity (how many output bits use each):")
    print(f"  Min: {int(np.min(mono_popularity))}")
    print(f"  Max: {int(np.max(mono_popularity))}")
    print(f"  Mean: {np.mean(mono_popularity):.1f}")
    print(f"  Unused monomials: {int(np.sum(mono_popularity == 0))}/{N}")

    # Correlation between output bits (Hamming distance of weight vectors)
    if max_out_bits <= 256:
        # Pairwise XOR weight vectors, count differences
        W_t = W.T  # (out_bits, N)
        dists = []
        for i in range(0, min(32, max_out_bits)):
            for j in range(i+1, min(32, max_out_bits)):
                d = np.sum(W_t[i] != W_t[j])
                dists.append(d)
        if dists:
            print(f"\nWeight vector Hamming distances (first 32 bits):")
            print(f"  Min: {min(dists)}, Max: {max(dists)}, Mean: {np.mean(dists):.0f}")
            print(f"  Expected if random: {N/2:.0f}")

    return {
        'n_bits': n_bits,
        'total_terms': total_terms,
        'density': density,
        'eff_degree': eff_degree,
        'degree_dist': terms_per_degree.tolist(),
        'terms_per_bit_mean': float(np.mean(terms_per_bit)),
        'terms_per_bit_std': float(np.std(terms_per_bit)),
    }

def main():
    results = []

    # Scale from 8 to 16 bits
    for n_bits in [8, 10, 12, 14, 16]:
        N = 1 << n_bits
        mem_mb = N * 256 / 1e6  # approximate memory for Y matrix
        print(f"\n>>> Starting {n_bits}-bit analysis (N={N:,}, ~{mem_mb:.0f}MB)...")

        if mem_mb > 2000:
            print(f"    Skipping — would use ~{mem_mb:.0f}MB")
            continue

        try:
            r = analyze_scale(n_bits)
            if r:
                results.append(r)
        except MemoryError:
            print(f"    Out of memory at {n_bits} bits")
            break
        except Exception as e:
            print(f"    Error: {e}")
            break

    # ============ CROSS-SCALE COMPARISON ============
    if len(results) >= 2:
        print(f"\n{'='*70}")
        print(f"CROSS-SCALE COMPARISON")
        print(f"{'='*70}")

        print(f"\n{'Bits':>4} | {'Inputs':>8} | {'Total Terms':>12} | {'Density':>8} | "
              f"{'Eff Deg':>7} | {'Terms/Bit':>10} | {'Std':>6}")
        print("-" * 75)
        for r in results:
            print(f"{r['n_bits']:4d} | {1<<r['n_bits']:8,} | {r['total_terms']:12,} | "
                  f"{r['density']*100:7.1f}% | {r['eff_degree']:7d} | "
                  f"{r['terms_per_bit_mean']:10.1f} | {r['terms_per_bit_std']:6.1f}")

        print(f"\nDegree distribution evolution:")
        max_deg = max(r['n_bits'] for r in results)
        header = f"{'Deg':>3} |"
        for r in results:
            header += f" {r['n_bits']:>8}b |"
        print(header)
        print("-" * len(header))

        for d in range(max_deg + 1):
            row = f"{d:3d} |"
            for r in results:
                if d < len(r['degree_dist']):
                    count = r['degree_dist'][d]
                    total = r['total_terms']
                    pct = count / total * 100 if total > 0 else 0
                    row += f" {pct:7.1f}% |"
                else:
                    row += f"       - |"
            print(row)

        # Key question: is degree growing linearly with input bits,
        # or does it saturate?
        print(f"\nDegree saturation check:")
        for r in results:
            # Find degree where cumulative % reaches 99%
            cumsum = 0
            total = r['total_terms']
            d99 = r['n_bits']
            for d in range(len(r['degree_dist'])):
                cumsum += r['degree_dist'][d]
                if cumsum >= 0.99 * total:
                    d99 = d
                    break
            print(f"  {r['n_bits']:2d} bits: eff_deg={r['eff_degree']}, "
                  f"99% of terms at deg≤{d99}, "
                  f"ratio={r['eff_degree']/r['n_bits']:.2f}")

if __name__ == "__main__":
    main()
