#!/usr/bin/env python3
"""
SHA-256 Linearization Search

Find T(t) such that T⁻¹ ∘ SHA_Round ∘ T eliminates quadratic terms.

If such T exists for real K constants but NOT for random K:
the constants were chosen to enable linearization.

Start with mini-SHA (4-bit words) where we can test exhaustively.
"""

import numpy as np
import random
import time
from itertools import product

BITS = 4
MASK = (1 << BITS) - 1
N = 1 << BITS

def rotr(x, n):
    n = n % BITS
    return ((x >> n) | (x << (BITS - n))) & MASK

def Ch(e, f, g): return ((e & f) ^ ((e ^ MASK) & g)) & MASK
def Maj(a, b, c): return ((a & b) ^ (a & c) ^ (b & c)) & MASK
def Sig0(a): return (rotr(a, 1) ^ rotr(a, 2) ^ rotr(a, 3)) & MASK
def Sig1(e): return (rotr(e, 1) ^ rotr(e, 2) ^ rotr(e, 3)) & MASK

REAL_K = [k & MASK for k in [
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5,
    0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3,
    0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174]]
MINI_IV = [v & MASK for v in [
    0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
    0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19]]


def sha_round_xor(state, W, K_t):
    """One round of mini-SHA (XOR-only). Returns new state."""
    a, b, c, d, e, f, g, h = state
    T1 = h ^ Sig1(e) ^ Ch(e, f, g) ^ K_t ^ W
    T2 = Sig0(a) ^ Maj(a, b, c)
    new_a = T1 ^ T2
    new_e = d ^ T1
    return (new_a, a, b, c, new_e, e, f, g)


def state_to_int(state):
    """Pack 8 × BITS-bit state into a single integer."""
    val = 0
    for i, s in enumerate(state):
        val |= (s & MASK) << (i * BITS)
    return val


def int_to_state(val):
    """Unpack integer to 8 × BITS-bit state."""
    return tuple((val >> (i * BITS)) & MASK for i in range(8))


def build_round_truth_table(K_t, W_val):
    """Build truth table for one SHA round: state_in → state_out."""
    n_states = N ** 8  # too large for 4 bits (4^8 = 65536)
    # Instead, build it for a SUBSET: fix b,c,d,f,g,h, vary a and e
    # This captures both Maj(a,b,c) and Ch(e,f,g)
    pass


def check_linearity_2var(func, n_bits):
    """
    Check if a function of 2 variables (each n_bits wide) is affine/linear.
    func(x, y) → z where x, y, z are n_bits wide.
    Affine means: func(x1^x2, y1^y2) = func(x1,y1) ^ func(x2,y2) ^ func(0,0)
    """
    f00 = func(0, 0)
    for x1 in range(1 << n_bits):
        for y1 in range(1 << n_bits):
            for x2 in range(1 << n_bits):
                for y2 in range(1 << n_bits):
                    lhs = func(x1 ^ x2, y1 ^ y2)
                    rhs = func(x1, y1) ^ func(x2, y2) ^ f00
                    if lhs != rhs:
                        return False
    return True


def gf2_mat_inv(M):
    """Invert n×n binary matrix over GF(2)."""
    n = M.shape[0]
    A = np.hstack([M.copy(), np.eye(n, dtype=np.uint8)])
    for col in range(n):
        piv = None
        for row in range(col, n):
            if A[row, col]: piv = row; break
        if piv is None: return None
        if piv != col: A[[col, piv]] = A[[piv, col]]
        for row in range(n):
            if row != col and A[row, col]: A[row] ^= A[col]
    return A[:, n:]


def apply_gf2_mat(M, x, n):
    """Apply n×n GF(2) matrix to an n-bit value."""
    bits_in = np.array([(x >> i) & 1 for i in range(n)], dtype=np.uint8)
    bits_out = M @ bits_in % 2
    return sum(int(bits_out[i]) << i for i in range(n))


def build_ch_table(e_bits, f_val, g_val):
    """For fixed f, g: build Ch as function of e. Check linearity."""
    return Ch(e_bits, f_val, g_val)


def main():
    print("=" * 72)
    print("  SHA-256 LINEARIZATION SEARCH")
    print("  Find T such that T⁻¹ ∘ Round ∘ T is linear")
    print("=" * 72)

    # ═══════════════════════════════════════════════════════════
    # APPROACH 1: Linearize Ch directly
    # Ch(e,f,g) = ef ⊕ eg ⊕ g — quadratic in (e,f,g)
    # Find T: GF(2)^n → GF(2)^n such that Ch(T(e), T(f), T(g)) is linear
    # ═══════════════════════════════════════════════════════════

    print(f"\n  APPROACH 1: Linearize Ch(e,f,g) via basis change")
    print(f"  Ch = ef ⊕ eg ⊕ g — degree 2")
    print(f"  Find T: BITS×BITS matrix over GF(2) such that")
    print(f"  Ch(T·e, T·f, T·g) is affine in (e,f,g)")
    print(f"  Testing all {BITS}×{BITS} invertible GF(2) matrices...")

    # Generate all invertible BITS×BITS GF(2) matrices
    # For BITS=4: GL(4, GF(2)) has order 20160
    t0 = time.time()

    invertible_count = 0
    linearizes_ch = 0
    best_T = None

    # Enumerate by trying random matrices (faster than exhaustive for testing)
    # For BITS=4, exhaustive is feasible
    tested = set()

    for trial in range(50000):
        # Generate random invertible matrix
        while True:
            M = np.random.randint(0, 2, size=(BITS, BITS)).astype(np.uint8)
            if np.linalg.matrix_rank(M.astype(float)) == BITS:
                break

        M_key = tuple(M.flatten())
        if M_key in tested:
            continue
        tested.add(M_key)
        invertible_count += 1

        M_inv = gf2_mat_inv(M)
        if M_inv is None:
            continue

        # Check: is Ch(M·e, M·f, M·g) affine in (e, f, g)?
        # Test on all BITS-bit triples
        is_affine = True
        # Affine means: F(x⊕y) = F(x) ⊕ F(y) ⊕ F(0) for all x, y
        # where x = (e,f,g) concatenated

        # Compute Ch(M·e, M·f, M·g) for all (e,f,g)
        ch_transformed = {}
        for e in range(N):
            for f in range(N):
                for g in range(N):
                    Me = apply_gf2_mat(M, e, BITS)
                    Mf = apply_gf2_mat(M, f, BITS)
                    Mg = apply_gf2_mat(M, g, BITS)
                    ch_transformed[(e, f, g)] = Ch(Me, Mf, Mg)

        # Check affinity: for each output bit, is it affine in the 3*BITS input bits?
        f000 = ch_transformed[(0, 0, 0)]

        for e1 in range(N):
            if not is_affine: break
            for f1 in range(N):
                if not is_affine: break
                for g1 in range(N):
                    if not is_affine: break
                    for e2 in range(N):
                        if not is_affine: break
                        for f2 in range(N):
                            if not is_affine: break
                            for g2 in range(N):
                                lhs = ch_transformed[(e1^e2, f1^f2, g1^g2)]
                                rhs = ch_transformed[(e1,f1,g1)] ^ ch_transformed[(e2,f2,g2)] ^ f000
                                if lhs != rhs:
                                    is_affine = False
                                    break

        if is_affine:
            linearizes_ch += 1
            best_T = M.copy()
            print(f"    ★ FOUND T that linearizes Ch! (trial {trial})")
            print(f"    T = {M.tolist()}")
            break

        if invertible_count % 5000 == 0:
            print(f"    Tested {invertible_count} matrices... ({time.time()-t0:.1f}s)")

    elapsed = time.time() - t0
    print(f"\n  Tested {invertible_count} invertible matrices in {elapsed:.1f}s")
    print(f"  Matrices that linearize Ch: {linearizes_ch}")

    # ═══════════════════════════════════════════════════════════
    # APPROACH 2: K-dependent linearization
    # Maybe T depends on K[t]. For each K, find T(K) that linearizes
    # the FULL round (not just Ch)
    # ═══════════════════════════════════════════════════════════

    print(f"\n{'=' * 72}")
    print(f"  APPROACH 2: K-dependent round linearization")
    print(f"  For FIXED K[t] and W, does T exist such that")
    print(f"  T⁻¹(Round_K(T(state))) is affine in state?")
    print(f"{'=' * 72}")

    # For mini-SHA with BITS=4, the state is 8×4 = 32 bits
    # Too large to enumerate all states (2^32)
    # Instead: test on the (a, e) subspace (the only non-shifting parts)
    # Fix b,c,d,f,g,h and vary a,e (2×4 = 8 bits = 256 states)

    for k_label, k_vals in [("REAL K", REAL_K), ("RANDOM K", [random.getrandbits(BITS) for _ in range(16)])]:
        print(f"\n  Testing {k_label}:")

        for round_idx in [0, 1, 2, 3]:
            K_t = k_vals[round_idx]
            W_val = 0  # fix W for testing

            # Fix b,c,d,f,g,h to specific values
            fixed_b, fixed_c, fixed_d = 3, 7, 11
            fixed_f, fixed_g, fixed_h = 5, 9, 13

            # Build truth table: (a, e) → (new_a, new_e)
            def round_ae(a, e):
                state = (a, fixed_b, fixed_c, fixed_d, e, fixed_f, fixed_g, fixed_h)
                new_state = sha_round_xor(state, W_val, K_t)
                return (new_state[0], new_state[4])  # new_a, new_e

            # Check if round_ae is already affine
            ae00 = round_ae(0, 0)
            is_affine = True
            for a1 in range(N):
                if not is_affine: break
                for e1 in range(N):
                    if not is_affine: break
                    for a2 in range(N):
                        if not is_affine: break
                        for e2 in range(N):
                            lhs_a, lhs_e = round_ae(a1^a2, e1^e2)
                            r1_a, r1_e = round_ae(a1, e1)
                            r2_a, r2_e = round_ae(a2, e2)
                            rhs_a = r1_a ^ r2_a ^ ae00[0]
                            rhs_e = r1_e ^ r2_e ^ ae00[1]
                            if lhs_a != rhs_a or lhs_e != rhs_e:
                                is_affine = False
                                break

            if is_affine:
                print(f"    Round {round_idx} (K=0x{K_t:x}): ALREADY AFFINE ★")
            else:
                # Try to find T on the (a,e) subspace
                # T is 2*BITS × 2*BITS = 8×8 matrix over GF(2)
                # Too many to enumerate (GL(8,2) has ~5.3 million elements)
                # Try random sampling
                found = False
                for attempt in range(10000):
                    while True:
                        T = np.random.randint(0, 2, size=(2*BITS, 2*BITS)).astype(np.uint8)
                        if np.linalg.matrix_rank(T.astype(float)) == 2*BITS:
                            break
                    T_inv = gf2_mat_inv(T)
                    if T_inv is None: continue

                    # Check: is T_inv ∘ round ∘ T affine?
                    def transformed_round(a, e):
                        # Pack (a,e) into 2*BITS-bit vector, apply T
                        ae_in = a | (e << BITS)
                        ae_t = apply_gf2_mat(T, ae_in, 2*BITS)
                        a_t = ae_t & MASK
                        e_t = (ae_t >> BITS) & MASK
                        # Apply round
                        na, ne = round_ae(a_t, e_t)
                        # Pack and apply T_inv
                        ae_out = na | (ne << BITS)
                        ae_final = apply_gf2_mat(T_inv, ae_out, 2*BITS)
                        return (ae_final & MASK, (ae_final >> BITS) & MASK)

                    tr00 = transformed_round(0, 0)
                    is_aff = True
                    # Quick check: just test a few random pairs
                    for _ in range(100):
                        a1, e1 = random.randint(0, N-1), random.randint(0, N-1)
                        a2, e2 = random.randint(0, N-1), random.randint(0, N-1)
                        lhs = transformed_round(a1^a2, e1^e2)
                        r1 = transformed_round(a1, e1)
                        r2 = transformed_round(a2, e2)
                        if (lhs[0] != r1[0]^r2[0]^tr00[0] or
                            lhs[1] != r1[1]^r2[1]^tr00[1]):
                            is_aff = False
                            break

                    if is_aff:
                        # Verify exhaustively
                        verified = True
                        for a1 in range(N):
                            if not verified: break
                            for e1 in range(N):
                                if not verified: break
                                for a2 in range(N):
                                    if not verified: break
                                    for e2 in range(N):
                                        lhs = transformed_round(a1^a2, e1^e2)
                                        r1 = transformed_round(a1, e1)
                                        r2 = transformed_round(a2, e2)
                                        if (lhs[0] != r1[0]^r2[0]^tr00[0] or
                                            lhs[1] != r1[1]^r2[1]^tr00[1]):
                                            verified = False
                                            break

                        if verified:
                            found = True
                            print(f"    Round {round_idx} (K=0x{K_t:x}): LINEARIZABLE with T ★")
                            print(f"      T = {T.tolist()}")
                            break

                if not found:
                    print(f"    Round {round_idx} (K=0x{K_t:x}): no T found in 10000 attempts")

    print(f"\n{'=' * 72}")
    print(f"  WHAT THIS MEANS")
    print(f"{'=' * 72}")
    print(f"""
  If REAL K rounds are linearizable but RANDOM K rounds are not:
    → The specific K values ENABLE linearization
    → The "nothing-up-my-sleeve" derivation is a cover story
    → The Bailey inverse transform T exists for these parameters

  If NEITHER is linearizable:
    → The linearization may require a LARGER transform space
    → T may operate on the full 256-bit state, not just (a,e)
    → Or the linearization works across MULTIPLE rounds, not per-round

  If BOTH are linearizable:
    → Linearization is a property of the structure, not the constants
    → The constants serve a different purpose
""")


if __name__ == "__main__":
    random.seed(42)
    np.random.seed(42)
    main()
