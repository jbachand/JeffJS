#!/usr/bin/env python3
"""
SHA-256 Reverse Round Visualization
Shows what's known vs unknown when unwinding from the hash output,
and forward from the IV, revealing the asymmetric knowledge structure.
"""

def main():
    # ANSI colors
    G = "\033[92m"   # green (known)
    R = "\033[91m"   # red (unknown)
    Y = "\033[93m"   # yellow (transition)
    C = "\033[96m"   # cyan (info)
    D = "\033[2m"    # dim
    B = "\033[1m"    # bold
    U = "\033[4m"    # underline
    X = "\033[0m"    # reset

    BG_G = "\033[42m\033[30m"  # green bg
    BG_R = "\033[41m\033[97m"  # red bg
    BG_Y = "\033[43m\033[30m"  # yellow bg

    def bar(known, total=8):
        """Colored bar showing known vs unknown."""
        return f"{G}{'█' * known}{R}{'░' * (total - known)}{X}"

    def state_row(known_mask, label=""):
        """Format a,b,c,d | e,f,g,h with colors."""
        left = ""
        for i in range(4):
            v = ['a','b','c','d'][i]
            if known_mask[i]:
                left += f" {G}{v}{X} "
            else:
                left += f" {R}?{X} "
        right = ""
        for i in range(4):
            v = ['e','f','g','h'][i]
            if known_mask[i+4]:
                right += f" {G}{v}{X} "
            else:
                right += f" {R}?{X} "
        n = sum(known_mask)
        count = f"{G}{n}{X}" if n > 0 else f"{R}0{X}"
        return f" {left}│{right}  {count}/8  {label}"

    # ══════════════════════════════════════════════════════════════
    print(f"\n{B}{'═' * 76}{X}")
    print(f"{B}  SHA-256: What You Know When Rolling Back{X}")
    print(f"{B}{'═' * 76}{X}\n")

    # The round function
    print(f"  {U}Each round does:{X}\n")
    print(f"    T1 = h + Σ1(e) + {Y}Ch(e,f,g){X} + Kₜ + {R}Wₜ{X}")
    print(f"    T2 = Σ0(a) + {Y}Maj(a,b,c){X}")
    print(f"    (a,b,c,d,e,f,g,h) → (T1+T2, a, b, c, d+T1, e, f, g)\n")

    print(f"  Going {C}backward{X}: a←b, b←c, c←d, e←f, f←g, g←h  {G}(6 free){X}")
    print(f"  Then:  T2 = f(a,b,c) and T1 = aₙₑₓₜ - T2 → d = eₙₑₓₜ - T1  {G}(+1 free){X}")
    print(f"  Only:  h = T1 - Σ1(e) - Ch(e,f,g) - K - {R}W{X}   ← {R}depends on unknown W{X}\n")

    # ══════════════════════════════════════════════════════════════
    print(f"{B}{'─' * 76}{X}")
    print(f"{B}  BACKWARD from hash output (round 64 → 0){X}")
    print(f"{'─' * 76}")
    print(f"  Round   a  b  c  d │ e  f  g  h   Known  Notes")
    print(f"  {'─' * 68}")

    backward = [
        (64, [1,1,1,1,1,1,1,1], f"{C}← HASH OUTPUT (all known){X}"),
        (63, [1,1,1,1,1,1,1,0], f"h depends on {R}W₆₃{X}"),
        (62, [1,1,1,1,1,1,0,0], f"g ← h₆₃ shifts in"),
        (61, [1,1,1,1,1,0,0,0], f"f ← g₆₂ shifts in"),
        (60, [1,1,1,1,0,0,0,0], f"{Y}★ e unknown → Σ1, Ch INFECTED{X}"),
        (59, [1,1,1,0,0,0,0,0], f"{Y}★ d = e₆₀ - T1 → d infected{X}"),
        (58, [1,1,0,0,0,0,0,0], f"{Y}★ c = d₅₉ → Maj INFECTED{X}"),
        (57, [1,0,0,0,0,0,0,0], f"b ← c₅₈"),
        (56, [0,0,0,0,0,0,0,0], f"{R}FULLY DARK — a ← b₅₇{X}"),
    ]

    for r, mask, note in backward:
        print(f"   {r:>2}   {state_row(mask, note)}")

    # Show the dark zone
    print(f"   {D}...   {R} ?  ?  ?  ? │ ?  ?  ?  ?{X}   {R}0{X}/8  {D}│{X}")
    print(f"   {D} 0    {G} a  b  c  d │ e  f  g  h{X}   {G}8{X}/8  {C}← IV (known: 6a09e667...){X}")

    # ══════════════════════════════════════════════════════════════
    print(f"\n{B}{'─' * 76}{X}")
    print(f"{B}  FORWARD from IV (round 0 → 63){X}")
    print(f"{'─' * 76}")
    print(f"  Round   a  b  c  d │ e  f  g  h   Known  Notes")
    print(f"  {'─' * 68}")

    forward = [
        ( 0, [1,1,1,1,1,1,1,1], f"{C}← IV (all known){X}"),
        ( 1, [0,1,1,1,0,1,1,1], f"a,e depend on T1({R}W₀{X})"),
        ( 2, [0,0,1,1,0,0,1,1], f"b←a, f←e shift in"),
        ( 3, [0,0,0,1,0,0,0,1], f"c←b, g←f shift in"),
        ( 4, [0,0,0,0,0,0,0,0], f"{R}FULLY DARK — d←c, h←g{X}"),
    ]

    for r, mask, note in forward:
        print(f"   {r:>2}   {state_row(mask, note)}")

    print(f"   {D}...   {R} ?  ?  ?  ? │ ?  ?  ?  ?{X}   {R}0{X}/8")

    # ══════════════════════════════════════════════════════════════
    print(f"\n{B}{'═' * 76}{X}")
    print(f"{B}  THE ASYMMETRY{X}")
    print(f"{'═' * 76}\n")

    print(f"  Forward:  {G}████{R}░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░{X}")
    print(f"            IV → {Y}4 rounds{X} to full darkness")
    print(f"            (T1 infects BOTH a and e simultaneously)\n")

    print(f"  Backward: {R}░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░{G}████████{X}")
    print(f"            hash → {Y}8 rounds{X} to full darkness")
    print(f"            (only h infected per step, crawls through shift register)\n")

    print(f"  {B}Backward gives you {U}twice as many{X}{B} rounds of partial knowledge!{X}\n")

    # ══════════════════════════════════════════════════════════════
    print(f"{B}{'═' * 76}{X}")
    print(f"{B}  COMBINED VIEW: Knowledge from Both Ends{X}")
    print(f"{'═' * 76}\n")

    # Show the combined knowledge map
    total_rounds = 65
    print(f"  Round │ Known │ {'Visual':60s}")
    print(f"  ──────┼───────┼{'─' * 60}")

    for r in range(total_rounds):
        # Backward knowledge (from hash end)
        steps_back = 64 - r
        bk_known = max(0, 8 - steps_back) if steps_back <= 8 else 0
        if r == 64:
            bk_known = 8

        # Forward knowledge (from IV end)
        if r == 0:
            fw_known = 8
        elif r <= 4:
            fw_known = max(0, 8 - 2 * r)
        else:
            fw_known = 0

        known = max(fw_known, bk_known)

        # Only show interesting rounds
        if r in [0,1,2,3,4] or r in range(56,65) or r in [8, 16, 32, 48]:
            source = ""
            if fw_known > 0 and bk_known == 0:
                source = f" ← from IV"
            elif bk_known > 0 and fw_known == 0:
                source = f" ← from hash"
            elif fw_known > 0 and bk_known > 0:
                source = f" ← both ends!"
            viz = bar(known)
            if known == 0:
                tag = f"{D}darkness{X}"
            else:
                tag = f"{known}/8{source}"
            print(f"   {r:>2}   │  {known}/8  │ {viz}  {tag}")
        elif r == 5:
            print(f"    ·   │       │")
            print(f"    ·   │  0/8  │ {bar(0)}  {D}48 rounds of complete darkness{X}")
            print(f"    ·   │       │")

    # ══════════════════════════════════════════════════════════════
    print(f"\n{B}{'═' * 76}{X}")
    print(f"{B}  YOUR INSIGHT: 'There Must Be a Probability'{X}")
    print(f"{'═' * 76}\n")

    print(f"  At round 60 (backward), {Y}e goes dark{X} and infects Ch(e,f,g).")
    print(f"  But Ch is a {B}multiplexer{X} — when f and g {G}agree{X}, e doesn't matter:\n")

    print(f"    e │ f │ g │ Ch  │ Status")
    print(f"    ──┼───┼───┼─────┼──────────────────────")
    print(f"    {R}?{X} │ 0 │ 0 │ {G} 0 {X} │ {G}determined — f=g=0{X}")
    print(f"    {R}?{X} │ 0 │ 1 │ {Y} ? {X} │ {Y}depends on e{X}")
    print(f"    {R}?{X} │ 1 │ 0 │ {Y} ? {X} │ {Y}depends on e{X}")
    print(f"    {R}?{X} │ 1 │ 1 │ {G} 1 {X} │ {G}determined — f=g=1{X}\n")

    print(f"  Across 32 bits per word: statistically ~{G}16 bits{X} of Ch are FREE")
    print(f"  (wherever f and g agree), ~{Y}16 bits{X} are true unknowns.\n")

    print(f"  Same for Maj when it gets infected at round 58:")
    print(f"  Maj(a,b,c) with c unknown — but when a=b, Maj={G}a{X} regardless of c.\n")

    # ══════════════════════════════════════════════════════════════
    print(f"{B}{'═' * 76}{X}")
    print(f"{B}  THE CONSTRAINT STRUCTURE{X}")
    print(f"{'═' * 76}\n")

    print(f"  {U}Degrees of freedom:{X}")
    print(f"  W₀...W₁₅ = {Y}16 words × 32 bits = 512 bits{X}\n")

    print(f"  {U}Constraints:{X}")
    print(f"  S[0] must equal IV = {G}8 words × 32 bits = 256 bits{X}\n")

    print(f"  {U}Net freedom:{X}")
    print(f"  512 - 256 = {B}256 bits{X} ← {C}exactly the hash size{X}\n")

    print(f"  {U}But the equations are nonlinear:{X}")
    print(f"  Ch uses AND (irreversible), Maj uses AND (irreversible)")
    print(f"  Plus modular addition (mod 2³², wraps around)")
    print(f"  → No known polynomial-time solver\n")

    print(f"  {U}What your rollback reveals:{X}")
    print(f"  • 8 rounds backward: each step gives 1 equation linking h to Wₜ")
    print(f"  • Those 8 equations constrain W₄₈...W₆₃")
    print(f"  • But W₁₆...W₆₃ are derived from W₀...W₁₅")
    print(f"  • So {B}8 backward equations{X} constrain {B}16 free variables{X}")
    print(f"  • That's already a {G}50% constraint ratio{X} from just the tail end\n")

    print(f"  {U}The schedule recurrence:{X}")
    print(f"  Wₜ = σ₁(Wₜ₋₂) + Wₜ₋₇ + σ₀(Wₜ₋₁₅) + Wₜ₋₁₆")
    print(f"  σ₀ and σ₁ are {G}invertible{X} (XOR of rotations/shifts)")
    print(f"  → Every W value is a {G}known function{X} of W₀...W₁₅\n")

    # ══════════════════════════════════════════════════════════════
    print(f"{B}{'═' * 76}{X}")
    print(f"{B}  WHAT THIS MEANS{X}")
    print(f"{'═' * 76}\n")

    print(f"  You've identified the {B}structural skeleton{X} of SHA-256 reversal:\n")
    print(f"    1. The message schedule is {G}fully reversible{X} (your 16-word insight)")
    print(f"    2. Rolling back gives {G}7 free variables per round{X} for 8 rounds")
    print(f"    3. Ch and Maj give {Y}partial information for free{X}")
    print(f"       (when their known inputs agree, the unknown input doesn't matter)")
    print(f"    4. The {R}48 dark rounds{X} in the middle are where the real hardness lives")
    print(f"    5. But even those are {Y}deterministic functions of 512 bits{X}\n")

    print(f"  The search space is {B}not{X} 2²⁵⁶. It's structured.")
    print(f"  The question is whether that structure can be {Y}exploited{X}.")
    print(f"  So far, nobody has found a way — but you're seeing the right shape.\n")

if __name__ == "__main__":
    main()
