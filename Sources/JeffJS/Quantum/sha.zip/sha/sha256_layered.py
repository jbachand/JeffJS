#!/usr/bin/env python3
"""
SHA-256 Layered: Build and invert one layer at a time.

Layer 1: LINEAR — XOR everything (no Ch/Maj, no carries)
  Forward: apply Σ, σ, XOR with K/IV/W, shift register
  Inverse: just reverse the XOR operations (self-inverse)

Layer 2: QUADRATIC — add Ch/Maj but keep XOR additions
  Forward: Layer 1 + Ch(e,f,g) and Maj(a,b,c)
  Inverse: peel quadratic, then invert linear

Layer 3: CARRY — add mod-2^32 carries
  Forward: full SHA-256
  Inverse: peel carry, then invert quadratic, then invert linear

Each layer's inverter is independent and composable.
"""

import struct, hashlib
import numpy as np

M32 = 0xFFFFFFFF

def rotr(x,n): return ((x>>n)|(x<<(32-n)))&M32
def shr(x,n): return x>>n
def Sigma1(x): return rotr(x,6)^rotr(x,11)^rotr(x,25)
def Sigma0(x): return rotr(x,2)^rotr(x,13)^rotr(x,22)
def sigma1(x): return rotr(x,17)^rotr(x,19)^shr(x,10)
def sigma0(x): return rotr(x,7)^rotr(x,18)^shr(x,3)
def Ch(e,f,g): return (e&f)^((~e)&g)&M32
def Maj(a,b,c): return (a&b)^(a&c)^(b&c)

K=[0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
   0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
   0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
   0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
   0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
   0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
   0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
   0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2]
IV=[0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,
    0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19]

def make_schedule(msg_byte):
    padded = bytes([msg_byte]) + b'\x80' + b'\x00'*54 + struct.pack('>Q', 8)
    return list(struct.unpack('>16I', padded))

# ============================================================
# LAYER 1: LINEAR (XOR only, no Ch/Maj, no carries)
# ============================================================

class LinearLayer:
    """SHA-256 with ALL nonlinearity removed.
    Ch(e,f,g) → e⊕f⊕g, Maj(a,b,c) → a⊕b⊕c, additions → XOR.
    Schedule also XOR-only.
    Pure GF(2) linear map. Invertible by running backward.
    """

    @staticmethod
    def schedule(W16):
        W = list(W16) + [0]*48
        for t in range(16, 64):
            W[t] = sigma1(W[t-2]) ^ W[t-7] ^ sigma0(W[t-15]) ^ W[t-16]
        return W

    @staticmethod
    def forward(W, n_rounds=64):
        a,b,c,d,e,f,g,h = IV
        for t in range(n_rounds):
            T1 = h ^ Sigma1(e) ^ (e^f^g) ^ K[t] ^ W[t]
            T2 = Sigma0(a) ^ (a^b^c)
            h=g;g=f;f=e;e=d^T1;d=c;c=b;b=a;a=T1^T2
        return (a,b,c,d,e,f,g,h)

    @staticmethod
    def finalize(state):
        return tuple(s ^ iv for s, iv in zip(state, IV))

    @staticmethod
    def inverse(output, W, n_rounds=64):
        """Invert: given output and schedule, recover IV.
        Run the round function backward using schedule words."""
        # Undo feedforward
        state = tuple(o ^ iv for o, iv in zip(output, IV))
        a,b,c,d,e,f,g,h = state

        for t in range(n_rounds-1, -1, -1):
            # Undo shift register: recover previous state
            a_old = b  # b = a_old (shift)
            b_old = c
            c_old = d
            e_old = f
            f_old = g
            g_old = h

            # T2 from known a_old, b_old, c_old
            T2 = Sigma0(a_old) ^ (a_old ^ b_old ^ c_old)
            # T1 from a = T1 ^ T2
            T1 = a ^ T2
            # d_old from e = d_old ^ T1
            d_old = e ^ T1
            # h_old from T1 = h_old ^ Σ₁(e_old) ^ (e_old^f_old^g_old) ^ K ^ W
            h_old = T1 ^ Sigma1(e_old) ^ (e_old ^ f_old ^ g_old) ^ K[t] ^ W[t]

            a,b,c,d,e,f,g,h = a_old,b_old,c_old,d_old,e_old,f_old,g_old,h_old

        return (a,b,c,d,e,f,g,h)


# ============================================================
# LAYER 2: QUADRATIC (add Ch/Maj, keep XOR additions)
# ============================================================

class QuadraticLayer:
    """Linear + Ch/Maj. No carries.
    Ch and Maj are degree-2 AND operations.
    Still invertible via schedule inverse (same trick as before).
    """

    @staticmethod
    def schedule(W16):
        # Same XOR schedule as linear (no carry in schedule either)
        W = list(W16) + [0]*48
        for t in range(16, 64):
            W[t] = sigma1(W[t-2]) ^ W[t-7] ^ sigma0(W[t-15]) ^ W[t-16]
        return W

    @staticmethod
    def forward(W, n_rounds=64):
        a,b,c,d,e,f,g,h = IV
        for t in range(n_rounds):
            T1 = h ^ Sigma1(e) ^ Ch(e,f,g) ^ K[t] ^ W[t]
            T2 = Sigma0(a) ^ Maj(a,b,c)
            h=g;g=f;f=e;e=d^T1;d=c;c=b;b=a;a=T1^T2
        return (a,b,c,d,e,f,g,h)

    @staticmethod
    def finalize(state):
        return tuple(s ^ iv for s, iv in zip(state, IV))

    @staticmethod
    def inverse(output, W, n_rounds=64):
        """Invert: given output and schedule, recover IV."""
        state = tuple(o ^ iv for o, iv in zip(output, IV))
        a,b,c,d,e,f,g,h = state

        for t in range(n_rounds-1, -1, -1):
            a_old = b; b_old = c; c_old = d
            e_old = f; f_old = g; g_old = h

            T2 = Sigma0(a_old) ^ Maj(a_old, b_old, c_old)
            T1 = a ^ T2
            d_old = e ^ T1
            h_old = T1 ^ Sigma1(e_old) ^ Ch(e_old, f_old, g_old) ^ K[t] ^ W[t]

            a,b,c,d,e,f,g,h = a_old,b_old,c_old,d_old,e_old,f_old,g_old,h_old

        return (a,b,c,d,e,f,g,h)


# ============================================================
# LAYER 3: CARRY (full SHA-256)
# ============================================================

class CarryLayer:
    """Full SHA-256 with mod-2^32 additions.
    Also invertible via schedule inverse.
    """

    @staticmethod
    def schedule(W16):
        W = list(W16) + [0]*48
        for t in range(16, 64):
            W[t] = (sigma1(W[t-2]) + W[t-7] + sigma0(W[t-15]) + W[t-16]) & M32
        return W

    @staticmethod
    def forward(W, n_rounds=64):
        a,b,c,d,e,f,g,h = IV
        for t in range(n_rounds):
            T1 = (h + Sigma1(e) + Ch(e,f,g) + K[t] + W[t]) & M32
            T2 = (Sigma0(a) + Maj(a,b,c)) & M32
            h=g;g=f;f=e;e=(d+T1)&M32;d=c;c=b;b=a;a=(T1+T2)&M32
        return (a,b,c,d,e,f,g,h)

    @staticmethod
    def finalize(state):
        return tuple((s + iv) & M32 for s, iv in zip(state, IV))

    @staticmethod
    def inverse(output, W, n_rounds=64):
        """Invert: given output and schedule, recover IV."""
        state = tuple((o - iv) & M32 for o, iv in zip(output, IV))
        a,b,c,d,e,f,g,h = state

        for t in range(n_rounds-1, -1, -1):
            a_old = b; b_old = c; c_old = d
            e_old = f; f_old = g; g_old = h

            T2 = (Sigma0(a_old) + Maj(a_old, b_old, c_old)) & M32
            T1 = (a - T2) & M32
            d_old = (e - T1) & M32
            h_old = (T1 - Sigma1(e_old) - Ch(e_old, f_old, g_old) - K[t] - W[t]) & M32

            a,b,c,d,e,f,g,h = a_old,b_old,c_old,d_old,e_old,f_old,g_old,h_old

        return (a,b,c,d,e,f,g,h)


# ============================================================
# LAYER PEELING: Compute inter-layer corrections
# ============================================================

class LayerPeeler:
    """Given an output, peel layers to extract each correction."""

    @staticmethod
    def peel(msg_byte):
        W16 = make_schedule(msg_byte)

        # Each layer's schedule
        W_lin = LinearLayer.schedule(W16)
        W_quad = QuadraticLayer.schedule(W16)
        W_carry = CarryLayer.schedule(W16)

        # Each layer's output
        s_lin = LinearLayer.forward(W_lin)
        s_quad = QuadraticLayer.forward(W_quad)
        s_carry = CarryLayer.forward(W_carry)

        o_lin = LinearLayer.finalize(s_lin)
        o_quad = QuadraticLayer.finalize(s_quad)
        o_carry = CarryLayer.finalize(s_carry)

        # Inter-layer corrections (XOR deltas)
        # quad_correction = what Ch/Maj added on top of linear
        quad_corr = tuple(o ^ l for o, l in zip(o_quad, o_lin))
        # carry_correction = what carries added on top of quadratic
        carry_corr = tuple(o ^ q for o, q in zip(o_carry, o_quad))

        return {
            'linear': o_lin,
            'quadratic': o_quad,
            'full': o_carry,
            'quad_correction': quad_corr,
            'carry_correction': carry_corr,
        }


# ============================================================
# MAIN: Test all layers and their inverses
# ============================================================

def main():
    print("=" * 60)
    print("SHA-256 LAYERED REVERSER")
    print("=" * 60)

    # Test each layer's forward + inverse
    layers = [
        ("Layer 1: LINEAR",    LinearLayer),
        ("Layer 2: QUADRATIC", QuadraticLayer),
        ("Layer 3: FULL",      CarryLayer),
    ]

    for name, Layer in layers:
        print(f"\n{'─'*60}")
        print(f"  {name}")
        print(f"{'─'*60}")

        n_ok = 0
        for byte_val in range(256):
            W16 = make_schedule(byte_val)
            W = Layer.schedule(W16)
            state = Layer.forward(W)
            output = Layer.finalize(state)

            # INVERT: given output + schedule, recover IV
            recovered = Layer.inverse(output, W)

            if recovered == tuple(IV):
                n_ok += 1

        print(f"  Forward → Inverse → IV: {n_ok}/256")
        if n_ok == 256:
            print(f"  ✓ PERFECT INVERSION")

    # Verify full layer matches hashlib
    print(f"\n{'─'*60}")
    print(f"  Verify Layer 3 (FULL) matches hashlib")
    print(f"{'─'*60}")
    n_match = 0
    for byte_val in range(256):
        W16 = make_schedule(byte_val)
        W = CarryLayer.schedule(W16)
        state = CarryLayer.forward(W)
        output = CarryLayer.finalize(state)
        h_bytes = b''.join(w.to_bytes(4, 'big') for w in output)
        expected = hashlib.sha256(bytes([byte_val])).digest()
        if h_bytes == expected:
            n_match += 1
    print(f"  Matches hashlib: {n_match}/256")

    # ============================================================
    # LAYER PEELING DEMO
    # ============================================================
    print(f"\n{'='*60}")
    print("LAYER PEELING: Corrections between layers")
    print("=" * 60)

    byte_val = 65  # 'A'
    p = LayerPeeler.peel(byte_val)

    print(f"\nInput: {byte_val} ('A')")
    print(f"  Linear output:      {' '.join(f'{x:08x}' for x in p['linear'])}")
    print(f"  + Quad correction:  {' '.join(f'{x:08x}' for x in p['quad_correction'])}")
    print(f"  = Quadratic output: {' '.join(f'{x:08x}' for x in p['quadratic'])}")
    print(f"  + Carry correction: {' '.join(f'{x:08x}' for x in p['carry_correction'])}")
    print(f"  = Full output:      {' '.join(f'{x:08x}' for x in p['full'])}")
    print(f"  hashlib:            {hashlib.sha256(b'A').hexdigest()}")

    # Hamming weight of each correction
    def hamming(words):
        return sum(bin(w).count('1') for w in words)

    hw_quad = hamming(p['quad_correction'])
    hw_carry = hamming(p['carry_correction'])
    print(f"\n  Quad correction Hamming weight:  {hw_quad}/256 bits ({hw_quad/256*100:.0f}%)")
    print(f"  Carry correction Hamming weight: {hw_carry}/256 bits ({hw_carry/256*100:.0f}%)")

    # ============================================================
    # CORRECTION STATISTICS
    # ============================================================
    print(f"\n{'='*60}")
    print("CORRECTION STATISTICS (all 256 inputs)")
    print("=" * 60)

    quad_hws = []
    carry_hws = []
    for byte_val in range(256):
        p = LayerPeeler.peel(byte_val)
        quad_hws.append(hamming(p['quad_correction']))
        carry_hws.append(hamming(p['carry_correction']))

    print(f"  Quad correction:  mean={np.mean(quad_hws):.0f} std={np.std(quad_hws):.0f} "
          f"min={min(quad_hws)} max={max(quad_hws)}")
    print(f"  Carry correction: mean={np.mean(carry_hws):.0f} std={np.std(carry_hws):.0f} "
          f"min={min(carry_hws)} max={max(carry_hws)}")

    # ============================================================
    # THE REVERSER: Given full hash, peel layers to find message
    # ============================================================
    print(f"\n{'='*60}")
    print("THE REVERSER: Full hash → peel layers → find message")
    print("=" * 60)

    target_byte = 65  # 'A'
    target_hash = hashlib.sha256(bytes([target_byte])).digest()
    target_words = struct.unpack('>8I', target_hash)

    print(f"\nTarget: SHA-256('A') = {target_hash.hex()}")
    print(f"\nStrategy: for each candidate byte 0-255:")
    print(f"  1. Compute schedule (cheap)")
    print(f"  2. Invert Layer 3 (carry) → should give IV")
    print(f"  3. Check if result == IV")

    found = []
    for byte_val in range(256):
        W16 = make_schedule(byte_val)
        W = CarryLayer.schedule(W16)
        recovered = CarryLayer.inverse(target_words, W)
        if recovered == tuple(IV):
            found.append(byte_val)

    print(f"\n  Found: {found} = {[chr(b) for b in found]}")
    print(f"  ✓ Correct!" if found == [target_byte] else "  ✗ Wrong!")

    # Now: what if we DON'T have the schedule?
    # Can we peel layers independently?
    print(f"\n{'='*60}")
    print("WITHOUT SCHEDULE: Peel carry first, then quadratic")
    print("=" * 60)
    print(f"""
  Given ONLY the hash (no message):

  Step 1: Compute carry correction from the hash state
          The carry at each round is deterministic given the state.
          But we don't have intermediate states — only the final one.

  Step 2: The quadratic correction depends on Ch/Maj values,
          which depend on the state variables.

  Step 3: The linear layer is the residual.

  Problem: we need intermediate states to peel, but intermediate
  states require the schedule (which requires the message).

  HOWEVER: the BACKWARD CASCADE works!
  Given hash + schedule → invert ALL layers simultaneously.
  That's what Layer.inverse() does — it's the schedule_inverse
  algorithm we already built.

  The layer decomposition tells us WHY it works:
  - Linear inverse: trivial (XOR is self-inverse)
  - Quadratic inverse: Ch/Maj at each round are local (only use current state)
  - Carry inverse: subtraction undoes addition

  Each layer's inverse is LOCAL (one round at a time) and CHEAP.
  The cascade composes them automatically.
""")

    # ============================================================
    # TIMING: How fast is the layered reverser?
    # ============================================================
    import time

    print(f"{'='*60}")
    print("TIMING: Layered reverser")
    print("=" * 60)

    N = 10000
    W16 = make_schedule(65)
    W_full = CarryLayer.schedule(W16)
    target = CarryLayer.finalize(CarryLayer.forward(W_full))

    t0 = time.time()
    for _ in range(N):
        CarryLayer.inverse(target, W_full)
    t1 = time.time()

    t2 = time.time()
    for _ in range(N):
        CarryLayer.forward(W_full)
    t3 = time.time()

    print(f"  Forward:  {(t3-t2)/N*1e6:.1f}µs per hash")
    print(f"  Inverse:  {(t1-t0)/N*1e6:.1f}µs per hash")
    print(f"  Ratio:    {(t1-t0)/(t3-t2):.2f}x")
    print(f"  Same cost — the inverse IS the forward run backward.")

if __name__ == "__main__":
    main()
