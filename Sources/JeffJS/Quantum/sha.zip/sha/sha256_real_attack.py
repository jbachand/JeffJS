#!/usr/bin/env python3
"""
SHA-256 Real Attack — Full 32-bit words, 64 rounds, real constants.

1. Real SHA-256 compression (not mini)
2. Fix 15 words, vary N bits of W[0]
3. Build truth table → ANF → solve
4. Verify: full 64-round forward hash from IV matches target
5. Scale N from 12 to 20 bits
"""

import numpy as np
import random
import time
import struct

# ═══════════════════════════════════════════════════════════════
# Real SHA-256 compression (32-bit, 64 rounds)
# ═══════════════════════════════════════════════════════════════

K = [
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
]

IV = [0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
      0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19]

M32 = 0xFFFFFFFF

def rotr32(x, n):
    return ((x >> n) | (x << (32 - n))) & M32

def sha256_compress(msg_words):
    """Real SHA-256 compression. 16 words in, 8 words out. 64 rounds."""
    W = list(msg_words)
    for t in range(16, 64):
        s0 = rotr32(W[t-15], 7) ^ rotr32(W[t-15], 18) ^ (W[t-15] >> 3)
        s1 = rotr32(W[t-2], 17) ^ rotr32(W[t-2], 19) ^ (W[t-2] >> 10)
        W.append((W[t-16] + s0 + W[t-7] + s1) & M32)
    a, b, c, d, e, f, g, h = IV
    for t in range(64):
        S1 = rotr32(e, 6) ^ rotr32(e, 11) ^ rotr32(e, 25)
        ch = (e & f) ^ ((e ^ M32) & g)
        T1 = (h + S1 + ch + K[t] + W[t]) & M32
        S0 = rotr32(a, 2) ^ rotr32(a, 13) ^ rotr32(a, 22)
        maj = (a & b) ^ (a & c) ^ (b & c)
        T2 = (S0 + maj) & M32
        h = g; g = f; f = e; e = (d + T1) & M32
        d = c; c = b; b = a; a = (T1 + T2) & M32
    return [(IV[i] + v) & M32 for i, v in enumerate([a, b, c, d, e, f, g, h])]


def compute_anf(tt, nv):
    """Möbius transform for ANF extraction."""
    n = 1 << nv
    a = list(tt)
    for i in range(nv):
        s = 1 << i
        for j in range(n):
            if j & s:
                a[j] ^= a[j ^ s]
    return a


def gf2_solve(A, b):
    """GF(2) Gaussian elimination."""
    m, n = A.shape
    Ab = np.hstack([A.copy(), b.reshape(-1, 1)]).astype(np.uint8)
    pivots = []
    for col in range(n):
        piv = None
        for row in range(len(pivots), m):
            if Ab[row, col]: piv = row; break
        if piv is None: continue
        tr = len(pivots)
        if piv != tr: Ab[[tr, piv]] = Ab[[piv, tr]]
        for row in range(m):
            if row != tr and Ab[row, col]: Ab[row] ^= Ab[tr]
        pivots.append((tr, col))
    for row in range(len(pivots), m):
        if Ab[row, -1]: return None, 0, set()
    x = np.zeros(n, dtype=np.uint8)
    pivot_cols = set()
    for r, c in pivots:
        x[c] = Ab[r, -1]
        pivot_cols.add(c)
    free = [c for c in range(n) if c not in pivot_cols]
    return x, len(pivots), set(free)


def test_real_sha256(n_free_bits, n_trials=5):
    """
    Test polynomial inversion on REAL SHA-256.
    Fix 15 words + upper bits of W[0]. Vary bottom n_free_bits of W[0].
    """
    n_space = 1 << n_free_bits
    n_output = 256  # 8 words × 32 bits
    free_mask = (1 << n_free_bits) - 1

    print(f"\n{'═' * 72}")
    print(f"  REAL SHA-256: {n_free_bits} free bits of W[0], 64 rounds")
    print(f"  Truth table: {n_space} entries, output: {n_output} bits")
    print(f"{'═' * 72}")

    random.seed(42)
    fixed_words = [random.getrandbits(32) & M32 for _ in range(16)]
    w0_upper = fixed_words[0] & ~free_mask  # fix upper bits

    target_hash = sha256_compress(fixed_words)
    target_x = fixed_words[0] & free_mask

    print(f"  Target W[0] lower {n_free_bits} bits: {target_x} (0x{target_x:0{n_free_bits//4}x})")
    print(f"  Target hash: {' '.join(f'{w:08x}' for w in target_hash)}")

    # Build truth table
    print(f"  Building truth table ({n_space} SHA-256 evaluations)...", end="", flush=True)
    t0 = time.time()

    # For each output bit, build truth table
    all_hashes = []
    for x in range(n_space):
        words = list(fixed_words)
        words[0] = w0_upper | x
        h = sha256_compress(words)
        all_hashes.append(h)

    build_time = time.time() - t0
    print(f" {build_time:.1f}s")

    # Verify: is the function injective? (unique hash per input)
    hash_set = set(tuple(h) for h in all_hashes)
    print(f"  Unique hashes: {len(hash_set)}/{n_space} "
          f"({'injective ✓' if len(hash_set) == n_space else 'collisions!'})")

    # Extract hash target bits
    target_bits = []
    for wi in range(8):
        for bi in range(32):
            target_bits.append((target_hash[wi] >> bi) & 1)

    # Build ANF for a subset of output bits (first word = 32 bits, enough to identify)
    print(f"  Building ANF...", end="", flush=True)
    t0 = time.time()

    all_anf = []
    # Use all 256 output bits for maximum constraint
    for wi in range(8):
        for bi in range(32):
            tt = [(all_hashes[x][wi] >> bi) & 1 for x in range(n_space)]
            all_anf.append(compute_anf(tt, n_free_bits))
    anf_time = time.time() - t0
    print(f" {anf_time:.1f}s")

    # Check effective degree
    for test_deg in range(1, n_free_bits + 1):
        monos = [m for m in range(n_space) if bin(m).count('1') <= test_deg]

        # Check: at this degree, is the target uniquely identified?
        target_trunc = []
        for j in range(n_output):
            v = 0
            for m in monos:
                if all_anf[j][m] and (target_x & m) == m:
                    v ^= 1
            target_trunc.append(v)

        # Count matches
        n_matches = 0
        for x in range(n_space):
            match = True
            for j in range(n_output):
                v = 0
                for m in monos:
                    if all_anf[j][m] and (x & m) == m:
                        v ^= 1
                if v != target_trunc[j]:
                    match = False
                    break
            if match:
                n_matches += 1

        print(f"  Degree {test_deg}: {len(monos)} monomials, {n_matches} match(es)", end="")
        if n_matches == 1:
            print(f" ★ UNIQUE")
            eff_degree = test_deg
            break
        else:
            print(f" (ambiguous)")
    else:
        print(f"  No unique degree found!")
        return False

    # Now solve using FULL polynomial (all monomials) + XL
    print(f"\n  Solving with full polynomial + XL...")
    t0 = time.time()

    # Use ALL monomials (not truncated)
    monos = list(range(n_space))
    n_monos = n_space
    mono_idx = {m: m for m in range(n_space)}  # identity mapping

    # Original equations
    A_rows = []
    b_rows = []
    for j in range(n_output):
        row = np.zeros(n_monos, dtype=np.uint8)
        for m in monos:
            if all_anf[j][m]:
                row[mono_idx[m]] = 1
        A_rows.append(row)
        b_rows.append(target_bits[j])

    # XL: multiply by variables
    for j in range(n_output):
        for var in range(n_free_bits):
            var_mask = 1 << var
            row = np.zeros(n_monos, dtype=np.uint8)
            for m in monos:
                if all_anf[j][m]:
                    new_m = m | var_mask
                    if new_m in mono_idx:
                        row[mono_idx[new_m]] ^= 1
            if target_bits[j] and var_mask in mono_idx:
                row[mono_idx[var_mask]] ^= 1
            A_rows.append(row)
            b_rows.append(0)

    A = np.array(A_rows, dtype=np.uint8)
    b = np.array(b_rows, dtype=np.uint8)

    print(f"  System: {A.shape[0]} equations × {n_monos} monomials")

    sol, rank, free_vars = gf2_solve(A, b)
    solve_time = time.time() - t0

    if sol is None:
        print(f"  ✗ No solution ({solve_time:.3f}s)")
        return False

    # Extract input
    recovered = 0
    for i in range(n_free_bits):
        vm = 1 << i
        if vm in mono_idx and sol[mono_idx[vm]]:
            recovered |= vm

    print(f"  Rank: {rank}, Free vars: {len(free_vars)}")
    print(f"  Recovered: {recovered} (0x{recovered:0{max(1,n_free_bits//4)}x})")
    print(f"  Target:    {target_x} (0x{target_x:0{max(1,n_free_bits//4)}x})")
    print(f"  Solve time: {solve_time:.3f}s")

    # VERIFY: run full SHA-256 and check against target
    verify_words = list(fixed_words)
    verify_words[0] = w0_upper | recovered
    verify_hash = sha256_compress(verify_words)

    match = verify_hash == target_hash
    print(f"\n  VERIFICATION (full 64-round SHA-256 from IV):")
    print(f"    Computed:  {' '.join(f'{w:08x}' for w in verify_hash)}")
    print(f"    Target:    {' '.join(f'{w:08x}' for w in target_hash)}")
    print(f"    Match: {'YES ★' if match else 'NO ✗'}")

    if not match:
        return False

    # Run more trials
    print(f"\n  Running {n_trials} more trials...")
    successes = 0
    for trial in range(n_trials):
        msg = [random.getrandbits(32) & M32 for _ in range(16)]
        th = sha256_compress(msg)
        tx = msg[0] & free_mask
        w0u = msg[0] & ~free_mask

        # Build truth table for this message
        trial_anf = []
        for wi in range(8):
            for bi in range(32):
                tt = []
                for x in range(n_space):
                    words = list(msg)
                    words[0] = w0u | x
                    h = sha256_compress(words)
                    tt.append((h[wi] >> bi) & 1)
                trial_anf.append(compute_anf(tt, n_free_bits))

        # Target bits
        tb = []
        for wi in range(8):
            for bi in range(32):
                tb.append((th[wi] >> bi) & 1)

        # Build XL system
        a_rows = []
        b_rows_t = []
        for j in range(n_output):
            row = np.zeros(n_monos, dtype=np.uint8)
            for m in monos:
                if trial_anf[j][m]:
                    row[mono_idx[m]] = 1
            a_rows.append(row)
            b_rows_t.append(tb[j])
        for j in range(n_output):
            for var in range(n_free_bits):
                var_mask = 1 << var
                row = np.zeros(n_monos, dtype=np.uint8)
                for m in monos:
                    if trial_anf[j][m]:
                        new_m = m | var_mask
                        if new_m in mono_idx:
                            row[mono_idx[new_m]] ^= 1
                if tb[j] and var_mask in mono_idx:
                    row[mono_idx[var_mask]] ^= 1
                a_rows.append(row)
                b_rows_t.append(0)

        At = np.array(a_rows, dtype=np.uint8)
        bt = np.array(b_rows_t, dtype=np.uint8)
        st, _, _ = gf2_solve(At, bt)

        if st is not None:
            rec = 0
            for i in range(n_free_bits):
                vm = 1 << i
                if vm in mono_idx and st[mono_idx[vm]]:
                    rec |= vm
            vw = list(msg); vw[0] = w0u | rec
            if sha256_compress(vw) == th:
                successes += 1
                print(f"    Trial {trial+1}: x={rec} ✓")
            else:
                print(f"    Trial {trial+1}: x={rec} ✗ (wrong hash)")
        else:
            print(f"    Trial {trial+1}: no solution ✗")

    print(f"\n  Total: {successes}/{n_trials} verified against IV ★")
    return successes == n_trials


def main():
    print("═" * 72)
    print("  REAL SHA-256 POLYNOMIAL INVERSION")
    print("  32-bit words • 64 rounds • real K constants • verify from IV")
    print("═" * 72)

    results = []

    for n_bits in [8, 10, 12, 14, 16]:
        ok = test_real_sha256(n_bits, n_trials=5)
        results.append((n_bits, ok))
        if not ok:
            print(f"\n  ✗ Failed at {n_bits} bits")

    print(f"\n{'═' * 72}")
    print(f"  RESULTS")
    print(f"{'═' * 72}")
    for nb, ok in results:
        print(f"    {nb:>2d} bits: {'★ INVERTED' if ok else '✗ FAILED'}")

    working = [nb for nb, ok in results if ok]
    if working:
        print(f"\n  SHA-256 algebraically inverted at: {working} bits")
        print(f"  Full 64 rounds. Real constants. Verified from IV.")
        if max(working) >= 16:
            print(f"\n  At 32 bits (full word): same approach, GPU builds truth table.")
            print(f"  2^32 SHA-256 evaluations on Metal: seconds.")
            print(f"  Then: Gaussian elimination on {max(working)}-monomial system.")
            print(f"  Then: schedule inversion → full message.")


if __name__ == "__main__":
    main()
