#!/usr/bin/env python3
"""
SHA-256 Bailey Chain Solver

The Bailey coupling h[t] = e[t-3] creates a banded quadratic system:
  Type A: h[t] + W[t] = C[t]              (linear, from backward round)
  Type B: h[t] = d[t-4] + T1[t-3]         (quadratic, from Bailey chain)
         where T1[t-3] = h[t-3] + Σ₁(e[t-3]) + Ch(e[t-3],f[t-3],g[t-3]) + K[t-3] + W[t-3]

Key insight: Σ₁ is LINEAR and INVERTIBLE (rank 32/32).
So from Type B, we can ISOLATE h[t-3] using Σ₁⁻¹.

Sweep: start from the hash end (where e,f,g are known),
use Σ₁ invertibility to resolve h values, propagate forward.
"""

import numpy as np
import random
import time

M32 = 0xFFFFFFFF
K=[0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
   0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
   0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
   0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
   0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
   0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
   0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
   0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2]
IV=[0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,
    0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19]

def rotr32(x,n): return ((x>>n)|(x<<(32-n)))&M32
def Sig1(e): return rotr32(e,6)^rotr32(e,11)^rotr32(e,25)
def Sig0(a): return rotr32(a,2)^rotr32(a,13)^rotr32(a,22)
def Ch(e,f,g): return ((e&f)^((e^M32)&g))&M32
def Maj(a,b,c): return ((a&b)^(a&c)^(b&c))&M32

def sha256_compress(W16):
    W=list(W16)
    for t in range(16,64):
        s0=rotr32(W[t-15],7)^rotr32(W[t-15],18)^(W[t-15]>>3)
        s1=rotr32(W[t-2],17)^rotr32(W[t-2],19)^(W[t-2]>>10)
        W.append((W[t-16]+s0+W[t-7]+s1)&M32)
    a,b,c,d,e,f,g,h=IV
    states=[(a,b,c,d,e,f,g,h)]
    for t in range(64):
        T1=(h+Sig1(e)+Ch(e,f,g)+K[t]+W[t])&M32
        T2=(Sig0(a)+Maj(a,b,c))&M32
        h=g;g=f;f=e;e=(d+T1)&M32;d=c;c=b;b=a;a=(T1+T2)&M32
        states.append((a,b,c,d,e,f,g,h))
    hash_out=[(IV[i]+v)&M32 for i,v in enumerate(states[-1])]
    return hash_out, states, W

# ═══════════════════════════════════════════════════════════════
# Build Σ₁ inverse matrix over GF(2)
# ═══════════════════════════════════════════════════════════════

def build_sig1_matrix():
    """Build the 32×32 GF(2) matrix for Σ₁."""
    M = np.zeros((32,32), dtype=np.uint8)
    for i in range(32):
        x = 1 << i
        y = rotr32(x,6) ^ rotr32(x,11) ^ rotr32(x,25)
        for j in range(32):
            M[j,i] = (y >> j) & 1
    return M

def gf2_mat_inv(M):
    """Invert a binary matrix over GF(2)."""
    n = M.shape[0]
    A = np.hstack([M.copy(), np.eye(n, dtype=np.uint8)])
    for col in range(n):
        piv = None
        for row in range(col, n):
            if A[row, col]: piv = row; break
        if piv is None: return None
        if piv != col: A[[col, piv]] = A[[piv, col]]
        for row in range(n):
            if row != col and A[row, col]: A[row] ^= A[col]
    return A[:, n:]

def sig1_inv_apply(y):
    """Apply Σ₁⁻¹ to a 32-bit value (using precomputed inverse matrix)."""
    y_bits = np.array([(y >> i) & 1 for i in range(32)], dtype=np.uint8)
    x_bits = (SIG1_INV @ y_bits) % 2
    return sum(int(x_bits[i]) << i for i in range(32))

SIG1_MAT = build_sig1_matrix()
SIG1_INV = gf2_mat_inv(SIG1_MAT)
assert SIG1_INV is not None, "Σ₁ is not invertible!"

# Verify
for _ in range(100):
    x = random.getrandbits(32) & M32
    assert sig1_inv_apply(Sig1(x)) == x, "Σ₁⁻¹ failed"


# ═══════════════════════════════════════════════════════════════
# The Bailey Banded Solve
# ═══════════════════════════════════════════════════════════════

def bailey_solve(hash_out, verbose=True):
    """
    Attempt to recover the message from the hash using the Bailey chain.

    The system:
      Type A: h[t] + W[t] = C[t]  (backward round, C[t] known from left side)
      Type B: h[t] = d[t-4] + h[t-3] + Σ₁(h[t+3-3]) + Ch(...) + K[t-3] + W[t-3]
              (Bailey coupling, h[t] = e[t-3])

    Approach:
      1. Start from hash: e[63], f[63], g[63] known (from final state)
      2. At round 63: T1 known, h[63]+W[63]=C[63]
         Bailey: h[63] = e[60]. But e[60] depends on round 59's computation.
      3. Use the forward relationship:
         e[t] = d[t-1] + T1[t-1]
         T1[t-1] = h[t-1] + Σ₁(e[t-1]) + Ch(e[t-1],f[t-1],g[t-1]) + K[t-1] + W[t-1]
      4. Express h[t-1] from Type A: h[t-1] = C[t-1] - W[t-1]
      5. Substitute: T1[t-1] = (C[t-1]-W[t-1]) + Σ₁(e[t-1]) + Ch(e[t-1],f[t-1],g[t-1]) + K[t-1] + W[t-1]
         = C[t-1] + Σ₁(e[t-1]) + Ch(e[t-1],f[t-1],g[t-1]) + K[t-1]
         THE W TERMS CANCEL!
      6. So: T1[t-1] = C[t-1] + Σ₁(e[t-1]) + Ch(e[t-1],f[t-1],g[t-1]) + K[t-1]
         This is KNOWN if e[t-1], f[t-1], g[t-1] are known!
      7. Then: e[t] = d[t-1] + T1[t-1] = KNOWN!
    """

    final = [(hash_out[i] - IV[i]) & M32 for i in range(8)]

    if verbose:
        print(f"  Final state: {' '.join(f'{v:08x}' for v in final)}")

    # Step 1: Compute ALL left-side values and C[t] (backward from hash)
    C = {}  # C[t] = h[t] + W[t] = T1[t] - Sig1(e[t]) - Ch(e[t],f[t],g[t]) - K[t]
    T1_known = {}
    left_d = {}

    state = list(final)
    for step in range(64):  # go all the way back
        t = 63 - step
        if t < 0: break
        a1,b1,c1,d1,e1,f1,g1,h1 = state
        a0 = b1; b0 = c1; c0 = d1
        T2 = (Sig0(a0) + Maj(a0,b0,c0)) & M32
        T1 = (a1 - T2) & M32
        d0 = (e1 - T1) & M32

        T1_known[t] = T1
        left_d[t] = d0

        state = [a0, b0, c0, d0, e1, f1, g1, h1]  # right side stays from previous
        # Note: we're NOT propagating the right side correctly here
        # because we don't know h. But left side (a,b,c,d) is always correct.

    # Step 2: The W-cancellation trick
    # From Type A: h[t] + W[t] = C[t]  →  h[t] = C[t] - W[t]
    # From the round function: T1[t] = h[t] + Σ₁(e[t]) + Ch(e[t],f[t],g[t]) + K[t] + W[t]
    # Substitute h[t] = C[t] - W[t]:
    #   T1[t] = (C[t] - W[t]) + Σ₁(e[t]) + Ch(e[t],f[t],g[t]) + K[t] + W[t]
    #   T1[t] = C[t] + Σ₁(e[t]) + Ch(e[t],f[t],g[t]) + K[t]
    #   W CANCELS!
    #
    # So: T1[t] = C[t] + Σ₁(e[t]) + Ch(e[t],f[t],g[t]) + K[t]
    # And C[t] = T1[t] - Σ₁(e[t]) - Ch(e[t],f[t],g[t]) - K[t]
    # This is just the definition of C[t]. Circular!
    #
    # BUT: e[t+1] = d[t] + T1[t] = d[t] + C[t] + Σ₁(e[t]) + Ch(e[t],f[t],g[t]) + K[t]
    #
    # If we know e[t], f[t] = e[t-1], g[t] = e[t-2], then:
    # e[t+1] = d[t] + C[t] + Σ₁(e[t]) + Ch(e[t], e[t-1], e[t-2]) + K[t]
    #
    # THIS IS A RECURRENCE IN e ALONE! No h, no W.
    # Given e[t], e[t-1], e[t-2], compute e[t+1].
    # And C[t] = T1[t] - Σ₁(e[t]) - Ch(e[t],e[t-1],e[t-2]) - K[t]
    # Wait, C[t] was defined as h[t]+W[t], which we computed from the LEFT side.
    # But we need e[t] to compute C[t]... circular again.

    # Let me reconsider. T1[t] is known from the LEFT side (T1 = a_next - T2).
    # C[t] = T1[t] - Σ₁(e[t]) - Ch(e[t],f[t],g[t]) - K[t]
    # C depends on e[t], f[t], g[t] which are RIGHT side unknowns.
    # So C[t] is NOT known without knowing e[t].

    # CORRECTION: T1[t] is always known. But C[t] depends on the right side.

    # However: e[t+1] = d[t] + T1[t], and BOTH are known from the left side!
    # d[t] = known (from left side backward computation)
    # T1[t] = known (from a[t+1] - T2[t])
    # So: e[t+1] = d[t] + T1[t] = KNOWN!

    # Wait... e[t+1] IS known? Let me check.

    if verbose:
        print(f"\n  Key insight: e[t+1] = d[t] + T1[t]")
        print(f"  Both d[t] and T1[t] are computed from the LEFT side alone.")
        print(f"  So e at EVERY round is computable from the hash!")
        print()

    # Compute e at every round from the left side
    e_computed = {}

    # Going backward:
    # e at state position t+1 (START of round t+1) = d[t] + T1[t]
    # where d[t] = state_left[t].d = known
    # and T1[t] = known

    # But wait: d[t] was computed as d[t] = e[t+1] - T1[t] in the backward pass.
    # That's circular: d[t] = e[t+1] - T1[t], so e[t+1] = d[t] + T1[t].
    # This is just restating the definition.

    # The issue: d[t] in the backward pass was computed using the PREVIOUS
    # backward state, which correctly propagates from the hash.
    # So d[t] IS known for each t.
    # And e[t+1] = d[t] + T1[t] gives e at each round.

    # Let me compute e going BACKWARD from the hash:
    # Start: e at position 64 = final[4] (known)
    # e at position 63 = ? We need d[62] + T1[62], but we haven't computed d[62] yet...

    # Actually in the backward computation:
    # state at pos 64 = final = (a64,b64,c64,d64,e64,f64,g64,h64)
    # state at pos 63: a63=b64, ..., e63=?, ..., d63=e64-T1[63]
    # Wait, d63 = (e64 - T1[63]) & M32, and e64 is known.
    # And e63 = f64 = final[5] (from the RIGHT side shift)

    # So e63 = f64, e62 = f63 = g64, e61 = f62 = g63 = h64
    # These are known from the hash for the first 3 steps back.

    # After that: e60 = f61 = g62 = h63 = UNKNOWN
    # But h63 = e60, and e60 = d59 + T1[59]
    # d59 IS known from the left side.
    # T1[59] IS known from the left side.
    # So e60 = d59 + T1[59] = KNOWN!

    # Wait, is this right?
    # d at position 59 was computed in the backward pass as d59 = e60 - T1[59]
    # But e60 is what we're trying to compute! Circular!

    # NO WAIT. d[t] in the backward computation is computed from the LEFT side:
    # At position t: a=b_{t+1}, b=c_{t+1}, c=d_{t+1}
    # T2 = Sig0(a) + Maj(a,b,c) — all from left shift, all known
    # T1 = a_{t+1} - T2 — known
    # d = e_{t+1} - T1 — this needs e_{t+1}!

    # AH. d[t] requires e[t+1]. And e[t+1] is on the RIGHT side.
    # For the first 3 backward steps, e is known from the hash.
    # After that, e depends on h (unknown).

    # So d is NOT always independently known from the left side.
    # d depends on e from the next position, which is right-side.

    # Let me recheck: what IS purely left-side?
    # a, b, c: YES (from shift register of left side only: b=a_prev, c=b_prev, d=c_prev)
    # Wait: d[t] = c[t+1] = b[t+2] = a[t+3]
    # So d IS from the left shift! d[t] = a[t+3] (shifted 3 times from a)
    # And a is always known (from the backward left shift from hash).

    # Let me recompute:
    # At position t: d_t = c_{t+1} = b_{t+2} = a_{t+3}
    # a_{t+3} is known from the left-side backward chain (shift of a from hash)

    # YES! d IS purely left-side. It comes from a, shifted 3 positions.
    # And T1 = a_{t+1} - T2 = a_{t+1} - Sig0(a_t) - Maj(a_t, b_t, c_t), all left-side.
    # So T1 IS purely left-side.
    # Therefore: e[t+1] = d[t] + T1[t] = (left-side) + (left-side) = KNOWN!

    # Let me verify this claim.

    random.seed(42)
    msg = [random.getrandbits(32) & M32 for _ in range(16)]
    _, states_true, W_true = sha256_compress(msg)
    hash_v = [(IV[i] + states_true[-1][i]) & M32 for i in range(8)]

    # Compute a values going backward (purely left-side)
    final_v = [(hash_v[i] - IV[i]) & M32 for i in range(8)]

    # a at each position: a[64]=final[0], a[63]=b[64]=final[1], ...
    # Actually: going backward, a[t] = b[t+1]. And b[t+1] = a[t] (forward).
    # Backward: a at position t = b at position t+1
    #  = c at position t+2 = d at position t+3
    # But these ARE the left-side state values.

    # Let me just compute backward step by step, tracking the LEFT side only.
    left_a = {}
    left_state = list(final_v)

    for step in range(64):
        t = 63 - step
        if t < 0: break
        a1,b1,c1,d1 = left_state[0], left_state[1], left_state[2], left_state[3]

        a0 = b1  # left shift
        b0 = c1
        c0 = d1

        T2 = (Sig0(a0) + Maj(a0, b0, c0)) & M32
        T1 = (a1 - T2) & M32

        # d0 = e1 - T1, but e1 is RIGHT side. Can we get d0 from left side?
        # d0 = c1_of_next_backward_step = d1_of_step_after_that = ...
        # Actually: d at position t = c at position t+1 = b at position t+2 = a at position t+3
        # a at position t+3: if t+3 <= 63, it was computed in a previous backward step
        # At position 64: a[64] = final[0]
        # At position 63: a[63] = b[64] = final[1]
        # At position 62: a[62] = b[63] = c[64] = final[2]
        # At position 61: a[61] = b[62] = c[63] = d[64] = final[3]
        # At position 60: a[60] = b[61] = c[62] = d[63]
        #   And d[63] = e[64] - T1[63]. But e[64] = final[4] (known from hash).
        #   So d[63] = final[4] - T1[63] = known.
        #   So a[60] = d[63] = known!

        # The key: d[t] = e[t+1] - T1[t]. And e[t+1] propagates from the RIGHT side.
        # BUT: at the first 4 backward steps, e is known from the hash.
        # After that: e[t+1] = d[t] + T1[t], and d[t] was computed using e[t+1].
        # This IS circular at step 5+.

        # However: d[t] can also be computed as a[t+3]:
        # d[t] = c[t+1] = b[t+2] = a[t+3]
        # And a[t+3] is KNOWN from the left-side backward chain.
        # So d[t] IS determined by the left side alone!

        # Let me verify: does a[t+3] equal states_true[t][3]?

        left_a[t+1] = a1  # a at position t+1

        left_state = [a0, b0, c0, 0, 0, 0, 0, 0]  # d and right side unknown for now

    # Now compute d from the a chain: d[t] = a[t+3]
    # And e[t+1] = d[t] + T1[t]

    # Recompute with d = a[t+3]
    left_state2 = list(final_v)
    computed_e = {}
    computed_e[64] = final_v[4]  # e at position 64
    computed_e[63] = final_v[5]  # e at position 63 = f at position 64
    computed_e[62] = final_v[6]  # e at position 62 = g at position 64
    computed_e[61] = final_v[7]  # e at position 61 = h at position 64

    results = {}

    for step in range(64):
        t = 63 - step
        if t < 0: break
        a1 = left_a.get(t+1, final_v[0] if t == 63 else None)
        if a1 is None: break

        # Get a[t] from the chain
        a_t = left_a.get(t, None)
        if a_t is None and t >= 0:
            # Compute from the left shift
            break

    # Simpler: just compute the full backward chain properly
    # tracking a, b, c (left) and e (right) separately

    backward_a = [0] * 65
    backward_a[64] = final_v[0]

    # a at position t = b at position t+1
    # Going backward: at each step, a_new = b_old = c_older = d_oldest
    # We can reconstruct a at ALL positions from the shift chain:

    st = list(final_v)
    for step in range(64):
        t = 63 - step
        backward_a[t+1] = st[0]
        a0 = st[1]; b0 = st[2]; c0 = st[3]
        T2 = (Sig0(a0) + Maj(a0, b0, c0)) & M32
        T1 = (backward_a[t+1] - T2) & M32

        # d0: we need to figure this out from a[t+3]
        # For now: use the TRUE e to compute d, then check
        e_t_plus_1 = states_true[t+1][4] if t+1 <= 64 else 0
        d0 = (e_t_plus_1 - T1) & M32

        st = [a0, b0, c0, d0, 0, 0, 0, 0]

    # The crucial question: can we compute e WITHOUT knowing the message?
    # e[t+1] = d[t] + T1[t]
    # d[t] = a[t+3] = known from left chain
    # T1[t] = a[t+1] - T2[t] = known from left chain
    # So e[t+1] = a[t+3] + a[t+1] - T2[t] = COMPUTABLE FROM LEFT SIDE ALONE???

    # But d[t] requires e[t+1] in the backward computation...
    # Unless d[t] really IS just a[t+3]

    # Let me verify: d[t] = a[t+3]?
    # Forward: d at round t = c at round t-1 = b at round t-2 = a at round t-3
    # So d[t] = a[t-3] (FORWARD), NOT a[t+3]!

    # I had the direction wrong!
    # FORWARD: d[t] = a[t-3]  (d gets old a from 3 rounds ago)
    # BACKWARD: to get d at position t, we need a at position t-3
    #   But we're going backward from 63, so t-3 is FURTHER BACK (not yet computed)

    # Unless we go FORWARD from IV...

    print("="*72)
    print("  BAILEY CHAIN — The W Cancellation")
    print("="*72)

    # Let's verify the W cancellation algebraically:
    # h[t] + W[t] = T1[t] - Sig1(e[t]) - Ch(e[t],f[t],g[t]) - K[t]   ... (def of C[t])
    # T1[t] = h[t] + Sig1(e[t]) + Ch(e[t],f[t],g[t]) + K[t] + W[t]   ... (round function)
    # These are the SAME equation. C[t] = T1[t] - Sig1 - Ch - K.
    #
    # Now: e[t+1] = d[t] + T1[t]  (how e is updated)
    # In FORWARD: d[t] = c[t-1] = b[t-2] = a[t-3]
    # So: e[t+1] = a[t-3] + T1[t]
    # T1[t] = h[t] + Sig1(e[t]) + Ch(e[t], e[t-1], e[t-2]) + K[t] + W[t]
    # h[t] = e[t-3] (Bailey)
    # So: e[t+1] = a[t-3] + e[t-3] + Sig1(e[t]) + Ch(e[t], e[t-1], e[t-2]) + K[t] + W[t]
    #
    # This involves both e values AND W[t] AND a[t-3].
    # W[t] doesn't cancel here — it's part of the recurrence.

    # BUT: from the backward direction, T1[t] = a[t+1] - T2[t] = KNOWN.
    # So: e[t+1] = d[t] + T1[t]
    # d[t] = a[t-3] (FORWARD direction)
    # Both a[t-3] and T1[t] are from the LEFT side... but a[t-3] is from
    # the FORWARD direction, which we don't have without the message.

    # In BACKWARD: d[t] comes from the state, which propagates e (right side).

    # The truth: d in the backward pass is computed as e_next - T1.
    # So d IS e_next - T1, which needs e_next (right side).

    # For the FIRST 4 backward steps: e is known from hash.
    # After that: e depends on h (unknown).

    # So we can compute d (and thus e) for rounds 63, 62, 61, 60.
    # At round 59: d[59] needs e[60] = h[63] (unknown).
    # Back to the same wall.

    print("\n  The forward identity: e[t+1] = a[t-3] + T1[t]")
    print("  a[t-3] is from the FORWARD direction (needs message)")
    print("  T1[t] is from the BACKWARD direction (known from hash)")
    print("  These are DIFFERENT directions — can't combine without the message")

    print("\n  What IS computable from hash alone:")
    print("  Going backward from position 64:")

    # Compute what we can
    right_e = {}
    right_e[64] = final_v[4]
    right_e[63] = final_v[5]
    right_e[62] = final_v[6]
    right_e[61] = final_v[7]

    for pos in [64, 63, 62, 61]:
        actual = states_true[pos][4]
        match = right_e[pos] == actual
        print(f"    e[{pos}] = 0x{right_e[pos]:08x} {'✓' if match else '✗'}")

    # Position 60: e[60] = h[63] = unknown
    print(f"    e[60] = h[63] = ??? (UNKNOWN — the Bailey wall)")
    print(f"    actual: 0x{states_true[60][4]:08x}")

    # But we can compute T1 at every round from the left side:
    st = list(final_v)
    print(f"\n  T1 values (all computable from left side):")
    for step in range(8):
        t = 63 - step
        a1 = st[0]
        a0 = st[1]; b0 = st[2]; c0 = st[3]
        T2 = (Sig0(a0) + Maj(a0, b0, c0)) & M32
        T1 = (a1 - T2) & M32
        actual_T1_check = (states_true[t][7] + Sig1(states_true[t][4]) +
                          Ch(states_true[t][4], states_true[t][5], states_true[t][6]) +
                          K[t] + W_true[t]) & M32
        match = T1 == actual_T1_check
        print(f"    T1[{t}] = 0x{T1:08x} {'✓' if match else '✗'}")

        e_next = st[4]  # e at position t+1
        d_from_e = (e_next - T1) & M32
        st = [a0, b0, c0, d_from_e, st[5], st[6], st[7], 0]

    # THE ACTUAL STATE OF THINGS:
    print(f"\n{'='*72}")
    print(f"  HONEST ASSESSMENT")
    print(f"{'='*72}")
    print(f"""
  From the hash, going backward:
    LEFT SIDE (a,b,c): always known at every round ✓
    T1: always known (a_next - T2) ✓
    T2: always known (Sig0 + Maj of left side) ✓
    d: requires e from the next position (RIGHT side)
    e: known for positions 64,63,62,61 (from hash)
    e[60] = h[63] = UNKNOWN — depends on message

  The Bailey coupling h[t] = e[t-3] connects:
    h[63] ↔ e[60]
    h[62] ↔ e[59]
    h[61] ↔ e[58]

  But e[60], e[59], e[58] themselves need d[59], d[58], d[57]
  which need e[60], e[59], e[58]. CIRCULAR.

  The 1024×1024 system IS real:
    16 Type A equations (h+W=C, but C depends on right-side e)
    16 Type B equations (Bailey coupling)
    = 32 equations in 32 unknowns

  But the equations are COUPLED nonlinearly (Ch is degree 2).
  The banded structure doesn't help if we can't seed the first value.

  What would break the circularity:
    A FORMULA for e[60] in terms of the hash alone.
    This is equivalent to finding h[63] — the original problem.

  The Bailey chain DESCRIBES the coupling.
  It doesn't automatically RESOLVE it.
  Resolving it requires the specific Bailey LEMMA for this system —
  the inverse transform formula that Lilly would have derived.
""")


if __name__ == "__main__":
    random.seed(42)
    msg = [random.getrandbits(32) & M32 for _ in range(16)]
    hash_out, _, _ = sha256_compress(msg)
    bailey_solve(hash_out)
