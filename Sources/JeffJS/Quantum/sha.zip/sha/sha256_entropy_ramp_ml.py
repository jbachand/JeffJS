#!/usr/bin/env python3
"""
Train ML on the ENTROPY PATTERN of the last 16 rounds, not the hash bits.

Key insight: individual hash bits are at 50% (random, unlearnable).
But the round-by-round EVOLUTION has structure:
- How does the weight matrix CHANGE between rounds?
- Is the XOR (delta) between consecutive round states sparse?
- Can ML learn the pattern of density evolution?

Target: the intermediate state evolution, not the endpoint.
"""

import numpy as np
from math import comb
import struct
import time

M32 = 0xFFFFFFFF

def rotr(x, n): return ((x >> n) | (x << (32 - n))) & M32
def shr(x, n): return x >> n
def Sigma1(x): return rotr(x, 6) ^ rotr(x, 11) ^ rotr(x, 25)
def Sigma0(x): return rotr(x, 2) ^ rotr(x, 13) ^ rotr(x, 22)
def sigma1(x): return rotr(x, 17) ^ rotr(x, 19) ^ shr(x, 10)
def sigma0(x): return rotr(x, 7) ^ rotr(x, 18) ^ shr(x, 3)
def Ch(e, f, g): return (e & f) ^ ((~e) & g) & M32
def Maj(a, b, c): return (a & b) ^ (a & c) ^ (b & c)

K = [0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
     0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
     0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
     0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
     0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
     0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
     0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
     0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2]
IV = [0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,
      0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19]

def sha256_all_states(msg_byte):
    msg = bytes([msg_byte])
    padded = msg + b'\x80' + b'\x00' * 54 + struct.pack('>Q', 8)
    W = list(struct.unpack('>16I', padded))
    for t in range(16, 64):
        W.append((sigma1(W[t-2]) + W[t-7] + sigma0(W[t-15]) + W[t-16]) & M32)
    a,b,c,d,e,f,g,h = IV
    states = [(a,b,c,d,e,f,g,h)]
    t1v, t2v = [], []
    for t in range(64):
        T1 = (h + Sigma1(e) + Ch(e,f,g) + K[t] + W[t]) & M32
        T2 = (Sigma0(a) + Maj(a,b,c)) & M32
        t1v.append(T1); t2v.append(T2)
        h=g;g=f;f=e;e=(d+T1)&M32;d=c;c=b;b=a;a=(T1+T2)&M32
        states.append((a,b,c,d,e,f,g,h))
    return states, t1v, t2v, W

def state_to_bits(state):
    bits = np.zeros(256, dtype=np.uint8)
    for w in range(8):
        for b in range(32):
            bits[w*32+b] = (state[w]>>b)&1
    return bits

def mobius(Y, n_bits):
    a = Y.copy()
    for i in range(n_bits):
        mask = 1 << i
        for x in range(len(a)):
            if x & mask:
                a[x] ^= a[x ^ mask]
    return a

def int_to_bits(v, n):
    return np.array([(v>>i)&1 for i in range(n)], dtype=np.uint8)

def gf2_solve(A, b):
    m, n = A.shape
    M = np.hstack([A%2, (b%2).reshape(-1,1)]).astype(np.uint8)
    pivot_row = 0; pivot_cols = []
    for col in range(n):
        found = False
        for row in range(pivot_row, m):
            if M[row,col]==1: M[[pivot_row,row]]=M[[row,pivot_row]]; found=True; break
        if not found: continue
        pivot_cols.append(col)
        for row in range(m):
            if row!=pivot_row and M[row,col]==1: M[row]^=M[pivot_row]
        pivot_row += 1
    for row in range(pivot_row, m):
        if M[row,n]==1: return None
    x = np.zeros(n, dtype=np.uint8)
    for i, col in enumerate(pivot_cols): x[col] = M[i, n]
    return x

def main():
    N_BITS = 8
    N = 256

    print("=" * 70)
    print("ENTROPY RAMP ML: Learning the round-by-round evolution")
    print("=" * 70)

    # Collect all intermediate states for all inputs
    print("Computing all 256 × 65 intermediate states...")
    all_states = []
    all_t1 = []
    all_t2 = []
    all_W = []
    for val in range(N):
        states, t1v, t2v, W = sha256_all_states(val)
        all_states.append(states)
        all_t1.append(t1v)
        all_t2.append(t2v)
        all_W.append(W)

    # ============================================================
    # EXPERIMENT 1: Round-by-round delta density
    # XOR between consecutive state weight matrices
    # ============================================================
    print(f"\n{'='*70}")
    print("EXP 1: State delta (XOR) density between consecutive rounds")
    print("=" * 70)

    prev_state_bits = None
    print(f"{'Round':>5} | {'State density':>13} | {'Delta density':>13} | "
          f"{'Delta a+e':>10} | {'Delta rest':>10}")
    print("-" * 70)

    for rnd in list(range(65)):
        # State bits for all inputs at this round
        Y = np.zeros((N, 256), dtype=np.uint8)
        for val in range(N):
            Y[val] = state_to_bits(all_states[val][rnd])

        # ANF weight matrix
        W_anf = np.zeros_like(Y)
        for ob in range(256):
            W_anf[:, ob] = mobius(Y[:, ob], N_BITS)

        state_density = np.sum(W_anf) / W_anf.size

        if prev_state_bits is not None:
            delta = (Y ^ prev_state_bits)  # bit-level XOR
            # ANF of delta
            W_delta = np.zeros_like(delta)
            for ob in range(256):
                W_delta[:, ob] = mobius(delta[:, ob], N_BITS)
            delta_density = np.sum(W_delta) / W_delta.size

            # Delta for a,e (words 0,4) vs rest
            ae_cols = list(range(0, 32)) + list(range(128, 160))
            rest_cols = [c for c in range(256) if c not in ae_cols]
            ae_density = np.sum(W_delta[:, ae_cols]) / (N * len(ae_cols))
            rest_density = np.sum(W_delta[:, rest_cols]) / (N * len(rest_cols))

            if rnd <= 10 or rnd >= 58 or rnd % 8 == 0:
                print(f"  R={rnd:2d}  | {state_density*100:12.1f}% | "
                      f"{delta_density*100:12.1f}% | "
                      f"{ae_density*100:9.1f}% | {rest_density*100:9.1f}%")
        else:
            if rnd == 0:
                print(f"  R= 0  | {state_density*100:12.1f}% |          (IV) |           |")

        prev_state_bits = Y.copy()

    # ============================================================
    # EXPERIMENT 2: T1 round-by-round delta
    # ============================================================
    print(f"\n{'='*70}")
    print("EXP 2: T1 value delta density (T1[t] XOR T1[t-1])")
    print("=" * 70)

    print(f"{'Round':>5} | {'T1 density':>10} | {'T1 delta':>10} | {'W[t] density':>12}")
    print("-" * 50)

    for rnd in range(64):
        # T1 bits
        T1_bits = np.zeros((N, 32), dtype=np.uint8)
        W_bits = np.zeros((N, 32), dtype=np.uint8)
        for val in range(N):
            for b in range(32):
                T1_bits[val, b] = (all_t1[val][rnd] >> b) & 1
                W_bits[val, b] = (all_W[val][rnd] >> b) & 1

        # ANF of T1
        t1_nz = 0
        for b in range(32):
            anf = mobius(T1_bits[:, b], N_BITS)
            t1_nz += np.sum(anf)
        t1_density = t1_nz / (N * 32)

        # ANF of W[t] — should be highly structured (linear schedule)
        w_nz = 0
        for b in range(32):
            anf = mobius(W_bits[:, b], N_BITS)
            w_nz += np.sum(anf)
        w_density = w_nz / (N * 32)

        if rnd <= 8 or rnd >= 48 or rnd % 8 == 0:
            print(f"  R={rnd:2d}  | {t1_density*100:9.1f}% | {'':>10} | {w_density*100:11.1f}%")

    # ============================================================
    # EXPERIMENT 3: Learn the DELTA pattern
    # Instead of hash → output, learn: message → state_delta
    # ============================================================
    print(f"\n{'='*70}")
    print("EXP 3: ML on state DELTA (round t vs round t-1)")
    print("=" * 70)

    # For the FIRST few rounds, the delta is sparse.
    # Can we learn it from partial data?
    import itertools

    monomials = []
    for deg in range(N_BITS + 1):
        for combo in itertools.combinations(range(N_BITS), deg):
            monomials.append(combo)

    X_bin = np.zeros((N, N_BITS), dtype=np.uint8)
    for i in range(N):
        X_bin[i] = int_to_bits(i, N_BITS)

    F = np.ones((N, len(monomials)), dtype=np.uint8)
    for j, mono in enumerate(monomials):
        for bi in mono:
            F[:, j] &= X_bin[:, bi]

    for rnd in [1, 2, 3, 4, 8, 48, 56, 60, 62, 63]:
        # Compute delta: state[rnd] XOR state[rnd-1]
        Y_delta = np.zeros((N, 256), dtype=np.uint8)
        for val in range(N):
            s_cur = state_to_bits(all_states[val][rnd])
            s_prev = state_to_bits(all_states[val][rnd - 1])
            Y_delta[val] = s_cur ^ s_prev

        # ANF of delta
        W_delta = np.zeros_like(Y_delta)
        for ob in range(256):
            W_delta[:, ob] = mobius(Y_delta[:, ob], N_BITS)

        total_nz = int(np.sum(W_delta))
        density = total_nz / W_delta.size

        # Degree distribution of delta
        deg_dist = np.zeros(N_BITS + 1)
        for m in range(N):
            deg = bin(m).count('1')
            deg_dist[deg] += np.sum(W_delta[m, :])

        # How many output bits have zero delta (unchanged between rounds)?
        n_zero = sum(1 for ob in range(256) if np.sum(W_delta[:, ob]) == 0)

        # Effective degree
        eff_deg = 0
        for d in range(N_BITS, -1, -1):
            if deg_dist[d] > 0: eff_deg = d; break

        # Can we learn it from 80% data?
        np.random.seed(42)
        perm = np.random.permutation(N)
        n_train = 204
        ti, vi = perm[:n_train], perm[n_train:]

        n_solved = 0
        n_generalized = 0
        for ob in range(256):
            if np.sum(W_delta[:, ob]) == 0:
                n_solved += 1
                n_generalized += 1
                continue
            c = gf2_solve(F[ti], Y_delta[ti, ob])
            if c is not None:
                n_solved += 1
                pred = (F[vi] @ c) % 2
                if np.array_equal(pred, Y_delta[vi, ob]):
                    n_generalized += 1

        print(f"  R={rnd:2d} delta: density={density*100:5.1f}% | "
              f"eff_deg={eff_deg} | zero_bits={n_zero:3d}/256 | "
              f"generalize={n_generalized}/256")

    # ============================================================
    # EXPERIMENT 4: The key test — can we learn JUST the a,e update?
    # ============================================================
    print(f"\n{'='*70}")
    print("EXP 4: ML on JUST the a,e update (the active part of each round)")
    print("=" * 70)
    print("Each round only modifies 2 words: a (=T1+T2) and e (=d+T1)")
    print("The other 6 words just shift. So the 'new information' per round")
    print("is just T1 and T2 — two 32-bit values = 64 bits.\n")

    for rnd in [1, 2, 3, 4, 8, 48, 56, 60, 63]:
        # T1 and T2 as functions of input
        Y_t1t2 = np.zeros((N, 64), dtype=np.uint8)
        for val in range(N):
            t1 = all_t1[val][rnd]
            t2 = all_t2[val][rnd]
            for b in range(32):
                Y_t1t2[val, b] = (t1 >> b) & 1
                Y_t1t2[val, 32 + b] = (t2 >> b) & 1

        # ANF
        W_t1t2 = np.zeros_like(Y_t1t2)
        for ob in range(64):
            W_t1t2[:, ob] = mobius(Y_t1t2[:, ob], N_BITS)

        density = np.sum(W_t1t2) / W_t1t2.size

        # Degree distribution
        deg_dist = np.zeros(N_BITS + 1)
        for m in range(N):
            deg = bin(m).count('1')
            deg_dist[deg] += np.sum(W_t1t2[m, :])

        eff_deg = 0
        for d in range(N_BITS, -1, -1):
            if deg_dist[d] > 0: eff_deg = d; break

        # Generalization test
        n_gen = 0
        for ob in range(64):
            c = gf2_solve(F[ti], Y_t1t2[ti, ob])
            if c is not None:
                pred = (F[vi] @ c) % 2
                if np.array_equal(pred, Y_t1t2[vi, ob]):
                    n_gen += 1

        # T1 vs T2 density
        t1_d = np.sum(W_t1t2[:, :32]) / (N * 32)
        t2_d = np.sum(W_t1t2[:, 32:]) / (N * 32)

        print(f"  R={rnd:2d}: T1={t1_d*100:5.1f}% T2={t2_d*100:5.1f}% | "
              f"eff_deg={eff_deg} | generalize={n_gen}/64")

    # ============================================================
    # EXPERIMENT 5: W[t] schedule values — the LINEAR part
    # ============================================================
    print(f"\n{'='*70}")
    print("EXP 5: Schedule W[t] — the part that SHOULD be learnable")
    print("=" * 70)
    print("W[0..15] come from the message. W[16+] are linear combos.")
    print("Since W[0] directly contains the input byte, W[t>15] should")
    print("be structured functions of the input.\n")

    for rnd in [0, 1, 15, 16, 17, 32, 48, 56, 60, 63]:
        Y_w = np.zeros((N, 32), dtype=np.uint8)
        for val in range(N):
            for b in range(32):
                Y_w[val, b] = (all_W[val][rnd] >> b) & 1

        W_anf = np.zeros_like(Y_w)
        for ob in range(32):
            W_anf[:, ob] = mobius(Y_w[:, ob], N_BITS)

        density = np.sum(W_anf) / W_anf.size

        eff_deg = 0
        for m in range(N):
            deg = bin(m).count('1')
            if np.sum(W_anf[m, :]) > 0:
                eff_deg = max(eff_deg, deg)

        # Generalization
        n_gen = 0
        for ob in range(32):
            c = gf2_solve(F[ti], Y_w[ti, ob])
            if c is not None:
                pred = (F[vi] @ c) % 2
                if np.array_equal(pred, Y_w[vi, ob]):
                    n_gen += 1

        print(f"  W[{rnd:2d}]: density={density*100:5.1f}% | "
              f"eff_deg={eff_deg} | generalize={n_gen}/32")

    # ============================================================
    # SUMMARY
    # ============================================================
    print(f"\n{'='*70}")
    print("SUMMARY: Where is the learnable structure?")
    print("=" * 70)
    print(f"""
  Hash bits (final output):     50% density → 0/256 generalize (random)
  State delta (round-by-round): ~50% at R>4 → 0/256 generalize (random)
  T1/T2 values:                 ~50% at R>2 → 0/64 generalize (random)

  BUT:
  State delta at R=1:           SPARSE → potentially learnable
  T1 at R=0:                    ~1% density → highly structured
  W[t] schedule values:         LINEAR in message bits → fully learnable

  The structure lives in:
  1. The schedule W[t] — linear, fully determined by message
  2. The FIRST 1-2 rounds of T1/T2 — low degree, sparse
  3. The state delta at round 1 — only a,e change

  After round ~3, everything is at 50%. The mixing is THAT fast.
  The useful window is rounds 0-3 from the forward direction,
  and rounds 63-60 from the backward direction (via T1/T2 recovery).
""")

if __name__ == "__main__":
    main()
