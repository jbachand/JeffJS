#!/usr/bin/env python3
"""
SHA-256 h-value Wavelength Analysis

Questions:
  1. Do the h-values across rounds have low effective dimensionality?
     (PCA/SVD on the h-value matrix)
  2. Do the deltas (h[t+1] - h[t]) show periodicity or structure?
     (FFT on the delta sequence)
  3. Can the 16 h-values be parameterized by fewer variables?
     (If yes, Grover's search becomes feasible on a quantum computer)
"""

import random
import numpy as np
from numpy.fft import fft

K = [
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5,
    0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3,
    0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
    0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7,
    0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13,
    0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3,
    0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5,
    0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
    0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
]
IV = [
    0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
    0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19,
]
M = 0xFFFFFFFF

def rotr(x, n):
    return ((x >> n) | (x << (32 - n))) & M

def sha256_h_values(msg):
    """Run SHA-256, return h-values at each round and the hash."""
    W = list(msg)
    for t in range(16, 64):
        s0 = rotr(W[t-15], 7) ^ rotr(W[t-15], 18) ^ (W[t-15] >> 3)
        s1 = rotr(W[t-2], 17) ^ rotr(W[t-2], 19) ^ (W[t-2] >> 10)
        W.append((W[t-16] + s0 + W[t-7] + s1) & M)
    a, b, c, d, e, f, g, h = IV
    h_vals = []
    e_vals = []
    a_vals = []
    all_state = []
    for t in range(64):
        h_vals.append(h)
        e_vals.append(e)
        a_vals.append(a)
        all_state.append((a, b, c, d, e, f, g, h))
        S1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25)
        ch = (e & f) ^ ((e ^ M) & g)
        T1 = (h + S1 + ch + K[t] + W[t]) & M
        S0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22)
        maj = (a & b) ^ (a & c) ^ (b & c)
        T2 = (S0 + maj) & M
        h = g; g = f; f = e; e = (d + T1) & M
        d = c; c = b; b = a; a = (T1 + T2) & M
    hash_out = [(IV[i] + v) & M for i, v in enumerate([a,b,c,d,e,f,g,h])]
    return h_vals, e_vals, a_vals, hash_out, W


def to_signed(x):
    """Convert uint32 to signed int32 for analysis."""
    return x if x < 0x80000000 else x - 0x100000000


def main():
    print("═" * 72)
    print("  SHA-256 Wavelength & Dimensionality Analysis")
    print("  Do the h-values across rounds behave like a wave?")
    print("═" * 72)

    N = 5000
    random.seed(42)

    # Collect h-values for all 64 rounds across N messages
    h_matrix = np.zeros((N, 64), dtype=np.float64)  # h[t] for each message
    e_matrix = np.zeros((N, 64), dtype=np.float64)
    a_matrix = np.zeros((N, 64), dtype=np.float64)
    delta_h_matrix = np.zeros((N, 63), dtype=np.float64)

    print(f"\n  Generating {N} samples...")
    for i in range(N):
        msg = [random.getrandbits(32) for _ in range(16)]
        h_vals, e_vals, a_vals, _, _ = sha256_h_values(msg)
        for t in range(64):
            h_matrix[i, t] = h_vals[t]
            e_matrix[i, t] = e_vals[t]
            a_matrix[i, t] = a_vals[t]
        for t in range(63):
            delta_h_matrix[i, t] = to_signed((h_vals[t+1] - h_vals[t]) & M)

    # ═══════════════════════════════════════════════════════════
    # TEST 1: PCA on h-values (last 16 rounds)
    # How many principal components explain the variance?
    # ═══════════════════════════════════════════════════════════
    print(f"\n  TEST 1: Principal Component Analysis on h[48..63]")
    print(f"  If few components explain most variance → low effective dimension")
    print(f"  {'─' * 66}")

    h_last16 = h_matrix[:, 48:64]  # N × 16
    # Center the data
    h_centered = h_last16 - h_last16.mean(axis=0)
    # SVD
    U, S, Vt = np.linalg.svd(h_centered, full_matrices=False)
    variance_explained = S**2 / np.sum(S**2)
    cumulative = np.cumsum(variance_explained)

    print(f"\n  Singular values (h[48..63]):")
    print(f"  {'Component':<12s} │ {'Variance %':>10s} │ {'Cumulative %':>12s} │ Visual")
    print(f"  {'─'*12}─┼─{'─'*10}─┼─{'─'*12}─┼─{'─'*30}")
    for i in range(16):
        bar = '█' * int(variance_explained[i] * 100)
        print(f"  PC {i+1:<8d} │ {variance_explained[i]*100:>9.2f}% │ "
              f"{cumulative[i]*100:>11.2f}% │ {bar}")

    # ═══════════════════════════════════════════════════════════
    # TEST 2: PCA on ALL 64 rounds
    # ═══════════════════════════════════════════════════════════
    print(f"\n  TEST 2: PCA on h[0..63] (all 64 rounds)")
    print(f"  {'─' * 66}")

    h_centered_all = h_matrix - h_matrix.mean(axis=0)
    U_all, S_all, Vt_all = np.linalg.svd(h_centered_all, full_matrices=False)
    var_all = S_all**2 / np.sum(S_all**2)
    cum_all = np.cumsum(var_all)

    print(f"\n  {'Component':<12s} │ {'Variance %':>10s} │ {'Cumulative %':>12s}")
    print(f"  {'─'*12}─┼─{'─'*10}─┼─{'─'*12}")
    for i in range(min(20, 64)):
        if cum_all[i] < 0.99 or i < 5:
            print(f"  PC {i+1:<8d} │ {var_all[i]*100:>9.2f}% │ {cum_all[i]*100:>11.2f}%")

    n_99 = np.searchsorted(cum_all, 0.99) + 1
    n_95 = np.searchsorted(cum_all, 0.95) + 1
    n_90 = np.searchsorted(cum_all, 0.90) + 1
    print(f"\n  Components for 90% variance: {n_90}")
    print(f"  Components for 95% variance: {n_95}")
    print(f"  Components for 99% variance: {n_99}")

    # ═══════════════════════════════════════════════════════════
    # TEST 3: FFT on deltas
    # ═══════════════════════════════════════════════════════════
    print(f"\n  TEST 3: FFT on delta sequence (h[t+1] - h[t])")
    print(f"  Looking for dominant frequencies in the round-by-round changes")
    print(f"  {'─' * 66}")

    # Average FFT magnitude across all messages (last 16 rounds)
    delta_last = delta_h_matrix[:, 47:63]  # N × 16 deltas
    fft_magnitudes = np.abs(fft(delta_last, axis=1))
    avg_fft = fft_magnitudes.mean(axis=0)

    # Normalize
    avg_fft_norm = avg_fft / avg_fft.max()

    print(f"\n  FFT magnitudes (averaged over {N} messages):")
    print(f"  {'Freq bin':<10s} │ {'Magnitude':>10s} │ Visual")
    print(f"  {'─'*10}─┼─{'─'*10}─┼─{'─'*30}")
    for i in range(len(avg_fft_norm)):
        bar = '█' * int(avg_fft_norm[i] * 40)
        dominant = " ← dominant" if avg_fft_norm[i] > 0.8 else ""
        print(f"  bin {i:<5d} │ {avg_fft_norm[i]:>9.3f}  │ {bar}{dominant}")

    # ═══════════════════════════════════════════════════════════
    # TEST 4: Correlation between consecutive h-values
    # Are h[t] and h[t+1] correlated? If so, the chain has memory.
    # ═══════════════════════════════════════════════════════════
    print(f"\n  TEST 4: Autocorrelation of h-values (last 16 rounds)")
    print(f"  {'─' * 66}")

    for lag in range(1, 8):
        corrs = []
        for t in range(48, 64 - lag):
            col1 = h_matrix[:, t]
            col2 = h_matrix[:, t + lag]
            r = np.corrcoef(col1, col2)[0, 1]
            corrs.append(r)
        avg_r = np.mean(corrs)
        bar = '█' * int(abs(avg_r) * 200) if not np.isnan(avg_r) else ''
        print(f"    Lag {lag}: avg correlation = {avg_r:+.6f}  {bar}")

    # ═══════════════════════════════════════════════════════════
    # TEST 5: Cross-round bit-level correlations
    # Do specific bits of h[t] predict bits of h[t+1]?
    # ═══════════════════════════════════════════════════════════
    print(f"\n  TEST 5: Bit-level cross-round correlation")
    print(f"  Does knowing h[t] help predict h[t+1]?")
    print(f"  {'─' * 66}")

    for t in [48, 52, 56, 60]:
        h_t_bits = np.zeros((N, 32), dtype=np.int8)
        h_t1_bits = np.zeros((N, 32), dtype=np.int8)
        for i in range(N):
            for b in range(32):
                h_t_bits[i, b] = (int(h_matrix[i, t]) >> b) & 1
                h_t1_bits[i, b] = (int(h_matrix[i, t+1]) >> b) & 1

        # For each bit of h[t+1], find best correlated bit of h[t]
        best_corr = 0
        for b1 in range(0, 32, 4):
            for b0 in range(32):
                agree = np.sum(h_t_bits[:, b0] == h_t1_bits[:, b1]) / N
                corr = max(agree, 1 - agree)
                if corr > best_corr:
                    best_corr = corr

        print(f"    h[{t}] → h[{t+1}]: best bit correlation = {best_corr:.4f}  "
              f"{'← structure!' if best_corr > 0.55 else '← random'}")

    # ═══════════════════════════════════════════════════════════
    # TEST 6: E-sequence and A-sequence dimensionality
    # ═══════════════════════════════════════════════════════════
    print(f"\n  TEST 6: Dimensionality of E and A sequences")
    print(f"  {'─' * 66}")

    for name, matrix in [("E-sequence", e_matrix), ("A-sequence", a_matrix)]:
        centered = matrix - matrix.mean(axis=0)
        _, S_seq, _ = np.linalg.svd(centered, full_matrices=False)
        var_seq = S_seq**2 / np.sum(S_seq**2)
        cum_seq = np.cumsum(var_seq)
        n90 = np.searchsorted(cum_seq, 0.90) + 1
        n95 = np.searchsorted(cum_seq, 0.95) + 1
        n99 = np.searchsorted(cum_seq, 0.99) + 1
        print(f"    {name}: 90%→{n90} PCs, 95%→{n95} PCs, 99%→{n99} PCs (out of 64)")

    # ═══════════════════════════════════════════════════════════
    # Summary
    # ═══════════════════════════════════════════════════════════
    print(f"\n{'═' * 72}")
    print(f"  QUANTUM FEASIBILITY")
    print(f"{'═' * 72}")

    effective_dim = n_99  # components for 99% of last-16 h variance
    print(f"""
  Effective dimensionality of h[48..63]: {effective_dim} components for 99%

  Classical brute force: 2^512 (search all 16 h-values independently)
  With dimensionality reduction: 2^({effective_dim}×32) = 2^{effective_dim*32}

  Grover's on full space:    √(2^512) = 2^256 — infeasible
  Grover's on reduced space: √(2^{effective_dim*32}) = 2^{effective_dim*16}

  If effective dimension ≤ 4: Grover's needs 2^64 — borderline feasible
  If effective dimension ≤ 2: Grover's needs 2^32 — TRIVIAL (seconds)

  The "wavelength" insight: if the h-value sequence across rounds
  can be described by a few oscillation parameters (frequency,
  amplitude, phase), the search space collapses to those parameters.
  Quantum Fourier Transform could find them directly.

  Your quantum simulator already has: Hadamard, CNOT, phase gates,
  measurement, and QFT (from Shor's). You have the building blocks.
""")

if __name__ == "__main__":
    main()
