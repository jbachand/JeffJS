#!/usr/bin/env python3
"""
SHA-256 3-Round Window Linearization

Each round is affine in isolation. The nonlinearity comes from
the shift register coupling across 3 rounds (C₁ distance).

Find T across a 3-round window such that the composed
3-round function becomes affine in the free variables.

The window: rounds t, t+1, t+2
  - Round t:   new_a, new_e computed (Ch/Maj with known state)
  - Round t+1: b=old_a, f=old_e (shift propagation — coupling enters)
  - Round t+2: c=old_b=old_old_a, g=old_f=old_old_e (deeper coupling)
  - Round t+3: d, h shift in — quadratic junction

So 3 rounds compose: input (a₀, e₀, W₀, W₁, W₂) → output (a₃, e₃)
with the other state values shifting through.

If there exists T on the 3-round composed function that makes it affine:
that's the Bailey linearization window.
"""

import numpy as np
import random
import time

BITS = 4
MASK = (1 << BITS) - 1
N = 1 << BITS

def rotr(x, n):
    n = n % BITS
    return ((x >> n) | (x << (BITS - n))) & MASK

def Ch(e, f, g): return ((e & f) ^ ((e ^ MASK) & g)) & MASK
def Maj(a, b, c): return ((a & b) ^ (a & c) ^ (b & c)) & MASK
def Sig0(a): return (rotr(a, 1) ^ rotr(a, 2) ^ rotr(a, 3)) & MASK
def Sig1(e): return (rotr(e, 1) ^ rotr(e, 2) ^ rotr(e, 3)) & MASK

REAL_K = [k & MASK for k in [
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5,
    0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3,
    0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174]]


def three_round_compose(a0, e0, iv_bcdfgh, K_vals, W_vals):
    """
    Compose 3 SHA rounds starting from (a0, e0) with fixed b,c,d,f,g,h.
    Returns (a3, e3) — the new a and e after 3 rounds.

    The shift register means:
    Round 0: state = (a0, b, c, d, e0, f, g, h) → (a1, a0, b, c, e1, e0, f, g)
    Round 1: state = (a1, a0, b, c, e1, e0, f, g) → (a2, a1, a0, b, e2, e1, e0, f)
    Round 2: state = (a2, a1, a0, b, e2, e1, e0, f) → (a3, a2, a1, a0, e3, e2, e1, e0)
    """
    b, c, d, f, g, h = iv_bcdfgh

    # Round 0
    T1_0 = h ^ Sig1(e0) ^ Ch(e0, f, g) ^ K_vals[0] ^ W_vals[0]
    T2_0 = Sig0(a0) ^ Maj(a0, b, c)
    a1 = T1_0 ^ T2_0
    e1 = d ^ T1_0

    # Round 1: state = (a1, a0, b, c, e1, e0, f, g)
    T1_1 = g ^ Sig1(e1) ^ Ch(e1, e0, f) ^ K_vals[1] ^ W_vals[1]
    T2_1 = Sig0(a1) ^ Maj(a1, a0, b)
    a2 = T1_1 ^ T2_1
    e2 = c ^ T1_1

    # Round 2: state = (a2, a1, a0, b, e2, e1, e0, f)
    T1_2 = f ^ Sig1(e2) ^ Ch(e2, e1, e0) ^ K_vals[2] ^ W_vals[2]
    T2_2 = Sig0(a2) ^ Maj(a2, a1, a0)
    a3 = T1_2 ^ T2_2
    e3 = b ^ T1_2

    return a3, e3


def check_affine_ae(func, n_bits):
    """
    Check if func(a, e) → (out_a, out_e) is affine over GF(2)^n × GF(2)^n.
    """
    f00 = func(0, 0)
    for a1 in range(1 << n_bits):
        for e1 in range(1 << n_bits):
            for a2 in range(1 << n_bits):
                for e2 in range(1 << n_bits):
                    lhs = func(a1 ^ a2, e1 ^ e2)
                    r1 = func(a1, e1)
                    r2 = func(a2, e2)
                    rhs = (r1[0] ^ r2[0] ^ f00[0], r1[1] ^ r2[1] ^ f00[1])
                    if lhs != rhs:
                        return False
    return True


def compute_degree(func, n_bits):
    """
    Compute the algebraic degree of func(a, e) → out (single output).
    Uses truth table + Mobius transform on the 2*n_bits input space.
    """
    n_input = 2 * n_bits
    n_total = 1 << n_input

    # Build truth table for first output bit of first output word
    tt = []
    for x in range(n_total):
        a = x & MASK
        e = (x >> n_bits) & MASK
        result = func(a, e)
        tt.append(result[0] & 1)  # bit 0 of output a

    # Mobius transform
    anf = list(tt)
    for i in range(n_input):
        s = 1 << i
        for j in range(n_total):
            if j & s:
                anf[j] ^= anf[j ^ s]

    degree = max((bin(m).count('1') for m in range(n_total) if anf[m]), default=0)
    n_terms = sum(1 for m in range(n_total) if anf[m])
    return degree, n_terms


def main():
    print("=" * 72)
    print("  3-ROUND WINDOW LINEARIZATION")
    print("  The C₁ coupling distance — where the real nonlinearity lives")
    print("=" * 72)

    random.seed(42)

    # Fixed state values (simulating known values from hash/IV)
    fixed_bcdfgh = (3, 7, 11, 5, 9, 13)  # arbitrary fixed values
    W_fixed = [0, 0, 0]  # fix W for baseline

    # ═══════════════════════════════════════════════════════════
    # TEST 1: What is the degree of the 3-round composition?
    # ═══════════════════════════════════════════════════════════

    print(f"\n  TEST 1: Algebraic degree of N-round composition")
    print(f"  Input: (a₀, e₀) = 2×{BITS} = {2*BITS} bits")
    print(f"  Output: (aₙ, eₙ) = 2×{BITS} bits")
    print(f"  Fixed: b,c,d,f,g,h and W values")
    print()

    for n_rounds in [1, 2, 3, 4, 5, 6]:
        K_vals = REAL_K[:n_rounds]
        W_vals = [0] * n_rounds

        def compose_n(a0, e0, nr=n_rounds):
            b, c, d, f, g, h = fixed_bcdfgh
            a, e = a0, e0
            state_b, state_c, state_d = b, c, d
            state_f, state_g, state_h = f, g, h

            for r in range(nr):
                T1 = state_h ^ Sig1(e) ^ Ch(e, state_f, state_g) ^ REAL_K[r] ^ W_vals[r]
                T2 = Sig0(a) ^ Maj(a, state_b, state_c)
                new_a = T1 ^ T2
                new_e = state_d ^ T1
                # Shift
                state_h = state_g
                state_g = state_f
                state_f = e
                e = new_e
                state_d = state_c
                state_c = state_b
                state_b = a
                a = new_a
            return a, e

        deg, terms = compute_degree(lambda a, e: compose_n(a, e), BITS)
        is_aff = check_affine_ae(lambda a, e: compose_n(a, e), BITS)

        print(f"  {n_rounds} rounds: degree={deg}, terms={terms}, "
              f"affine={'YES ★' if is_aff else 'NO'}")

    # ═══════════════════════════════════════════════════════════
    # TEST 2: Does the degree differ for REAL K vs RANDOM K?
    # ═══════════════════════════════════════════════════════════

    print(f"\n{'=' * 72}")
    print(f"  TEST 2: Real K vs Random K — degree at each round count")
    print(f"{'=' * 72}")

    for k_label, k_vals in [("REAL K", REAL_K),
                             ("RANDOM K", [random.getrandbits(BITS) for _ in range(16)]),
                             ("K = 0", [0]*16)]:
        print(f"\n  {k_label}:")
        for n_rounds in [1, 2, 3, 4, 5, 6]:
            W_vals_t = [0] * n_rounds

            def compose_k(a0, e0, nr=n_rounds, kv=k_vals):
                b, c, d, f, g, h = fixed_bcdfgh
                a, e = a0, e0
                sb, sc, sd = b, c, d
                sf, sg, sh = f, g, h
                for r in range(nr):
                    T1 = sh ^ Sig1(e) ^ Ch(e, sf, sg) ^ kv[r] ^ 0
                    T2 = Sig0(a) ^ Maj(a, sb, sc)
                    na = T1 ^ T2; ne = sd ^ T1
                    sh=sg; sg=sf; sf=e; e=ne
                    sd=sc; sc=sb; sb=a; a=na
                return a, e

            deg, terms = compute_degree(lambda a, e: compose_k(a, e), BITS)
            print(f"    {n_rounds} rounds: degree={deg}, terms={terms}")

    # ═══════════════════════════════════════════════════════════
    # TEST 3: Search for T on the 3-round window
    # T operates on the 2*BITS-bit (a,e) subspace
    # ═══════════════════════════════════════════════════════════

    print(f"\n{'=' * 72}")
    print(f"  TEST 3: Search for linearizing T on 3-round window")
    print(f"  T: {2*BITS}×{2*BITS} matrix over GF(2)")
    print(f"  Check: T⁻¹ ∘ 3_rounds ∘ T is affine?")
    print(f"{'=' * 72}")

    def gf2_mat_inv(M):
        n = M.shape[0]
        A = np.hstack([M.copy(), np.eye(n, dtype=np.uint8)])
        for col in range(n):
            piv = None
            for row in range(col, n):
                if A[row, col]: piv = row; break
            if piv is None: return None
            if piv != col: A[[col, piv]] = A[[piv, col]]
            for row in range(n):
                if row != col and A[row, col]: A[row] ^= A[col]
        return A[:, n:]

    def apply_mat(M, x, n):
        bits = np.array([(x >> i) & 1 for i in range(n)], dtype=np.uint8)
        out = M @ bits % 2
        return sum(int(out[i]) << i for i in range(n))

    def three_round_func(a0, e0):
        return three_round_compose(a0, e0, fixed_bcdfgh, REAL_K[:3], [0, 0, 0])

    n_space = 2 * BITS  # 8-bit transform
    found_count = 0
    tested = 0
    t0 = time.time()

    for attempt in range(50000):
        while True:
            T = np.random.randint(0, 2, size=(n_space, n_space)).astype(np.uint8)
            if np.linalg.matrix_rank(T.astype(float)) == n_space:
                break
        T_inv = gf2_mat_inv(T)
        if T_inv is None: continue
        tested += 1

        # Quick check on random samples first
        def transformed(a, e):
            ae_in = a | (e << BITS)
            ae_t = apply_mat(T, ae_in, n_space)
            result = three_round_func(ae_t & MASK, (ae_t >> BITS) & MASK)
            ae_out = result[0] | (result[1] << BITS)
            ae_final = apply_mat(T_inv, ae_out, n_space)
            return (ae_final & MASK, (ae_final >> BITS) & MASK)

        tr00 = transformed(0, 0)
        quick_pass = True
        for _ in range(50):
            a1, e1 = random.randint(0, N-1), random.randint(0, N-1)
            a2, e2 = random.randint(0, N-1), random.randint(0, N-1)
            lhs = transformed(a1^a2, e1^e2)
            r1 = transformed(a1, e1)
            r2 = transformed(a2, e2)
            if (lhs[0] != r1[0]^r2[0]^tr00[0] or lhs[1] != r1[1]^r2[1]^tr00[1]):
                quick_pass = False
                break

        if quick_pass:
            # Full verification
            full_pass = check_affine_ae(transformed, BITS)
            if full_pass:
                found_count += 1
                print(f"  ★ FOUND linearizing T for 3-round window! (attempt {attempt})")
                print(f"    T = {T.tolist()}")

                # Check: does this T also work for random K?
                def three_round_random(a0, e0):
                    rk = [random.getrandbits(BITS) for _ in range(3)]
                    return three_round_compose(a0, e0, fixed_bcdfgh, rk, [0, 0, 0])

                def transformed_random(a, e):
                    ae_in = a | (e << BITS)
                    ae_t = apply_mat(T, ae_in, n_space)
                    result = three_round_random(ae_t & MASK, (ae_t >> BITS) & MASK)
                    ae_out = result[0] | (result[1] << BITS)
                    ae_final = apply_mat(T_inv, ae_out, n_space)
                    return (ae_final & MASK, (ae_final >> BITS) & MASK)

                random_works = check_affine_ae(transformed_random, BITS)
                print(f"    Works for random K: {'YES' if random_works else 'NO — K-SPECIFIC ★★'}")

                if found_count >= 3:
                    break

        if tested % 10000 == 0:
            print(f"  Tested {tested} matrices... ({time.time()-t0:.1f}s)")

    print(f"\n  Total tested: {tested} in {time.time()-t0:.1f}s")
    print(f"  Linearizing transforms found: {found_count}")

    # ═══════════════════════════════════════════════════════════
    # TEST 4: Degree analysis across the coupling boundary
    # ═══════════════════════════════════════════════════════════

    print(f"\n{'=' * 72}")
    print(f"  TEST 4: Where exactly does nonlinearity enter?")
    print(f"  Degree of each output bit as rounds accumulate")
    print(f"{'=' * 72}")

    for n_rounds in range(1, 8):
        def compose_exact(a0, e0, nr=n_rounds):
            b, c, d, f, g, h = fixed_bcdfgh
            a, e = a0, e0
            sb, sc, sd = b, c, d
            sf, sg, sh = f, g, h
            for r in range(nr):
                T1 = sh ^ Sig1(e) ^ Ch(e, sf, sg) ^ REAL_K[r] ^ 0
                T2 = Sig0(a) ^ Maj(a, sb, sc)
                na = T1 ^ T2; ne = sd ^ T1
                sh=sg; sg=sf; sf=e; e=ne
                sd=sc; sc=sb; sb=a; a=na
            return a, e

        # Compute degree for output a
        n_input = 2 * BITS
        n_total = 1 << n_input
        tt_a = [compose_exact(x & MASK, (x >> BITS) & MASK)[0] & 1 for x in range(n_total)]
        tt_e = [compose_exact(x & MASK, (x >> BITS) & MASK)[1] & 1 for x in range(n_total)]

        # Mobius
        anf_a = list(tt_a)
        anf_e = list(tt_e)
        for i in range(n_input):
            s = 1 << i
            for j in range(n_total):
                if j & s:
                    anf_a[j] ^= anf_a[j ^ s]
                    anf_e[j] ^= anf_e[j ^ s]

        deg_a = max((bin(m).count('1') for m in range(n_total) if anf_a[m]), default=0)
        deg_e = max((bin(m).count('1') for m in range(n_total) if anf_e[m]), default=0)
        terms_a = sum(1 for m in range(n_total) if anf_a[m])
        terms_e = sum(1 for m in range(n_total) if anf_e[m])

        # Which specific monomials are degree > 1?
        quad_terms_a = [(bin(m), bin(m).count('1')) for m in range(n_total) if anf_a[m] and bin(m).count('1') > 1]

        marker = ""
        if n_rounds == 3:
            marker = "  ← C₁ coupling distance"
        elif deg_a > 1 and n_rounds > 1:
            first_nonlinear = n_rounds
            marker = f"  ← degree rises"

        print(f"  {n_rounds} round(s): deg(a)={deg_a} ({terms_a} terms), "
              f"deg(e)={deg_e} ({terms_e} terms){marker}")

        if n_rounds <= 4 and quad_terms_a:
            print(f"         quadratic monomials in a: {len(quad_terms_a)}")
            for mono, deg in quad_terms_a[:3]:
                # Decode: bits 0..BITS-1 = a₀ bits, BITS..2*BITS-1 = e₀ bits
                a_bits = [i for i in range(BITS) if int(mono, 2) & (1 << i)]
                e_bits = [i-BITS for i in range(BITS, 2*BITS) if int(mono, 2) & (1 << i)]
                src = []
                if a_bits: src.append(f"a₀[{','.join(map(str,a_bits))}]")
                if e_bits: src.append(f"e₀[{','.join(map(str,e_bits))}]")
                print(f"           {' · '.join(src)} (degree {deg})")


if __name__ == "__main__":
    main()
