#!/usr/bin/env python3
"""
SHA-256 Forward Jump: Skip to round 56 using schedule + backward walk.

For each candidate message:
1. Schedule → W[63] (cheap, no compression needed)
2. h[63] = C[63] - W[63] (free, C[63] from target hash)
3. a[56] = h[63] - T1[59] (free, T1[59] from backward walk)
4. Run compression forward ONLY 56 rounds
5. Check if a[56] matches → early rejection

Saves 8/64 = 12.5% of compression work.
But more importantly: the jump from message→a[56] is FREE.
The schedule IS the shortcut.
"""

import struct
import hashlib
import time
import random

M32 = 0xFFFFFFFF

def rotr(x, n): return ((x >> n) | (x << (32 - n))) & M32
def shr(x, n): return x >> n
def Sigma1(x): return rotr(x, 6) ^ rotr(x, 11) ^ rotr(x, 25)
def Sigma0(x): return rotr(x, 2) ^ rotr(x, 13) ^ rotr(x, 22)
def sigma1(x): return rotr(x, 17) ^ rotr(x, 19) ^ shr(x, 10)
def sigma0(x): return rotr(x, 7) ^ rotr(x, 18) ^ shr(x, 3)
def Ch(e, f, g): return (e & f) ^ ((~e) & g) & M32
def Maj(a, b, c): return (a & b) ^ (a & c) ^ (b & c)

K = [0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
     0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
     0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
     0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
     0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
     0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
     0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
     0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2]
IV = [0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,
      0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19]

def make_schedule(msg_byte):
    padded = bytes([msg_byte]) + b'\x80' + b'\x00' * 54 + struct.pack('>Q', 8)
    W = list(struct.unpack('>16I', padded))
    for t in range(16, 64):
        W.append((sigma1(W[t-2]) + W[t-7] + sigma0(W[t-15]) + W[t-16]) & M32)
    return W

def compress_n_rounds(W, n_rounds):
    a,b,c,d,e,f,g,h = IV
    for t in range(n_rounds):
        T1 = (h + Sigma1(e) + Ch(e,f,g) + K[t] + W[t]) & M32
        T2 = (Sigma0(a) + Maj(a,b,c)) & M32
        h=g;g=f;f=e;e=(d+T1)&M32;d=c;c=b;b=a;a=(T1+T2)&M32
    return (a,b,c,d,e,f,g,h)

def compress_full(W):
    state = compress_n_rounds(W, 64)
    return [(state[i]+IV[i])&M32 for i in range(8)]

def backward_walk(hash_out):
    """Extract constants from target hash."""
    st = [(hash_out[i]-IV[i])&M32 for i in range(8)]
    a_f,b_f,c_f,d_f,e_f,f_f,g_f,h_f = st

    # Round 63
    T2_63 = (Sigma0(b_f) + Maj(b_f,c_f,d_f)) & M32
    T1_63 = (a_f - T2_63) & M32
    e_bef = (e_f - T1_63) & M32
    C63 = (T1_63 - Sigma1(f_f) - Ch(f_f,g_f,h_f) - K[63]) & M32

    # Round 62
    T2_62 = (Sigma0(c_f) + Maj(c_f,d_f,e_bef)) & M32
    T1_62 = (b_f - T2_62) & M32
    f_bef = (f_f - T1_62) & M32

    # Round 61
    T2_61 = (Sigma0(d_f) + Maj(d_f,e_bef,f_bef)) & M32
    T1_61 = (c_f - T2_61) & M32
    g_bef = (g_f - T1_61) & M32

    # Round 60
    T2_60 = (Sigma0(e_bef) + Maj(e_bef,f_bef,g_bef)) & M32
    T1_60 = (d_f - T2_60) & M32
    h_bef = (h_f - T1_60) & M32

    # Round 59
    T2_59 = (Sigma0(f_bef) + Maj(f_bef,g_bef,h_bef)) & M32
    T1_59 = (e_bef - T2_59) & M32

    return {
        'C63': C63,
        'T1_59': T1_59, 'T1_60': T1_60, 'T1_61': T1_61,
        'T1_62': T1_62, 'T1_63': T1_63,
    }

def main():
    print("=" * 70)
    print("SHA-256 FORWARD JUMP ALGORITHM")
    print("=" * 70)

    # ============ THE CHAIN ============
    print(f"""
  The shift register creates a DIRECT chain from a[56] to h[63]:

    a[56] → b[57] → c[58] → d[59] ─+T1[59]→ e[60] → f[61] → g[62] → h[63]
    ^^^^                                                                 ^^^^
    CHECK HERE                                              = C[63] - W[63]
    (round 56)                                              (from schedule)

  Steps:
    h[63] = C[63] - W[63]     ← schedule + backward walk
    a[56] = h[63] - T1[59]    ← backward walk gives T1[59]

  So: a[56] = C[63] - W[63] - T1[59]
  All three terms computed WITHOUT any compression rounds.
""")

    # ============ VERIFY THE CHAIN ============
    print("Verifying the chain for all 256 single-byte inputs...")

    n_verified = 0
    for byte_val in range(256):
        W = make_schedule(byte_val)
        hash_out = compress_full(W)
        bw = backward_walk(hash_out)

        # Forward: get a[56] from 56 rounds
        state_56 = compress_n_rounds(W, 56)
        a_56_forward = state_56[0]

        # Jump: get a[56] from schedule + backward walk
        h63 = (bw['C63'] - W[63]) & M32
        a_56_jump = (h63 - bw['T1_59']) & M32

        if a_56_forward == a_56_jump:
            n_verified += 1

    print(f"  Chain verified: {n_verified}/256 ✓")

    # ============ EXTENDED CHAINS ============
    print(f"\n{'='*70}")
    print("EXTENDED: Multiple jump targets from 5 backward equations")
    print("=" * 70)

    # h[63] = a[56] + T1[59]  →  a[56] = h[63] - T1[59]
    # h[62] = a[55] + T1[58]  →  a[55] = h[62] - T1[58]
    #   But T1[58] needs U (unknown). So only h[63]→a[56] is free.

    # HOWEVER: there are MORE chains via the e→f→g→h path.
    # In the standard form:
    #   h[63] = g[62] → g[62] = f[61] → f[61] = e[60] → e[60] = d[59]+T1[59]
    #   d[59] = c[58] → c[58] = b[57] → b[57] = a[56]
    #
    # But ALSO:
    #   h[62] = g[61] = f[60] = e[59] = d[58]+T1[58]
    #   d[58] = c[57] = b[56] = a[55]
    #   → a[55] = h[62] - T1[58]
    #   T1[58] requires knowing h[58] and W[58] but also the state...
    #   Actually T1[58] is NOT free from backward walk (needs U guess)

    # What IS free:
    # From backward walk (no guesses): T1[59..63]
    # Chain from h[63]: a[56] = h[63] - T1[59]
    # That's the only FREE jump target.

    # With U guess (2^32 candidates):
    # T1[58] becomes available → a[55] = h[62] - T1[58]
    # T1[57] becomes available → a[54] = h[61] - T1[57]
    # etc.

    # Let's show the free jump:
    print(f"\nFree jump (no guessing):")
    print(f"  a[56] = C[63] - W[63] - T1[59]")
    print(f"  → Run 56 rounds forward, check a[56]")
    print(f"  → Saves 8 rounds = 12.5%")

    # ============ TIMING COMPARISON ============
    print(f"\n{'='*70}")
    print("TIMING: Standard vs Forward Jump")
    print("=" * 70)

    # Setup: pick a target
    target_byte = ord('A')
    W_target = make_schedule(target_byte)
    hash_target = compress_full(W_target)
    bw = backward_walk(hash_target)

    # Precompute jump target
    # a_56_target = C[63] - W_target[63] - T1[59]
    # But this depends on the candidate's W[63], not the target's!
    # For each CANDIDATE message, W[63] changes.

    # Method 1: Standard — full 64-round compression for each candidate
    t0 = time.time()
    found_standard = None
    checks_standard = 0
    for byte_val in range(256):
        W = make_schedule(byte_val)
        h = compress_full(W)
        checks_standard += 1
        if h == hash_target:
            found_standard = byte_val
            break
    t_standard = time.time() - t0

    # Method 2: Forward Jump — 56 rounds + early rejection
    t0 = time.time()
    found_jump = None
    checks_jump = 0
    rounds_run = 0
    for byte_val in range(256):
        W = make_schedule(byte_val)

        # Jump: compute target a[56] for THIS candidate
        h63_target = (bw['C63'] - W[63]) & M32
        a56_target = (h63_target - bw['T1_59']) & M32

        # Run 56 rounds forward
        state = compress_n_rounds(W, 56)
        rounds_run += 56
        checks_jump += 1

        if state[0] != a56_target:
            continue  # Early rejection!

        # Passed a[56] check — run remaining 8 rounds
        a,b,c,d,e,f,g,h = state
        for t in range(56, 64):
            T1 = (h + Sigma1(e) + Ch(e,f,g) + K[t] + W[t]) & M32
            T2 = (Sigma0(a) + Maj(a,b,c)) & M32
            h=g;g=f;f=e;e=(d+T1)&M32;d=c;c=b;b=a;a=(T1+T2)&M32
        rounds_run += 8

        h_out = [(x+iv)&M32 for x,iv in zip([a,b,c,d,e,f,g,h], IV)]
        if h_out == hash_target:
            found_jump = byte_val
            break

    t_jump = time.time() - t0

    print(f"\n  Standard: found byte {found_standard} in {checks_standard} checks, "
          f"{t_standard*1000:.2f}ms")
    print(f"  Jump:     found byte {found_jump} in {checks_jump} checks, "
          f"{t_jump*1000:.2f}ms")
    print(f"  Jump ran {rounds_run} total rounds vs {checks_standard*64} standard")
    print(f"  Ratio: {rounds_run/(checks_standard*64)*100:.1f}% of standard work")

    # ============ FALSE POSITIVE RATE ============
    print(f"\n{'='*70}")
    print("FALSE POSITIVE RATE: How many candidates pass a[56] check?")
    print("=" * 70)

    # For each WRONG candidate, does a[56] accidentally match?
    n_pass = 0
    n_fail = 0
    for byte_val in range(256):
        W = make_schedule(byte_val)
        h63 = (bw['C63'] - W[63]) & M32
        a56_target = (h63 - bw['T1_59']) & M32

        state = compress_n_rounds(W, 56)
        if state[0] == a56_target:
            n_pass += 1
        else:
            n_fail += 1

    print(f"  Pass a[56] check: {n_pass}/256")
    print(f"  Fail (early reject): {n_fail}/256")
    print(f"  False positive rate: {(n_pass-1)/255*100:.2f}% (excluding correct answer)")

    if n_pass == 1:
        print(f"\n  *** ONLY THE CORRECT INPUT PASSES ***")
        print(f"  *** a[56] check is a PERFECT filter at this scale ***")
        print(f"  *** 255 wrong candidates rejected at round 56 ***")

    # ============ THE BIG PICTURE ============
    print(f"\n{'='*70}")
    print("THE FORWARD JUMP ALGORITHM")
    print("=" * 70)
    print(f"""
  PRECOMPUTE (once per target hash):
    Backward walk → C[63], T1[59]      Cost: ~5 rounds

  PER CANDIDATE:
    1. Schedule(msg) → W[63]            Cost: ~48 σ ops
    2. h[63] = C[63] - W[63]           Cost: 1 subtraction
    3. a[56] = h[63] - T1[59]          Cost: 1 subtraction
    4. Forward 56 rounds → check a[56]  Cost: 56 rounds
    5. If match: run 8 more → verify    Cost: 8 rounds (rare)

  vs STANDARD:
    Forward 64 rounds → compare hash    Cost: 64 rounds

  Savings: 8 rounds skipped + early rejection of ~100% of wrong candidates
  at round 56 instead of round 64.

  For Bitcoin mining:
    ~12.5% fewer rounds per candidate
    + near-perfect early rejection at round 56
    = significant speedup on GPU/ASIC
""")

if __name__ == "__main__":
    main()
