#!/usr/bin/env python3
"""
SHA-256 unrolled backward walk analysis.
Key question: at round 61 in unrolled form, h appears in Ch(h,a,b).
Is h KNOWN from the hash output? If so, we get 3 rounds where Ch is AFFINE
in the unknowns (not just 1).

The unrolled form eliminates the shift register. Each round modifies exactly
2 of 8 variables. The modification pattern has period 8:

r=0: d += T1, h = T1+T2    (modifies d, h)
r=1: c += T1, g = T1+T2    (modifies c, g)
r=2: b += T1, f = T1+T2    (modifies b, f)
r=3: a += T1, e = T1+T2    (modifies a, e)
r=4: h += T1, d = T1+T2    (modifies h, d)
r=5: g += T1, c = T1+T2    (modifies g, c)
r=6: f += T1, b = T1+T2    (modifies f, b)
r=7: e += T1, a = T1+T2    (modifies e, a)
"""

import hashlib, struct, sys

M32 = 0xFFFFFFFF

def rotr(x, n): return ((x >> n) | (x << (32 - n))) & M32
def shr(x, n): return x >> n

def Sigma1(x): return rotr(x, 6) ^ rotr(x, 11) ^ rotr(x, 25)
def Sigma0(x): return rotr(x, 2) ^ rotr(x, 13) ^ rotr(x, 22)
def sigma1(x): return rotr(x, 17) ^ rotr(x, 19) ^ shr(x, 10)
def sigma0(x): return rotr(x, 7) ^ rotr(x, 18) ^ shr(x, 3)
def Ch(e, f, g): return (e & f) ^ (~e & g) & M32
def Maj(a, b, c): return (a & b) ^ (a & c) ^ (b & c)
def add(*args):
    s = 0
    for a in args: s = (s + a) & M32
    return s

K = [
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5,
    0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3,
    0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
    0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7,
    0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13,
    0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3,
    0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5,
    0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
    0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
]

IV = [
    0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
    0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19,
]

def sha256_standard(msg_words):
    """Standard SHA-256 compression, returns all intermediate states."""
    W = list(msg_words) + [0]*48
    for t in range(16, 64):
        W[t] = add(sigma1(W[t-2]), W[t-7], sigma0(W[t-15]), W[t-16])

    a, b, c, d, e, f, g, h = IV
    states = [(a, b, c, d, e, f, g, h)]
    t1_vals = []
    t2_vals = []

    for t in range(64):
        T1 = add(h, Sigma1(e), Ch(e, f, g), K[t], W[t])
        T2 = add(Sigma0(a), Maj(a, b, c))
        t1_vals.append(T1)
        t2_vals.append(T2)
        h = g; g = f; f = e; e = add(d, T1)
        d = c; c = b; b = a; a = add(T1, T2)
        states.append((a, b, c, d, e, f, g, h))

    hash_out = [add(states[-1][i], IV[i]) for i in range(8)]
    return hash_out, states, t1_vals, t2_vals, W

def sha256_unrolled(msg_words):
    """Unrolled SHA-256 — no shift register, variables rotate in place."""
    W = list(msg_words) + [0]*48
    for t in range(16, 64):
        W[t] = add(sigma1(W[t-2]), W[t-7], sigma0(W[t-15]), W[t-16])

    a, b, c, d, e, f, g, h = IV
    var_history = [(a, b, c, d, e, f, g, h)]

    for t in range(64):
        r = t % 8
        if r == 0:
            T1 = add(h, Sigma1(e), Ch(e, f, g), K[t], W[t])
            T2 = add(Sigma0(a), Maj(a, b, c))
            d = add(d, T1); h = add(T1, T2)
        elif r == 1:
            T1 = add(g, Sigma1(d), Ch(d, e, f), K[t], W[t])
            T2 = add(Sigma0(h), Maj(h, a, b))
            c = add(c, T1); g = add(T1, T2)
        elif r == 2:
            T1 = add(f, Sigma1(c), Ch(c, d, e), K[t], W[t])
            T2 = add(Sigma0(g), Maj(g, h, a))
            b = add(b, T1); f = add(T1, T2)
        elif r == 3:
            T1 = add(e, Sigma1(b), Ch(b, c, d), K[t], W[t])
            T2 = add(Sigma0(f), Maj(f, g, h))
            a = add(a, T1); e = add(T1, T2)
        elif r == 4:
            T1 = add(d, Sigma1(a), Ch(a, b, c), K[t], W[t])
            T2 = add(Sigma0(e), Maj(e, f, g))
            h = add(h, T1); d = add(T1, T2)
        elif r == 5:
            T1 = add(c, Sigma1(h), Ch(h, a, b), K[t], W[t])
            T2 = add(Sigma0(d), Maj(d, e, f))
            g = add(g, T1); c = add(T1, T2)
        elif r == 6:
            T1 = add(b, Sigma1(g), Ch(g, h, a), K[t], W[t])
            T2 = add(Sigma0(c), Maj(c, d, e))
            f = add(f, T1); b = add(T1, T2)
        elif r == 7:
            T1 = add(a, Sigma1(f), Ch(f, g, h), K[t], W[t])
            T2 = add(Sigma0(b), Maj(b, c, d))
            e = add(e, T1); a = add(T1, T2)

        var_history.append((a, b, c, d, e, f, g, h))

    hash_out = [add(x, iv) for x, iv in zip((a,b,c,d,e,f,g,h), IV)]
    return hash_out, var_history

def test_unrolled_equivalence():
    """Verify unrolled matches standard."""
    import random
    random.seed(42)
    msg = [random.randint(0, M32) for _ in range(16)]

    h_std, states, t1v, t2v, W = sha256_standard(msg)
    h_unr, var_hist = sha256_unrolled(msg)

    print("=== Unrolled vs Standard SHA-256 ===")
    match = all(a == b for a, b in zip(h_std, h_unr))
    print(f"Hash match: {match}")
    if not match:
        print(f"  Standard: {[hex(x) for x in h_std]}")
        print(f"  Unrolled: {[hex(x) for x in h_unr]}")
        return False
    return True, h_std, states, t1v, t2v, W, var_hist

def analyze_backward_walk():
    """Map which unrolled variables are known at each backward step."""
    import random
    random.seed(42)
    msg = [random.randint(0, M32) for _ in range(16)]

    ok, h_std, states, t1v, t2v, W, var_hist = test_unrolled_equivalence()

    # Final state from hash
    final = [add(h_std[i], ((-IV[i]) & M32)) for i in range(8)]
    # final = (a, b, c, d, e, f, g, h) after round 63
    a_f, b_f, c_f, d_f, e_f, f_f, g_f, h_f = final

    print(f"\n=== Backward Walk from Hash ===")
    print(f"Final state (hash - IV):")
    for i, name in enumerate("abcdefgh"):
        print(f"  {name} = {hex(final[i])}")

    # Map: which rounds modify each variable
    print(f"\n=== Variable Modification Map (last 8 rounds) ===")
    mods = {v: [] for v in "abcdefgh"}
    for t in range(56, 64):
        r = t % 8
        # Which two vars are modified?
        mod_pairs = {
            0: ('d', 'h'), 1: ('c', 'g'), 2: ('b', 'f'), 3: ('a', 'e'),
            4: ('h', 'd'), 5: ('g', 'c'), 6: ('f', 'b'), 7: ('e', 'a')
        }
        v1, v2 = mod_pairs[r]
        mods[v1].append(t)
        mods[v2].append(t)

    for v in "abcdefgh":
        print(f"  {v}: modified at rounds {mods[v]}")

    # For backward walk, a variable is KNOWN at round t if it was NOT modified
    # by any round > t.
    print(f"\n=== Backward Walk: Which Variables Known? ===")
    print(f"(Variables not modified between round t and round 63)")

    for step, t in enumerate(range(63, 55, -1)):
        # Which vars are modified by rounds t+1 through 63?
        modified = set()
        mod_pairs = {
            0: ('d', 'h'), 1: ('c', 'g'), 2: ('b', 'f'), 3: ('a', 'e'),
            4: ('h', 'd'), 5: ('g', 'c'), 6: ('f', 'b'), 7: ('e', 'a')
        }
        for future_t in range(t+1, 64):
            v1, v2 = mod_pairs[future_t % 8]
            modified.add(v1)
            modified.add(v2)

        known = [v for v in "abcdefgh" if v not in modified]
        unknown = [v for v in "abcdefgh" if v in modified]

        r = t % 8
        # What does the T1 formula look like at this round?
        t1_roles = {
            0: "T1 = h + Σ₁(e) + Ch(e,f,g)",
            1: "T1 = g + Σ₁(d) + Ch(d,e,f)",
            2: "T1 = f + Σ₁(c) + Ch(c,d,e)",
            3: "T1 = e + Σ₁(b) + Ch(b,c,d)",
            4: "T1 = d + Σ₁(a) + Ch(a,b,c)",
            5: "T1 = c + Σ₁(h) + Ch(h,a,b)",
            6: "T1 = b + Σ₁(g) + Ch(g,h,a)",
            7: "T1 = a + Σ₁(f) + Ch(f,g,h)",
        }
        t2_roles = {
            0: "T2 = Σ₀(a) + Maj(a,b,c)",
            1: "T2 = Σ₀(h) + Maj(h,a,b)",
            2: "T2 = Σ₀(g) + Maj(g,h,a)",
            3: "T2 = Σ₀(f) + Maj(f,g,h)",
            4: "T2 = Σ₀(e) + Maj(e,f,g)",
            5: "T2 = Σ₀(d) + Maj(d,e,f)",
            6: "T2 = Σ₀(c) + Maj(c,d,e)",
            7: "T2 = Σ₀(b) + Maj(b,c,d)",
        }

        print(f"\n  Step {step+1}: Undo round {t} (r={r})")
        print(f"    Known vars: {', '.join(known)} ({len(known)}/8)")
        print(f"    Unknown:    {', '.join(unknown)} ({len(unknown)}/8)")
        print(f"    {t1_roles[r]} + K[{t}] + W[{t}]")
        print(f"    {t2_roles[r]}")

        # Check if T2 inputs are all known
        t2_var_map = {
            0: ['a','b','c'], 1: ['h','a','b'], 2: ['g','h','a'], 3: ['f','g','h'],
            4: ['e','f','g'], 5: ['d','e','f'], 6: ['c','d','e'], 7: ['b','c','d'],
        }
        t2_vars = t2_var_map[r]
        t2_known = all(v in known for v in t2_vars)
        print(f"    T2 vars ({','.join(t2_vars)}): {'ALL KNOWN ✓' if t2_known else 'UNKNOWN ✗'}")

        # Check Σ₁ input
        sigma1_var_map = {0:'e', 1:'d', 2:'c', 3:'b', 4:'a', 5:'h', 6:'g', 7:'f'}
        s1v = sigma1_var_map[r]
        print(f"    Σ₁({s1v}): {'KNOWN ✓' if s1v in known else 'UNKNOWN ✗'}")

        # Check Ch inputs
        ch_var_map = {
            0: ['e','f','g'], 1: ['d','e','f'], 2: ['c','d','e'], 3: ['b','c','d'],
            4: ['a','b','c'], 5: ['h','a','b'], 6: ['g','h','a'], 7: ['f','g','h'],
        }
        ch_vars = ch_var_map[r]
        ch_known_count = sum(1 for v in ch_vars if v in known)
        ch_status = []
        for v in ch_vars:
            ch_status.append(f"{v}={'✓' if v in known else '✗'}")
        print(f"    Ch({','.join(ch_vars)}): {' '.join(ch_status)}")
        if ch_known_count == 3:
            print(f"      → Ch is a KNOWN CONSTANT")
        elif ch_vars[0] in known:
            print(f"      → Ch is AFFINE in unknowns (1st arg known → linear in others)")
        else:
            print(f"      → Ch is NONLINEAR (1st arg unknown)")

        # Addend variable
        addend_map = {0:'h', 1:'g', 2:'f', 3:'e', 4:'d', 5:'c', 6:'b', 7:'a'}
        add_v = addend_map[r]
        print(f"    Addend ({add_v}): {'KNOWN ✓' if add_v in known else 'UNKNOWN ✗'}")

        if t2_known:
            print(f"    → T1 and T2 recoverable ✓")
        else:
            print(f"    → T2 NOT computable (missing vars) ✗")

def verify_t1_t2_recovery():
    """Actually compute and verify T1/T2 from hash alone."""
    import random
    random.seed(42)
    msg = [random.randint(0, M32) for _ in range(16)]

    _, h_std, states, t1v, t2v, W, var_hist = test_unrolled_equivalence()

    # Start from hash
    final = [(h_std[i] - IV[i]) & M32 for i in range(8)]
    a, b, c, d, e, f, g, h = final

    print(f"\n=== Verifying T1/T2 Recovery ===")

    # Undo round 63 (r=7): modifies e, a
    # T2 = Σ₀(b) + Maj(b,c,d) — all final, known
    T2_63 = add(Sigma0(b), Maj(b, c, d))
    T1_63 = (a - T2_63) & M32
    e_before = (e - T1_63) & M32
    print(f"Round 63: T1={hex(T1_63)} T2={hex(T2_63)} | actual T1={hex(t1v[63])} T2={hex(t2v[63])} | match: {T1_63==t1v[63] and T2_63==t2v[63]}")
    # After undoing: a=???, e=e_before, b,c,d,f,g,h = final

    # Undo round 62 (r=6): modifies f, b
    # T2 = Σ₀(c) + Maj(c, d, e_before) — all known!
    T2_62 = add(Sigma0(c), Maj(c, d, e_before))
    T1_62 = (b - T2_62) & M32
    f_before = (f - T1_62) & M32
    print(f"Round 62: T1={hex(T1_62)} T2={hex(T2_62)} | actual T1={hex(t1v[62])} T2={hex(t2v[62])} | match: {T1_62==t1v[62] and T2_62==t2v[62]}")

    # Undo round 61 (r=5): modifies g, c
    # T2 = Σ₀(d) + Maj(d, e_before, f_before) — all known!
    T2_61 = add(Sigma0(d), Maj(d, e_before, f_before))
    T1_61 = (c - T2_61) & M32
    g_before = (g - T1_61) & M32
    print(f"Round 61: T1={hex(T1_61)} T2={hex(T2_61)} | actual T1={hex(t1v[61])} T2={hex(t2v[61])} | match: {T1_61==t1v[61] and T2_61==t2v[61]}")

    # KEY: At round 61, Σ₁(h) uses h = h_final (KNOWN)
    # And Ch(h, a, b) has h = h_final (KNOWN) as first arg
    print(f"\n  Round 61 details:")
    print(f"    h (Σ₁ input) = h_final = {hex(h)} — KNOWN from hash[7]-IV[7]")
    print(f"    Σ₁(h) = {hex(Sigma1(h))} — computable")
    print(f"    Ch(h, a_???, b_???): h known → AFFINE in a,b")

    # Undo round 60 (r=4): modifies h, d
    # T2 = Σ₀(e_before) + Maj(e_before, f_before, g_before) — all known!
    T2_60 = add(Sigma0(e_before), Maj(e_before, f_before, g_before))
    T1_60 = (d - T2_60) & M32
    h_before = (h - T1_60) & M32
    print(f"Round 60: T1={hex(T1_60)} T2={hex(T2_60)} | actual T1={hex(t1v[60])} T2={hex(t2v[60])} | match: {T1_60==t1v[60] and T2_60==t2v[60]}")

    # Undo round 59 (r=3): modifies a, e
    # T2 = Σ₀(f_before) + Maj(f_before, g_before, h_before) — all known!
    T2_59 = add(Sigma0(f_before), Maj(f_before, g_before, h_before))
    T1_59 = (e_before - T2_59) & M32
    print(f"Round 59: T1={hex(T1_59)} T2={hex(T2_59)} | actual T1={hex(t1v[59])} T2={hex(t2v[59])} | match: {T1_59==t1v[59] and T2_59==t2v[59]}")

    # Round 58 (r=2): modifies b, f
    # T2 = Σ₀(g_before) + Maj(g_before, h_before, a_???) — a unknown!
    # This is where the wall is — a was modified by round 63 and we don't know its pre-63 value
    print(f"\nRound 58: T2 needs a_before_63 — UNKNOWN (wall)")

    print(f"\n=== The Linearity Window ===")
    print(f"Rounds 63-61: Σ₁ input is KNOWN in all three")
    print(f"  Round 63: Σ₁(f_final) — known")
    print(f"  Round 62: Σ₁(g_final) — known")
    print(f"  Round 61: Σ₁(h_final) — known  ← USER'S OBSERVATION")
    print(f"  Round 60: Σ₁(a_???)  — UNKNOWN (first unknown Σ₁)")

    print(f"\nCh linearity in the addend equations:")
    print(f"  Round 63: Ch(f,g,h) all final → CONSTANT")
    print(f"  Round 62: Ch(g,h,a_???) → g,h known → AFFINE in a_???")
    print(f"  Round 61: Ch(h,a_???,b_???) → h known → AFFINE in a_???,b_???")
    print(f"  Round 60: Ch(a_???,b_???,c_???) → a unknown → NONLINEAR")
    print(f"  Round 59: Ch(b_???,c_???,d_???) → b unknown → NONLINEAR")

    print(f"\n=== 3 Linear Addend Equations ===")
    print(f"These are INTEGER equations (mod 2^32), linear in unknowns:")

    # Round 63 addend: T1_63 = a_old + Σ₁(f) + Ch(f,g,h) + K[63] + W[63]
    known_63 = add(Sigma1(f), Ch(f, g, h), K[63])
    print(f"\n  Eq 63: a_old + W[63] = {hex((T1_63 - known_63) & M32)}")
    # Verify
    actual_a_old = states[63][0]  # a at time 63 (before round 63)
    check = (actual_a_old + W[63]) & M32
    print(f"    Verify: a_old={hex(actual_a_old)}, W[63]={hex(W[63])}, sum={hex(check)}, expected={hex((T1_63-known_63)&M32)}, match: {check == (T1_63-known_63)&M32}")

    # Round 62 addend: T1_62 = b_old + Σ₁(g) + Ch(g,h,a_old) + K[62] + W[62]
    # Ch(g,h,a_old) = g·h ⊕ ḡ·a_old — affine in a_old
    # So: b_old + ḡ·a_old + W[62] = T1_62 - Σ₁(g) - g·h - K[62]
    known_62_const = add(Sigma1(g), (g & h), K[62])  # constant part
    # The ḡ·a_old term makes it NOT a simple integer equation
    print(f"\n  Eq 62: b_old + (~g & a_old) + W[62] = {hex((T1_62 - known_62_const) & M32)}")
    print(f"    NOTE: (~g & a_old) is bitwise — NOT integer-linear")
    actual_b_old = states[62][1]  # b at time 62
    ch_val = Ch(g, h, actual_a_old)
    check62 = (actual_b_old + ch_val + W[62]) & M32
    exp62 = (T1_62 - Sigma1(g) - K[62]) & M32
    print(f"    Verify: {hex(check62)} == {hex(exp62)}: {check62 == exp62}")

    # Round 61 addend: T1_61 = c_old + Σ₁(h) + Ch(h,a_old,b_old) + K[61] + W[61]
    # Ch(h,a_old,b_old) = h·a_old ⊕ h̄·b_old — affine, known h selects
    known_61_const = add(Sigma1(h), K[61])
    print(f"\n  Eq 61: c_old + Ch(h_known, a_old, b_old) + W[61] = {hex((T1_61 - known_61_const) & M32)}")
    print(f"    Ch(h,a,b) = (h & a) ^ (~h & b) — h is KNOWN, so this is a bitwise MUX")
    print(f"    For each bit: if h_bit=1, Ch_bit=a_bit; if h_bit=0, Ch_bit=b_bit")

    # Count how many bits of h_final are 1 vs 0
    ones = bin(h).count('1')
    zeros = 32 - ones
    print(f"    h_final = {hex(h)}: {ones} one-bits, {zeros} zero-bits")
    print(f"    → Ch reveals {ones} bits of a_old and {zeros} bits of b_old (bitwise)")

    actual_c_old = states[61][2]  # c at time 61
    actual_b_old_61 = states[61][1]
    ch_val_61 = Ch(h, actual_a_old, actual_b_old_61)
    check61 = (actual_c_old + ch_val_61 + W[61]) & M32
    exp61 = (T1_61 - known_61_const) & M32
    print(f"    Verify: {hex(check61)} == {hex(exp61)}: {check61 == exp61}")

def count_effective_unknowns():
    """Count actual degrees of freedom for backward walk."""
    print(f"\n=== Effective Unknowns Analysis ===")
    print(f"\nVariables we need to determine:")
    print(f"  - h_63 (= g_62 = f_61 = e_60): the propagating unknown")
    print(f"  - h_62 (= g_61 = f_60 = e_59): one more level")
    print(f"  - h_61 (= g_60 = f_59 = e_58): one more")
    print(f"  - W[56] through W[63]: 8 schedule words")
    print(f"  Total unknowns: 3 state + 8 W = 11 × 32 = 352 bits")
    print(f"\nEquations we have:")
    print(f"  - 5 T1 values (rounds 59-63): 5 × 32 = 160 bits")
    print(f"  - 5 addend equations: 5 × 32 = 160 bits")
    print(f"    But addend eqs include W as unknowns, not independent info")
    print(f"\nThe addend equations:")
    print(f"  T1[t] = addend_var + Σ₁(sigma_var) + Ch(...) + K[t] + W[t]")
    print(f"  Since T1[t] is known, each gives: addend_var + ... + W[t] = const")

    print(f"\nKey insight: W[48..63] are determined by W[0..15]")
    print(f"  The 16 message words W[0..15] are the fundamental unknowns")
    print(f"  W[48..63] are LINEAR functions of W[0..15]")
    print(f"  So the 5 addend equations give 5 constraints on W[0..15] + h_63/h_62/h_61")
    print(f"  But h_63 itself depends on round 60: e_60 = d_59 + T1_59")
    print(f"  And d_59 depends on the entire computation up to round 59")

    print(f"\nThe 3-round LINEAR window (63, 62, 61):")
    print(f"  These addend equations are integer-LINEAR in the unknowns")
    print(f"  because Ch has a known first argument → bitwise affine")
    print(f"  (though carries still propagate between bits)")

    print(f"\nAfter round 60: Ch(a_old,...) with a_old UNKNOWN → NONLINEAR")
    print(f"  This is the true boundary: 3 linear equations, then nonlinear")

def demonstrate_ch_mux():
    """Show how Ch acts as a MUX when first arg is known."""
    import random
    random.seed(42)
    msg = [random.randint(0, M32) for _ in range(16)]

    _, h_std, states, t1v, t2v, W, var_hist = test_unrolled_equivalence()

    final = [(h_std[i] - IV[i]) & M32 for i in range(8)]
    h_final = final[7]  # h variable

    # At round 61: Ch(h_final, a_unknown, b_unknown)
    # For each bit i:
    #   if h_final bit i = 1: Ch bit i = a_unknown bit i
    #   if h_final bit i = 0: Ch bit i = b_unknown bit i

    print(f"\n=== Ch as Bitwise MUX at Round 61 ===")
    print(f"h_final = {bin(h_final)} ({hex(h_final)})")

    # Get actual values
    actual_a_old = states[63][0]  # This is a before round 63 modified it
    actual_b_old = states[62][1]  # This is b before round 62 modified it

    # Wait - need to map correctly. In the unrolled form at round 61:
    # Ch(h, a, b) where:
    # h = h_final (KNOWN)
    # a = a at start of round 61 in unrolled form
    # b = b at start of round 61 in unrolled form

    # In the unrolled form, a is modified by rounds 59(r=3) and 63(r=7)
    # b is modified by rounds 58(r=2) and 62(r=6)
    # At start of round 61, a was last set at round 59 (a += T1)
    # and b was last set at round 58 (b += T1)... no wait, let me check

    # Actually, going backward: at the START of round 61, the variable a
    # has the value it will keep until round 63 modifies it.
    # In the forward direction: round 59 (r=3) modifies a, then round 63 (r=7) modifies a.
    # So at start of round 61, a has its value from after round 59's modification.

    # Similarly, b is modified at round 58 (r=2) and round 62 (r=6).
    # At start of round 61, b has its value from after round 58's modification.

    # Let's get these from var_history
    a_at_61 = var_hist[61][0]  # after round 60, before round 61
    b_at_61 = var_hist[61][1]

    ch_actual = Ch(h_final, a_at_61, b_at_61)

    # Build Ch bitwise
    ch_built = 0
    a_bits_revealed = 0
    b_bits_revealed = 0
    for bit in range(32):
        h_bit = (h_final >> bit) & 1
        a_bit = (a_at_61 >> bit) & 1
        b_bit = (b_at_61 >> bit) & 1
        if h_bit == 1:
            ch_built |= (a_bit << bit)
            a_bits_revealed += 1
        else:
            ch_built |= (b_bit << bit)
            b_bits_revealed += 1

    print(f"\nCh(h_known, a_unknown, b_unknown):")
    print(f"  Bitwise MUX: if h[i]=1 → a[i], if h[i]=0 → b[i]")
    print(f"  Built from bits: {hex(ch_built)}")
    print(f"  Actual Ch value: {hex(ch_actual)}")
    print(f"  Match: {ch_built == ch_actual}")
    print(f"  a bits revealed: {a_bits_revealed}/32")
    print(f"  b bits revealed: {b_bits_revealed}/32")

    # The addend equation at round 61:
    # T1[61] = c_old + Σ₁(h_final) + Ch(h_final, a_old, b_old) + K[61] + W[61]
    # = c_old + KNOWN + MUX(a_old, b_old) + K[61] + W[61]
    #
    # Where MUX selects specific bits from a_old and b_old.
    # This is ONE equation with 3 uint32 unknowns (c_old, a_old or parts, b_old or parts, W[61]).
    # But combined with the Ch equations from rounds 63 and 62, we get a system.

    print(f"\n=== Combined System: 3 Linear Equations ===")
    print(f"Let U = a_before_63 (state unknown)")
    print(f"Let V = b_before_62 (state unknown)")
    print(f"Let X = c_before_61 (state unknown)")

    # From round 63 addend:
    # T1[63] = U + Σ₁(f) + Ch(f,g,h) + K[63] + W[63]
    # → U + W[63] = T1[63] - Σ₁(f) - Ch(f,g,h) - K[63] = C63
    a_f, b_f, c_f, d_f, e_f, f_f, g_f, h_f = final
    T1_63 = t1v[63]
    C63 = (T1_63 - Sigma1(f_f) - Ch(f_f, g_f, h_f) - K[63]) & M32
    print(f"\nEq 63: U + W[63] = {hex(C63)}")
    check = (a_at_61 + W[63]) & M32  # Wait, U = a_before_63, not a_at_61
    # a_before_63 is the a value just before round 63 runs
    # In unrolled form, round 63 (r=7) sets a = T1+T2
    # So a_before_63 is the value at start of round 63 = var_hist[63][0]
    a_before_63 = var_hist[63][0]
    check = (a_before_63 + W[63]) & M32
    print(f"  Verify: U={hex(a_before_63)}, W[63]={hex(W[63])}, U+W[63]={hex(check)}, match: {check==C63}")

    # From round 62 addend:
    # T1[62] = V + Σ₁(g) + Ch(g,h,U) + K[62] + W[62]
    # Ch(g,h,U) = g·h ⊕ ḡ·U
    # → V + (ḡ & U) + W[62] = T1[62] - Σ₁(g) - (g & h) - K[62] = C62
    T1_62 = t1v[62]
    C62 = (T1_62 - Sigma1(g_f) - (g_f & h_f) - K[62]) & M32
    b_before_62 = var_hist[62][1]
    ch62_partial = (~g_f & a_before_63) & M32
    check62 = (b_before_62 + ch62_partial + W[62]) & M32
    print(f"\nEq 62: V + (~g & U) + W[62] = {hex(C62)}")
    print(f"  Verify: V={hex(b_before_62)}, ~g&U={hex(ch62_partial)}, W[62]={hex(W[62])}")
    print(f"  V+(~g&U)+W[62] = {hex(check62)}, match: {check62==C62}")

    # From round 61 addend:
    # T1[61] = X + Σ₁(h) + Ch(h,U',V') + K[61] + W[61]
    # where U' = a at start of round 61, V' = b at start of round 61
    # U' = a_before_63 (a not modified between 61 and 63 except at round 63 and round 59)
    # Wait - a IS modified at round 59 (r=3). So a at start of round 61 = a after round 60
    # = a after round 59's modification (since round 60 doesn't modify a).
    # And a at start of round 63 = a after round 62 = a after round 61 = a after round 60 = a_at_61
    # So U' = a_before_63 = a_at_61? Let me check.

    # Round 59 (r=3): modifies a and e. a += T1
    # Round 60 (r=4): does NOT modify a
    # Round 61 (r=5): does NOT modify a
    # Round 62 (r=6): does NOT modify a
    # Round 63 (r=7): modifies a. a = T1+T2

    # So a at start of 61 = a at end of 60 = a at end of 59 = a after round 59's a+=T1
    # And a at start of 63 = a at end of 62 = a at end of 61 = a at end of 60 = same value!
    # So a_before_63 = a_at_61 = a at start of round 61. They're THE SAME.

    print(f"\n  CRITICAL: a_before_63 = a_at_start_of_61 = same variable!")
    print(f"  Because rounds 60, 61, 62 do NOT modify a.")
    print(f"  a_before_63 = {hex(a_before_63)}, var_hist[61][0] = {hex(var_hist[61][0])}")
    print(f"  Same: {a_before_63 == var_hist[61][0]}")

    # Similarly for b:
    # Round 58 (r=2): modifies b and f. b += T1
    # Round 59 (r=3): does NOT modify b
    # Round 60 (r=4): does NOT modify b
    # Round 61 (r=5): does NOT modify b
    # Round 62 (r=6): modifies b. b = T1+T2

    # So b at start of 61 = b at end of 60 = b at end of 59 = b at end of 58 = b after round 58
    # And b_before_62 = b at start of 62 = b at end of 61 = b at end of 60 = same!
    # So b_before_62 = b at start of round 61. Same variable!

    print(f"  b_before_62 = b_at_start_of_61 = same variable!")
    print(f"  b_before_62 = {hex(b_before_62)}, var_hist[61][1] = {hex(var_hist[61][1])}")
    print(f"  Same: {b_before_62 == var_hist[61][1]}")

    T1_61 = t1v[61]
    c_before_61 = var_hist[61][2]
    C61 = (T1_61 - Sigma1(h_f) - K[61]) & M32
    ch61 = Ch(h_f, a_before_63, b_before_62)
    check61 = (c_before_61 + ch61 + W[61]) & M32
    print(f"\nEq 61: X + Ch(h,U,V) + W[61] = {hex(C61)}")
    print(f"  Ch(h,U,V) = (h & U) ^ (~h & V)")
    print(f"  Verify: X={hex(c_before_61)}, Ch={hex(ch61)}, W[61]={hex(W[61])}")
    print(f"  X+Ch+W[61] = {hex(check61)}, match: {check61==C61}")

    # But X (= c_before_61) is ALSO a state unknown. Where does it come from?
    # c is modified at round 57 (r=1) and round 61 (r=5)
    # So c at start of round 61 = c after round 60 = ... = c after round 57
    # c_before_61 is another independent state unknown

    print(f"\n=== Summary of the 3-Equation System ===")
    print(f"3 equations, each mod 2^32:")
    print(f"  U + W[63]              = C63  (pure integer-linear)")
    print(f"  V + (~g & U) + W[62]   = C62  (bitwise-affine U, integer-linear V)")
    print(f"  X + Ch(h,U,V) + W[61]  = C61  (bitwise-affine U,V via MUX)")
    print(f"\n6 unknowns: U, V, X, W[61], W[62], W[63]")
    print(f"3 equations → 3 degrees of freedom remain")
    print(f"\nBUT: W[61], W[62], W[63] are LINEAR in W[0..15]")
    print(f"  W[63] = σ₁(W[61]) + W[56] + σ₀(W[48]) + W[47]")
    print(f"  Each W[t] (t≥16) is a linear combination of W[0..15]")
    print(f"  So W[61..63] contributes 0 new DoF beyond W[0..15]")
    print(f"\nThe state unknowns U, V, X are also determined by W[0..15]")
    print(f"  (through the entire forward computation)")
    print(f"  So effectively: 3 equations on 16 unknowns (W[0..15])")
    print(f"  → 13 degrees of freedom")

if __name__ == "__main__":
    test_unrolled_equivalence()
    analyze_backward_walk()
    verify_t1_t2_recovery()
    count_effective_unknowns()
    demonstrate_ch_mux()
