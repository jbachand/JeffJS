#!/usr/bin/env python3
"""
SHA-256 Period Hunt — Does the backward round function have hidden periodicity?

If f(h) = rhs - h - Ch(e_known, f_known, h) has a periodic structure,
QFT can extract it like Shor's extracts the period of modular exponentiation.

We test:
1. The full backward round function f(h) for periodicity
2. The Ch component alone for periodicity
3. Quantum simulation: apply f in superposition + QFT, look for peaks
4. Compare real K constants vs random K (does real K create periodicity?)
"""

import numpy as np
from numpy.fft import fft, fftfreq
import random

# ═══════════════════════════════════════════════════════════════
# Mini-SHA components (4-bit)
# ═══════════════════════════════════════════════════════════════

BITS = 4
MASK = (1 << BITS) - 1
N = 1 << BITS  # 16

def rotr(x, n):
    n = n % BITS
    return ((x >> n) | (x << (BITS - n))) & MASK

def Ch(e, f, g):
    return ((e & f) ^ ((e ^ MASK) & g)) & MASK

def Maj(a, b, c):
    return ((a & b) ^ (a & c) ^ (b & c)) & MASK

def Sigma0(a):
    return (rotr(a, 1) ^ rotr(a, 2) ^ rotr(a, 3)) & MASK

def Sigma1(e):
    return (rotr(e, 1) ^ rotr(e, 2) ^ rotr(e, 3)) & MASK

REAL_K = [k & MASK for k in [
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5,
    0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3,
    0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
]]
MINI_IV = [v & MASK for v in [
    0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
    0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19,
]]


def mini_sha(msg, n_rounds=16):
    W = list(msg[:16])
    while len(W) < 16: W.append(0)
    for t in range(16, max(n_rounds, 16)):
        s0 = rotr(W[t-15], 1) ^ rotr(W[t-15], 2) ^ (W[t-15] >> 1)
        s1 = rotr(W[t-2], 2) ^ rotr(W[t-2], 3) ^ (W[t-2] >> 1)
        W.append((W[t-16] + s0 + W[t-7] + s1) & MASK)
    a, b, c, d, e, f, g, h = MINI_IV
    states = [(a, b, c, d, e, f, g, h)]
    for t in range(n_rounds):
        S1 = Sigma1(e)
        ch = Ch(e, f, g)
        T1 = (h + S1 + ch + REAL_K[t % len(REAL_K)] + W[t]) & MASK
        S0 = Sigma0(a)
        maj = Maj(a, b, c)
        T2 = (S0 + maj) & MASK
        h = g; g = f; f = e; e = (d + T1) & MASK
        d = c; c = b; b = a; a = (T1 + T2) & MASK
        states.append((a, b, c, d, e, f, g, h))
    hash_out = [(MINI_IV[i] + v) & MASK for i, v in enumerate(states[-1])]
    return hash_out, W, states


# ═══════════════════════════════════════════════════════════════
# Quantum simulator (minimal, for QFT-based period finding)
# ═══════════════════════════════════════════════════════════════

class QSim:
    def __init__(self, n):
        self.n = n
        self.dim = 1 << n
        self.state = np.zeros(self.dim, dtype=np.complex128)
        self.state[0] = 1.0

    def h_gate(self, q):
        s = 1 << q
        inv = 1.0 / np.sqrt(2)
        new = self.state.copy()
        for i in range(self.dim):
            if i & s == 0:
                j = i | s
                a, b = self.state[i], self.state[j]
                new[i] = (a + b) * inv
                new[j] = (a - b) * inv
        self.state = new

    def phase(self, q, angle):
        s = 1 << q
        p = np.exp(1j * angle)
        for i in range(self.dim):
            if i & s:
                self.state[i] *= p

    def x_gate(self, q):
        s = 1 << q
        new = self.state.copy()
        for i in range(self.dim):
            j = i ^ s
            new[j] = self.state[i]
        self.state = new

    def qft(self, qubits):
        """QFT on the specified qubits."""
        n = len(qubits)
        for i in range(n):
            qi = qubits[i]
            self.h_gate(qi)
            for j in range(i + 1, n):
                qj = qubits[j]
                angle = np.pi / (1 << (j - i))
                self.controlled_phase(qj, qi, angle)
        # Swap qubits for correct ordering
        for i in range(n // 2):
            self.swap(qubits[i], qubits[n - 1 - i])

    def controlled_phase(self, control, target, angle):
        sc = 1 << control
        st = 1 << target
        p = np.exp(1j * angle)
        for i in range(self.dim):
            if (i & sc) and (i & st):
                self.state[i] *= p

    def swap(self, q1, q2):
        s1 = 1 << q1
        s2 = 1 << q2
        new = self.state.copy()
        for i in range(self.dim):
            b1 = (i >> q1) & 1
            b2 = (i >> q2) & 1
            if b1 != b2:
                j = i ^ s1 ^ s2
                new[j] = self.state[i]
        self.state = new

    def apply_function(self, input_qubits, output_qubits, func):
        """Apply |x>|0> -> |x>|f(x)> for a classical function f."""
        ni = len(input_qubits)
        no = len(output_qubits)
        new = np.zeros_like(self.state)
        for i in range(self.dim):
            if abs(self.state[i]) < 1e-15:
                continue
            # Extract input value
            x = 0
            for bi, q in enumerate(input_qubits):
                if i & (1 << q):
                    x |= (1 << bi)
            # Extract current output value
            y = 0
            for bi, q in enumerate(output_qubits):
                if i & (1 << q):
                    y |= (1 << bi)
            # Compute f(x) XOR y (reversible)
            fy = func(x) ^ y
            # Build new index
            j = i
            for bi, q in enumerate(output_qubits):
                if fy & (1 << bi):
                    j |= (1 << q)
                else:
                    j &= ~(1 << q)
            new[j] += self.state[i]
        self.state = new

    def measure_probs(self, qubits):
        """Get probability distribution over specified qubits."""
        nq = len(qubits)
        probs = np.zeros(1 << nq)
        for i in range(self.dim):
            val = 0
            for bi, q in enumerate(qubits):
                if i & (1 << q):
                    val |= (1 << bi)
            probs[val] += abs(self.state[i]) ** 2
        return probs


# ═══════════════════════════════════════════════════════════════
# TEST 1: Classical periodicity of the backward round function
# ═══════════════════════════════════════════════════════════════

def test_classical_periodicity():
    print("═" * 72)
    print("  TEST 1: Classical Periodicity of Backward Round Function")
    print("  f(h) = rhs - h - Ch(e_known, f_known, h)")
    print("═" * 72)

    random.seed(42)
    msg = [random.getrandbits(BITS) for _ in range(16)]
    hash_out, W, states = mini_sha(msg, 16)
    final_state = [(hash_out[i] - MINI_IV[i]) & MASK for i in range(8)]

    # For each of the last 4 rounds, compute f(h) for all h
    print(f"\n  For each backward round, compute f(h) for all h ∈ [0, {N-1}]:")
    print(f"  f(h) = the W value produced by candidate h\n")

    for step in range(4):
        t = 15 - step
        a1, b1, c1, d1, e1, f1, g1, h1 = final_state if step == 0 else state_prev

        a0 = b1; b0 = c1; c0 = d1
        e0 = f1; f0 = g1; g0 = h1
        T2 = (Sigma0(a0) + Maj(a0, b0, c0)) & MASK
        T1 = (a1 - T2) & MASK
        d0 = (e1 - T1) & MASK

        # f(h) = W produced by candidate h
        def backward_f(h_candidate):
            ch = Ch(e0, f0, h_candidate)
            rhs = (T1 - Sigma1(e0) - ch - REAL_K[t % len(REAL_K)]) & MASK
            # rhs = h_prev + W, but h_prev is unknown too
            # The FUNCTION we're analyzing: given h as g in Ch, what W comes out?
            # W = rhs - h_prev. But h_prev is the NEXT unknown in the chain.
            # For period analysis: look at just the Ch contribution
            return rhs

        values = [backward_f(h) for h in range(N)]

        # Check for periodicity
        print(f"  Round {t}: e0={e0:04b} f0={f0:04b}")
        print(f"    h:    {' '.join(f'{h:2d}' for h in range(N))}")
        print(f"    f(h): {' '.join(f'{v:2d}' for v in values)}")

        # FFT to find periodicity
        signal = np.array(values, dtype=np.float64)
        signal -= signal.mean()
        spectrum = np.abs(fft(signal))
        spectrum[0] = 0  # remove DC

        dominant = np.argmax(spectrum[:N//2+1])
        print(f"    FFT dominant frequency: {dominant}/{N} (period = {N/dominant if dominant > 0 else '∞'})")

        # Check for simple patterns
        diffs = [(values[(i+1) % N] - values[i]) & MASK for i in range(N)]
        unique_diffs = len(set(diffs))
        print(f"    Consecutive diffs: {unique_diffs} unique out of {N}")

        # Check for exact periodicity: f(h) = f(h + p) for some p
        for p in range(1, N):
            periodic = all(values[h] == values[(h + p) % N] for h in range(N))
            if periodic:
                print(f"    ★ EXACT PERIOD: {p}")
                break
        else:
            print(f"    No exact period found")

        # Store state for next iteration
        state_prev = [a0, b0, c0, d0, e0, f0, g0, values[0]]  # placeholder h
        print()


# ═══════════════════════════════════════════════════════════════
# TEST 2: Ch function periodicity analysis
# Ch(e, f, g) with fixed e, f — what's the structure as g varies?
# ═══════════════════════════════════════════════════════════════

def test_ch_periodicity():
    print("═" * 72)
    print("  TEST 2: Ch(e, f, g) Structure — g varies, e and f fixed")
    print("  This is the CORE nonlinear function in the backward round")
    print("═" * 72)

    print(f"\n  Ch(e, f, g) = (e & f) ^ (~e & g)")
    print(f"  Where e=0: Ch = g (identity)")
    print(f"  Where e=1: Ch = f (constant)")
    print(f"  Mixed: Ch is a SELECTOR — picks bits from f or g based on e\n")

    for e in range(N):
        for f_val in [0, 5, 10, 15]:  # sample f values
            values = [Ch(e, f_val, g) for g in range(N)]

            # The key question: is Ch(e, f, ·) a LINEAR function of g?
            # Ch = (e & f) ^ (~e & g) = constant ^ (mask & g)
            # where mask = ~e. This IS linear! It's XOR with a mask.

            # Check linearity: Ch(e, f, g1 ^ g2) == Ch(e, f, g1) ^ Ch(e, f, g2) ^ Ch(e, f, 0)?
            ch0 = Ch(e, f_val, 0)
            is_affine = True
            for g1 in range(N):
                for g2 in range(N):
                    lhs = Ch(e, f_val, g1 ^ g2)
                    rhs = Ch(e, f_val, g1) ^ Ch(e, f_val, g2) ^ ch0
                    if lhs != rhs:
                        is_affine = False
                        break
                if not is_affine:
                    break

            if e in [0, 3, 7, 12, 15]:  # sample e values
                print(f"  e={e:04b} f={f_val:04b}: Ch(g) = {values}")
                print(f"    Affine in g? {'YES ★' if is_affine else 'NO'}")
                if is_affine:
                    # Ch(e,f,g) = (~e & g) ^ (e & f) = affine: multiply by ~e, add constant
                    mask = e ^ MASK
                    const = e & f_val
                    print(f"    Ch = (~e & g) ^ (e & f) = (0b{mask:04b} & g) ^ 0b{const:04b}")
                print()


# ═══════════════════════════════════════════════════════════════
# TEST 3: The FULL backward function — is it affine in h?
# f(h) = C - h - Ch(e, f, h) where C is known
# f(h) = C - h - [(~e & h) ^ (e & f)]
# ═══════════════════════════════════════════════════════════════

def test_backward_linearity():
    print("═" * 72)
    print("  TEST 3: Is the backward function AFFINE in h?")
    print("  f(h) = C - h - Ch(e, f, h)")
    print("  Ch is affine in h (XOR with mask). But subtraction is mod 2^n.")
    print("  XOR is GF(2). Subtraction is Z/2^n. They DON'T commute.")
    print("═" * 72)

    # The backward function mixes:
    # - Subtraction (mod 2^BITS): h enters via rhs - h_prev
    # - XOR (GF(2)): h enters via Ch = (~e & h) ^ constant
    #
    # These are operations in DIFFERENT algebraic structures.
    # Subtraction carries propagate across bits. XOR doesn't.
    #
    # The question: does this mixing create periodicity or structure?

    print(f"\n  Decomposition:")
    print(f"    f(h) = T1 - Σ1(e0) - Ch(e0, f0, h) - K[t]")
    print(f"    Ch(e0, f0, h) = (~e0 & h) ^ (e0 & f0)")
    print(f"    = XOR_mask(h) ^ constant")
    print(f"")
    print(f"  So f(h) = [T1 - Σ1(e0) - K[t]] - [(~e0 & h) ^ (e0 & f0)]")
    print(f"          = C - [(~e0 & h) ^ D]")
    print(f"  where C and D are known constants.\n")

    # For each possible (e0, f0), compute f(h) for all h and check structure
    print(f"  Testing all (e, f) pairs for structure in f(h):\n")

    n_affine = 0
    n_periodic = 0
    n_total = 0

    for e0 in range(N):
        for f0_val in range(N):
            C = random.randint(0, MASK)  # T1 - Σ1 - K (some known value)
            D = e0 & f0_val

            def f(h):
                ch = ((e0 ^ MASK) & h) ^ D
                return (C - ch) & MASK

            values = [f(h) for h in range(N)]
            n_total += 1

            # Check affine: f(a ^ b) = f(a) ^ f(b) ^ f(0)?
            f0 = f(0)
            is_affine = True
            for a in range(N):
                for b in range(N):
                    if f(a ^ b) != (f(a) ^ f(b) ^ f0):
                        is_affine = False
                        break
                if not is_affine:
                    break
            if is_affine:
                n_affine += 1

            # Check periodicity
            for p in range(1, N):
                if all(values[h] == values[(h + p) % N] for h in range(N)):
                    n_periodic += 1
                    break

    print(f"  Results across all {n_total} (e, f) combinations:")
    print(f"    Affine (f(a^b) = f(a)^f(b)^f(0)): {n_affine}/{n_total}")
    print(f"    Periodic (f(h) = f(h+p)):          {n_periodic}/{n_total}")

    # Deep dive on one specific case
    print(f"\n  Deep dive: e=0b0110, f=0b1010, C=0b1100\n")
    e0, f0_val, C = 0b0110, 0b1010, 0b1100
    D = e0 & f0_val  # 0b0010

    for h in range(N):
        ch_val = ((e0 ^ MASK) & h) ^ D
        result = (C - ch_val) & MASK
        h_bits = format(h, f'0{BITS}b')
        ch_bits = format(ch_val, f'0{BITS}b')
        r_bits = format(result, f'0{BITS}b')
        print(f"    h={h_bits}  Ch={ch_bits}  f(h)={r_bits} ({result:2d})")


# ═══════════════════════════════════════════════════════════════
# TEST 4: Quantum period finding on the backward function
# Like Shor's: prepare superposition, apply f, QFT, measure
# ═══════════════════════════════════════════════════════════════

def test_quantum_period_finding():
    print(f"\n{'═' * 72}")
    print("  TEST 4: Quantum Period Finding (Shor's Approach)")
    print("  Prepare |h⟩ in superposition, compute f(h), apply QFT, measure")
    print("═" * 72)

    random.seed(42)
    msg = [random.getrandbits(BITS) for _ in range(16)]
    hash_out, W, states = mini_sha(msg, 16)
    final_state = [(hash_out[i] - MINI_IV[i]) & MASK for i in range(8)]

    # For the last round backward
    t = 15
    a1, b1, c1, d1, e1, f1, g1, h1 = final_state
    a0 = b1; b0 = c1; c0 = d1
    e0 = f1; f0 = g1; g0 = h1
    T2 = (Sigma0(a0) + Maj(a0, b0, c0)) & MASK
    T1 = (a1 - T2) & MASK

    def backward_f(h):
        ch = Ch(e0, f0, h)
        return (T1 - Sigma1(e0) - ch - REAL_K[t % len(REAL_K)]) & MASK

    # Classical truth table
    print(f"\n  Classical f(h) for round {t}:")
    print(f"  e0={e0} ({e0:04b}), f0={f0} ({f0:04b})")
    for h in range(N):
        print(f"    f({h:2d}) = {backward_f(h):2d}", end="")
        if h == states[t][7]:  # actual h value
            print(f"  ← actual h_before", end="")
        print()

    # Quantum simulation: Shor-like period finding
    n_input = BITS   # qubits for h
    n_output = BITS  # qubits for f(h)
    n_total = n_input + n_output

    print(f"\n  Quantum circuit: {n_input} input qubits + {n_output} output qubits = {n_total} total")

    sim = QSim(n_total)
    input_qubits = list(range(n_input))
    output_qubits = list(range(n_input, n_total))

    # Step 1: Hadamard on input qubits (superposition of all h)
    for q in input_qubits:
        sim.h_gate(q)

    # Step 2: Apply f(h) → output register
    sim.apply_function(input_qubits, output_qubits, backward_f)

    # Step 3: QFT on input qubits
    sim.qft(input_qubits)

    # Step 4: Measure input qubits
    probs = sim.measure_probs(input_qubits)

    print(f"\n  After f(h) + QFT, probability distribution on input register:")
    print(f"  {'Value':>7s} │ {'Prob':>8s} │ Visual")
    print(f"  {'─'*7}─┼─{'─'*8}─┼─{'─'*40}")

    peaks = []
    for v in range(N):
        p = probs[v]
        bar = '█' * int(p * 80)
        peak = ""
        if p > 1.5 / N:  # significantly above uniform
            peak = " ← PEAK"
            peaks.append((v, p))
        print(f"  {v:>7d} │ {p:>8.4f} │ {bar}{peak}")

    print(f"\n  Peaks (above uniform = {1/N:.4f}):")
    for v, p in peaks:
        print(f"    value={v} ({v:04b}), probability={p:.4f}, ratio to uniform={p*N:.2f}×")

    # ═══════════════════════════════════════════════════════════
    # TEST 4b: What if f has collisions? (like modular exp in Shor's)
    # Shor's works because f(x) = a^x mod N has PERIODIC collisions.
    # If backward_f has collisions, QFT reveals the period structure.
    # ═══════════════════════════════════════════════════════════

    # Check collisions in backward_f
    values = [backward_f(h) for h in range(N)]
    value_counts = {}
    for v in values:
        value_counts[v] = value_counts.get(v, 0) + 1
    n_unique = len(value_counts)
    collisions = {v: c for v, c in value_counts.items() if c > 1}

    print(f"\n  Function properties:")
    print(f"    Unique outputs: {n_unique}/{N}")
    print(f"    Collisions: {len(collisions)} values hit multiple times")
    for v, c in sorted(collisions.items()):
        inputs = [h for h in range(N) if backward_f(h) == v]
        print(f"      f(h)={v}: hit by h={inputs} ({c} times)")

    if collisions:
        print(f"\n  ★ COLLISIONS FOUND — the function is NOT injective!")
        print(f"    This means multiple h values produce the same W.")
        print(f"    QFT can extract the PERIOD between colliding inputs.")
        print(f"    This is exactly how Shor's algorithm works!")

        # For each collision pair, compute the "period"
        for v, c in sorted(collisions.items()):
            inputs = [h for h in range(N) if backward_f(h) == v]
            if len(inputs) >= 2:
                periods = [(inputs[j] - inputs[i]) % N
                           for i in range(len(inputs))
                           for j in range(i+1, len(inputs))]
                print(f"      f(h)={v}: periods between colliders = {periods}")

    # ═══════════════════════════════════════════════════════════
    # TEST 4c: Full Shor-like approach — does QFT give us the period?
    # ═══════════════════════════════════════════════════════════
    if collisions:
        print(f"\n  QFT peaks should correspond to multiples of N/period:")
        for v, p in peaks:
            for period in set(periods):
                if period > 0:
                    expected_peak = N // period if N % period == 0 else -1
                    if expected_peak > 0 and v % expected_peak == 0:
                        print(f"    Peak at {v} = {v//expected_peak} × {expected_peak} "
                              f"(N/period = {N}/{period} = {expected_peak})")


# ═══════════════════════════════════════════════════════════════
# TEST 5: Composition — does composing multiple rounds create periodicity?
# ═══════════════════════════════════════════════════════════════

def test_composition_periodicity():
    print(f"\n{'═' * 72}")
    print("  TEST 5: Multi-Round Composition — Period Emergence")
    print("  Does composing backward rounds create periodic structure?")
    print("═" * 72)

    random.seed(42)
    msg = [random.getrandbits(BITS) for _ in range(16)]
    hash_out, W_true, states = mini_sha(msg, 16)
    final_state = [(hash_out[i] - MINI_IV[i]) & MASK for i in range(8)]

    # For each "depth" (1 round, 2 rounds, 4 rounds composed),
    # compute the composed function and check for periodicity
    for depth in [1, 2, 4, 8]:
        print(f"\n  Composing {depth} backward rounds:")

        def composed_f(h_guess):
            """
            Start with h_guess for the LAST round, walk backward `depth` rounds.
            Return the state hash after `depth` backward steps.
            """
            state = list(final_state)
            accumulated = 0

            for step in range(depth):
                t = 15 - step
                a1, b1, c1, d1, e1, f1, g1, h1 = state
                a0 = b1; b0 = c1; c0 = d1
                e0 = f1; f0 = g1; g0 = h1
                T2 = (Sigma0(a0) + Maj(a0, b0, c0)) & MASK
                T1 = (a1 - T2) & MASK
                d0 = (e1 - T1) & MASK
                ch = Ch(e0, f0, h_guess if step == 0 else g0)
                rhs = (T1 - Sigma1(e0) - ch - REAL_K[t % len(REAL_K)]) & MASK
                # Use h_guess only for the first round; subsequent rounds
                # propagate the state from the first guess
                h_before = h_guess if step == 0 else (rhs & MASK)
                state = [a0, b0, c0, d0, e0, f0, g0, h_before]
                accumulated = (accumulated + rhs) & MASK

            return accumulated

        values = [composed_f(h) for h in range(N)]
        unique = len(set(values))

        # FFT
        signal = np.array(values, dtype=np.float64)
        signal -= signal.mean()
        spectrum = np.abs(fft(signal))
        spectrum[0] = 0
        dominant = np.argmax(spectrum[:N//2+1])
        dom_magnitude = spectrum[dominant] / np.sum(spectrum) * 100 if np.sum(spectrum) > 0 else 0

        # Periodicity check
        periods_found = []
        for p in range(1, N):
            if all(values[h] == values[(h + p) % N] for h in range(N)):
                periods_found.append(p)

        # Collision check
        collisions = sum(1 for v in set(values) if values.count(v) > 1)

        print(f"    Values:     {values}")
        print(f"    Unique:     {unique}/{N}")
        print(f"    Collisions: {collisions} values hit >1 time")
        print(f"    FFT peak:   freq={dominant}, magnitude={dom_magnitude:.1f}%")
        print(f"    Periods:    {periods_found if periods_found else 'none'}")

        # Quantum QFT on composed function
        sim = QSim(BITS * 2)
        iq = list(range(BITS))
        oq = list(range(BITS, BITS * 2))
        for q in iq:
            sim.h_gate(q)
        sim.apply_function(iq, oq, composed_f)
        sim.qft(iq)
        probs = sim.measure_probs(iq)

        qft_peaks = [(v, probs[v]) for v in range(N) if probs[v] > 1.5 / N]
        if qft_peaks:
            peak_str = ", ".join(f"{v}({p:.3f})" for v, p in qft_peaks)
            print(f"    QFT peaks:  {peak_str}")
        else:
            print(f"    QFT peaks:  uniform (no structure)")


# ═══════════════════════════════════════════════════════════════

if __name__ == "__main__":
    test_ch_periodicity()
    test_backward_linearity()
    test_classical_periodicity()
    test_quantum_period_finding()
    test_composition_periodicity()

    print(f"\n{'═' * 72}")
    print(f"  SUMMARY")
    print(f"{'═' * 72}")
    print(f"""
  What we're looking for:
    Shor's works because modular exponentiation has PERIODIC structure.
    If the backward round function also has periodicity/collisions,
    QFT can extract it — turning search into structure extraction.

  Key findings:
    • Ch(e, f, g) is AFFINE in g (it's XOR with a mask)
    • The backward function mixes XOR (affine) with modular subtraction
    • This mixing creates COLLISIONS when the XOR mask and carry
      structure align — multiple h values produce the same output
    • QFT peaks at collision-related frequencies
    • Composition of multiple rounds may amplify or reduce structure

  If periodicity persists through composition → Shor-like attack works
  If periodicity vanishes → falls back to Grover's (still 2^128)
""")
