#!/usr/bin/env python3
"""
SHA-256 Dual Ramp: Forward entropy in, backward entropy out.

Forward ramp: message bits → state (density climbs 0% → 50%)
Backward ramp: hash bits → state (known vars drop 100% → 50%)

Where they cross = maximum constraint = solvable zone.
"""

import numpy as np
from math import comb
import struct

M32 = 0xFFFFFFFF

def rotr(x, n): return ((x >> n) | (x << (32 - n))) & M32
def shr(x, n): return x >> n
def Sigma1(x): return rotr(x, 6) ^ rotr(x, 11) ^ rotr(x, 25)
def Sigma0(x): return rotr(x, 2) ^ rotr(x, 13) ^ rotr(x, 22)
def sigma1(x): return rotr(x, 17) ^ rotr(x, 19) ^ shr(x, 10)
def sigma0(x): return rotr(x, 7) ^ rotr(x, 18) ^ shr(x, 3)
def Ch(e, f, g): return (e & f) ^ ((~e) & g) & M32
def Maj(a, b, c): return (a & b) ^ (a & c) ^ (b & c)

K = [0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
     0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
     0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
     0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
     0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
     0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
     0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
     0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2]
IV = [0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,
      0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19]

def sha256_all_states(msg_byte):
    """Run full SHA-256, return state at every round."""
    msg = bytes([msg_byte])
    padded = msg + b'\x80' + b'\x00' * 54 + struct.pack('>Q', 8)
    W = list(struct.unpack('>16I', padded))
    for t in range(16, 64):
        W.append((sigma1(W[t-2]) + W[t-7] + sigma0(W[t-15]) + W[t-16]) & M32)

    a,b,c,d,e,f,g,h = IV
    states = [(a,b,c,d,e,f,g,h)]
    t1_vals, t2_vals = [], []
    for t in range(64):
        T1 = (h + Sigma1(e) + Ch(e,f,g) + K[t] + W[t]) & M32
        T2 = (Sigma0(a) + Maj(a,b,c)) & M32
        t1_vals.append(T1); t2_vals.append(T2)
        h=g;g=f;f=e;e=(d+T1)&M32;d=c;c=b;b=a;a=(T1+T2)&M32
        states.append((a,b,c,d,e,f,g,h))

    hash_out = tuple((states[-1][i]+IV[i])&M32 for i in range(8))
    return states, t1_vals, t2_vals, W, hash_out

def mobius(Y, n_bits):
    a = Y.copy()
    for i in range(n_bits):
        mask = 1 << i
        for x in range(len(a)):
            if x & mask:
                a[x] ^= a[x ^ mask]
    return a

def state_to_bits(state):
    """Convert 8 × 32-bit state to 256 bits."""
    bits = np.zeros(256, dtype=np.uint8)
    for w in range(8):
        for b in range(32):
            bits[w*32+b] = (state[w]>>b)&1
    return bits

def compute_forward_ramp(n_bits=8):
    """Compute forward ramp: for each round, how "random" is the state
    as a function of input bits?

    Measure: ANF density of state bits relative to input bits.
    """
    N = 1 << n_bits

    print("=" * 70)
    print("FORWARD RAMP: Message → State density at each round")
    print("=" * 70)

    # Get all states for all inputs
    all_states = []
    for val in range(N):
        states, _, _, _, _ = sha256_all_states(val)
        all_states.append(states)

    # For each round, compute ANF of state bits
    forward_density = []
    forward_word_density = []

    for rnd in list(range(1, 9)) + [12, 16, 32, 64]:
        Y = np.zeros((N, 256), dtype=np.uint8)
        for val in range(N):
            Y[val] = state_to_bits(all_states[val][rnd])

        # ANF extraction
        total_nonzero = 0
        word_nz = [0] * 8
        for ob in range(256):
            w_anf = mobius(Y[:, ob], n_bits)
            nz = int(np.sum(w_anf))
            total_nonzero += nz
            word_nz[ob // 32] += nz

        density = total_nonzero / (N * 256)
        forward_density.append((rnd, density))

        wd = [word_nz[w] / (N * 32) for w in range(8)]
        forward_word_density.append((rnd, wd))

    return forward_density, forward_word_density

def compute_backward_ramp():
    """Compute backward ramp: from the hash, how many state values
    are DETERMINED at each round going backward?

    In the standard form, going backward from round 64:
    - The shift register means each undo reveals most variables
    - But one variable (h_t) propagates as unknown

    Count: fraction of state variables that are known at each round.
    """
    print("\n" + "=" * 70)
    print("BACKWARD RAMP: Hash → Known state at each round")
    print("=" * 70)

    # In the standard form backward walk:
    # After round 64: 8/8 known (from hash)
    # The shift register: b[t+1]=a[t], c[t+1]=b[t], d[t+1]=c[t],
    #   f[t+1]=e[t], g[t+1]=f[t], h[t+1]=g[t]
    # Plus: a[t+1]=T1+T2, e[t+1]=d[t]+T1
    # T2 uses a,b,c → from the "right" side, always known
    # T1 = a[t+1] - T2 → known
    # d[t] = e[t+1] - T1 → known
    # But: h[t] propagates backward via h[t+1]=g[t]→g[t]=h[t+1]
    # And h[t] is NOT directly computable.

    # So at each step back, we lose track of one value in the h chain.
    # Known: a,b,c,d,e,f,g from shifts and T1/T2 recovery
    # Unknown: h (the one that propagated)

    # Actually more precisely:
    # At state t (going backward from t=64):
    # Known: a[t]=b[t+1], b[t]=c[t+1], c[t]=d[t+1],
    #         e[t]=f[t+1], f[t]=g[t+1], g[t]=h[t+1]
    #         d[t]=e[t+1]-T1[t] (known since T1[t] known)
    # Unknown: h[t] — needs the addend equation which involves W[t]

    # After undoing n rounds: at state (64-n)
    # 7 state vars are known, 1 (h[64-n]) is unknown
    # BUT: the 7 known vars at state t depend on values from t+1..64
    # Some of those values ALSO depend on h[t+1], h[t+2], etc.

    # Let's track precisely which state vars are "free of unknowns"
    # vs which carry the unknown chain.

    # Using the UNROLLED form (from earlier analysis):
    # Variables modified at each r = t%8:
    # r=0: d,h  r=1: c,g  r=2: b,f  r=3: a,e
    # r=4: h,d  r=5: g,c  r=6: f,b  r=7: e,a

    # Going backward from round 63:
    # Round 63 (r=7): modifies e,a → can undo, recover e_bef, but a_bef=UNKNOWN(U)
    # Round 62 (r=6): modifies f,b → can undo, recover f_bef, but b_bef=UNKNOWN(V)
    # etc.

    # At each step, T2 is computable from 3 vars on the "determined" side
    # T1 = (modified_var - T2). Then the OTHER modified var = f(T1, old_state).
    # One var is determined, one becomes UNKNOWN.

    # So the backward ramp of KNOWN vars:
    backward_known = []

    # After round 64 (hash): 8/8 = 100%
    backward_known.append((64, 8, 8))

    # After undoing round 63: 7 known, 1 unknown (a = U)
    backward_known.append((63, 7, 8))

    # After undoing round 62: 6 known, 2 unknown (a, b)
    backward_known.append((62, 6, 8))

    # After undoing round 61: 5 known, 3 unknown (a, b, c)
    backward_known.append((61, 5, 8))

    # After undoing round 60: 4 known, 4 unknown (a, b, c, d)
    backward_known.append((60, 4, 8))

    # After undoing round 59: 3 known (+a_bef59 from U-T1_59, but U unknown)
    # Actually, T2_59 uses f_bef,g_bef,h_bef → all known → T2_59 known
    # T1_59 = e_bef - T2_59 → known
    # a_bef59 = U - T1_59 → unknown (depends on U)
    # e_bef59 = ??? (set by round 55) → unknown
    # So at state 59: e_bef,f_bef,g_bef,h_bef known (4), a,b,c,d unknown (4)
    # Wait... the known ones keep shifting.

    # Let me be more precise using the unrolled variable tracking.
    # After undoing rounds 63-59 (5 rounds):
    # Known: e_bef(from R63), f_bef(R62), g_bef(R61), h_bef(R60)
    # Unknown: a(U), b(V), c(X), d(Y)
    # = 4/8 known = 50%
    backward_known.append((59, 4, 8))

    # After undoing round 58 (with U guessed → +1 known):
    # T2_58 uses g_bef, h_bef, a_bef59 → a_bef59 = U-T1_59 (unknown without U)
    # WITHOUT U: can't compute T2_58. STUCK at 4/8.
    # WITH U: get T2_58, T1_58, extend to 5/8. But that's guessing.
    backward_known.append((58, 4, 8))  # without guess
    backward_known.append((57, 4, 8))
    backward_known.append((56, 4, 8))

    return backward_known

def compute_backward_density(n_bits=8):
    """Compute the DENSITY ramp going backward.

    For each number of rounds undone, compute the ANF density of the
    RECOVERABLE state values as functions of the HASH bits.

    The hash has 256 output bits. Each recovered state value is some
    function of those bits (via T1/T2 recovery). Extract the ANF of
    that function.
    """
    N = 1 << n_bits

    print("\n" + "=" * 70)
    print("BACKWARD DENSITY: Hash bits → recovered state ANF density")
    print("=" * 70)

    # For each input (0-255), compute the hash and the backward-recovered values
    # The "input" to the backward function is the hash itself.
    # But the hash is 256 bits and we only vary 8 message bits.
    # So we look at: how do the RECOVERED T1/T2 values depend on message bits?

    # Recovered values from backward walk (functions of hash, which is function of message):
    # T1[63], T2[63] → functions of hash words → functions of message bits
    # T1[62], T2[62] → "
    # etc.

    # Compute T1/T2 for each round, for each input
    all_t1 = np.zeros((N, 64), dtype=np.uint32)
    all_t2 = np.zeros((N, 64), dtype=np.uint32)

    for val in range(N):
        _, t1v, t2v, _, _ = sha256_all_states(val)
        for t in range(64):
            all_t1[val, t] = t1v[t]
            all_t2[val, t] = t2v[t]

    # For each round's T1 value, compute ANF density relative to input bits
    print(f"\nT1/T2 ANF density by round (as function of 8 input bits):")
    print(f"{'Round':>5} | {'T1 density':>10} | {'T2 density':>10}")
    print("-" * 35)

    t1_densities = []
    t2_densities = []

    for rnd in [0, 1, 2, 3, 4, 8, 16, 32, 48, 56, 57, 58, 59, 60, 61, 62, 63]:
        # T1 density
        t1_nz = 0
        for b in range(32):
            truth = np.array([(int(all_t1[val, rnd]) >> b) & 1 for val in range(N)], dtype=np.uint8)
            anf = mobius(truth, n_bits)
            t1_nz += int(np.sum(anf))

        # T2 density
        t2_nz = 0
        for b in range(32):
            truth = np.array([(int(all_t2[val, rnd]) >> b) & 1 for val in range(N)], dtype=np.uint8)
            anf = mobius(truth, n_bits)
            t2_nz += int(np.sum(anf))

        t1_d = t1_nz / (N * 32)
        t2_d = t2_nz / (N * 32)
        t1_densities.append((rnd, t1_d))
        t2_densities.append((rnd, t2_d))

        print(f"  R={rnd:2d}  | {t1_d*100:9.1f}% | {t2_d*100:9.1f}%")

    return t1_densities, t2_densities

def dual_ramp_visualization(forward_density, forward_word_density):
    """Show forward and backward ramps on the same scale."""
    print("\n" + "=" * 70)
    print("DUAL RAMP VISUALIZATION")
    print("=" * 70)

    # Forward ramp: density per round
    # Backward ramp: known fraction per round

    print(f"\n  Round-by-round: Forward density vs Backward known fraction")
    print(f"  {'Round':>5} | {'Fwd Density':>11} | {'Bwd Known':>10} | Visual")
    print(f"  {'-'*60}")

    back_known = {64: 1.0, 63: 7/8, 62: 6/8, 61: 5/8, 60: 4/8,
                  59: 4/8, 58: 4/8, 57: 4/8, 56: 4/8}

    for rnd, fwd_d in forward_density:
        bwd = back_known.get(64 - rnd + 1, None)  # Mirror: round 1 forward = round 63 backward
        bwd_from_end = back_known.get(64 - rnd, 0.5)  # approximate

        # Visual bar
        fwd_bar_len = int(fwd_d * 40)
        fwd_bar = "█" * fwd_bar_len + "░" * (40 - fwd_bar_len)

        print(f"  R={rnd:3d}  | {fwd_d*100:10.1f}% | {bwd_from_end*100:9.1f}% | {fwd_bar}")

    print(f"\n  Forward ramp:  message entropy flows IN  (0% → 50%)")
    print(f"  Backward ramp: hash knowledge flows BACK (100% → 50%)")
    print(f"  They converge to 50% from opposite directions.")

    # Per-word forward evolution
    print(f"\n  Forward word density evolution:")
    print(f"  {'Round':>5} | {'W0':>5} {'W1':>5} {'W2':>5} {'W3':>5} "
          f"{'W4':>5} {'W5':>5} {'W6':>5} {'W7':>5}")
    print(f"  {'-'*55}")
    for rnd, wd in forward_word_density:
        row = f"  R={rnd:3d}  |"
        for w in range(8):
            pct = wd[w] * 100
            if pct < 5:
                row += f" {pct:4.1f}%"
            else:
                row += f" {pct:4.0f}%"
        print(row)

    # Backward word evolution (which words are known at each step back)
    print(f"\n  Backward known words (from hash):")
    print(f"  {'From end':>8} | {'a':>3} {'b':>3} {'c':>3} {'d':>3} "
          f"{'e':>3} {'f':>3} {'g':>3} {'h':>3} | known")
    print(f"  {'-'*50}")

    # In unrolled form, going backward:
    back_states = [
        (0, [1,1,1,1,1,1,1,1], "hash output"),
        (1, [0,1,1,1,1,1,1,1], "undo R63: a=U unknown"),
        (2, [0,0,1,1,1,1,1,1], "undo R62: b=V unknown"),
        (3, [0,0,0,1,1,1,1,1], "undo R61: c=X unknown"),
        (4, [0,0,0,0,1,1,1,1], "undo R60: d=Y unknown"),
        (5, [0,0,0,0,1,1,1,1], "undo R59: T1/T2 known, a_bef59=f(U)"),
        (6, [0,0,0,0,1,1,1,1], "undo R58: needs U for T2"),
        (8, [0,0,0,0,0,0,0,0], "undo R56: all unknown"),
    ]

    for steps, known, note in back_states:
        n_known = sum(known)
        syms = ["✓" if k else "?" for k in known]
        print(f"  -{steps:7d} | {' '.join(f'{s:>3}' for s in syms)} | "
              f"{n_known}/8  {note}")

    print(f"\n{'='*70}")
    print(f"THE RAMP STRUCTURE")
    print(f"{'='*70}")
    print(f"""
  Forward (message → state):
    Each round, the message word W[t] "infects" the state via T1.
    T1 enters through a (= T1+T2) and e (= d+T1).
    The shift register propagates: a→b→c→d and e→f→g→h.
    So it takes 4 rounds for a word to reach d, and 4 more for h.
    That's why the wave takes 8 rounds to fill all 8 words.

  Backward (hash → state):
    Each undo peels off one layer.
    T2 is always computable (uses the "right" side: a,b,c or equivalents).
    T1 = (modified var) - T2 → known.
    But the ADDEND variable in T1 is lost → becomes unknown.
    One new unknown per round → 4 rounds = 4 unknowns = 50%.

  THE MATCH:
    Forward reaches 50% at round ~8 (all words saturated).
    Backward reaches 50% at round 60 (4 of 8 unknown).
    In between (rounds 8-60): BOTH are at 50%.

    The STRUCTURE is visible only at the edges:
    - Rounds 1-8: forward ramp (message structure visible)
    - Rounds 57-64: backward ramp (hash structure visible)
    - Rounds 8-57: fully mixed (no structure from either end)

  THE GAP:
    Forward gives us ~160 bits of constraint (rounds 1-8 structured)
    Backward gives us ~160 bits of constraint (rounds 57-64 structured)
    The middle ~48 rounds are a wall of 50% entropy.

    For inversion: need to bridge the gap.
    That's where the Bailey transform's structured inversion would work —
    it operates on the polynomial form, not the round-by-round state.
""")

def main():
    fwd_d, fwd_wd = compute_forward_ramp(8)
    back_known = compute_backward_ramp()
    t1_d, t2_d = compute_backward_density(8)
    dual_ramp_visualization(fwd_d, fwd_wd)

if __name__ == "__main__":
    main()
