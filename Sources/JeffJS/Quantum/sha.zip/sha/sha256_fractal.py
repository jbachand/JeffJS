#!/usr/bin/env python3
"""
SHA-256 Fractal Visualization

Each round of SHA-256 forks the computation through Ch and Maj.
Ch is a MUX: it selects f or g based on e (2 branches per bit).
Maj is a majority vote: it selects based on 2-of-3 (another fork).

Across 64 rounds, these forks create a tree structure.
The tree IS the polynomial — each leaf is one monomial.

Visualize:
- Each round as a level of the tree
- Ch forks (selector e splits into f-branch and g-branch)
- Maj forks (majority splits into consensus-branch and minority-branch)
- The tree grows and then COLLAPSES (x+x=0 cancellations prune branches)
- The surviving branches are the polynomial terms
"""

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as patches
import numpy as np
import random

M32 = 0xFFFFFFFF

def rotr32(x, n): return ((x >> n) | (x << (32 - n))) & M32
def Sig1(e): return rotr32(e,6)^rotr32(e,11)^rotr32(e,25)
def Sig0(a): return rotr32(a,2)^rotr32(a,13)^rotr32(a,22)
def Ch(e,f,g): return ((e&f)^((e^M32)&g))&M32
def Maj(a,b,c): return ((a&b)^(a&c)^(b&c))&M32

K=[0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
   0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
   0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
   0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
   0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
   0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
   0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
   0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2]
IV=[0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,
    0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19]


def build_fractal():
    """
    Build the SHA-256 fractal tree for one bit position.
    Track how a single input bit propagates through the rounds,
    forking at each Ch and Maj operation.
    """
    fig, axes = plt.subplots(1, 2, figsize=(28, 20), facecolor='#0d1117')

    random.seed(42)
    msg = [random.getrandbits(32) & M32 for _ in range(16)]

    # ═══════════════════════════════════════════════════════════
    # LEFT PANEL: The forking tree (term count per round)
    # ═══════════════════════════════════════════════════════════

    ax1 = axes[0]
    ax1.set_facecolor('#0d1117')

    # Track term counts from the symbolic composition
    # (from our earlier analysis)
    # 4 free bits:
    terms_4bit = {
        'rounds': list(range(65)),
        'terms_a': [1,2,2,3,9,9,9,12,12,12,12,12,12,13,12,12,
                    13,12,12,12,13,12,13,12,11,12,10,10,12,13,13,11,
                    13,12,12,11,14,11,12,13,13,14,14,10,14,11,12,11,
                    11,13,12,11,11,12,12,12,14,11,12,13,11,12,10,12,10],
        'terms_e': [1,2,2,2,7,7,7,5,12,12,12,12,13,12,12,12,
                    12,12,13,13,12,13,12,10,10,10,10,11,12,11,12,12,
                    12,12,13,12,11,12,11,13,13,10,13,12,12,12,12,12,
                    11,12,12,12,12,12,13,12,12,12,13,12,12,12,13,12,12]
    }

    # Possible terms at each bit count
    max_possible = {4: 16, 6: 64, 8: 256}

    rounds = list(range(64))

    # Draw the term count evolution
    ax1.fill_between(rounds, [16]*64, alpha=0.1, color='#da3633', label='Max possible (2⁴=16)')
    ax1.plot(rounds, terms_4bit['terms_a'][:64], 'o-', color='#58a6ff', markersize=3,
             linewidth=1.5, label='Terms in a (survived)', zorder=5)
    ax1.plot(rounds, terms_4bit['terms_e'][:64], 's-', color='#3fb950', markersize=3,
             linewidth=1.5, label='Terms in e (survived)', zorder=5)

    # Mark the saturation point
    ax1.axvline(x=8, color='#f0883e', linestyle='--', alpha=0.5)
    ax1.annotate('Degree saturates', xy=(8, 14), fontsize=10, color='#f0883e',
                rotation=90, va='top')

    # Mark the 16-round boundary
    ax1.axvline(x=16, color='#da3633', linestyle='--', alpha=0.5)
    ax1.annotate('16 rounds\n(schedule boundary)', xy=(16, 14), fontsize=9,
                color='#da3633', rotation=90, va='top')

    ax1.set_xlabel('Round', fontsize=12, color='#e6edf3')
    ax1.set_ylabel('Surviving polynomial terms', fontsize=12, color='#e6edf3')
    ax1.set_title('SHA-256 Polynomial Terms: Growth → Saturation → Equilibrium',
                  fontsize=14, color='#e6edf3', fontweight='bold')
    ax1.legend(loc='lower right', facecolor='#161b22', edgecolor='#30363d',
              labelcolor='#e6edf3')
    ax1.set_ylim(0, 18)
    ax1.tick_params(colors='#8b949e')
    ax1.spines['bottom'].set_color('#30363d')
    ax1.spines['left'].set_color('#30363d')
    ax1.spines['top'].set_visible(False)
    ax1.spines['right'].set_visible(False)

    # Add annotations
    ax1.annotate('Rounds 1-8:\nDegree grows\nTerms multiply',
                xy=(4, 5), fontsize=9, color='#8b949e',
                bbox=dict(boxstyle='round,pad=0.3', facecolor='#161b22', edgecolor='#30363d'))
    ax1.annotate('Rounds 8-64:\nDegree saturated\nTerms oscillate ≈50%\nx+x=0 cancels as\nfast as Ch/Maj creates',
                xy=(35, 3), fontsize=9, color='#8b949e',
                bbox=dict(boxstyle='round,pad=0.3', facecolor='#161b22', edgecolor='#30363d'))

    # ═══════════════════════════════════════════════════════════
    # RIGHT PANEL: The fractal fork tree
    # ═══════════════════════════════════════════════════════════

    ax2 = axes[1]
    ax2.set_facecolor('#0d1117')

    # Draw the fractal tree showing how Ch forks
    # Each round: input state → Ch fork (e selects f or g) → output
    # The tree shows 16 rounds of forking with cancellation

    def draw_tree(ax, max_depth=16, start_x=0.5, start_y=1.0, initial_width=0.45):
        """Draw a fractal tree where branches fork at Ch and cancel at x+x=0."""

        np.random.seed(42)

        def branch(x, y, angle, depth, width, alive_branches):
            if depth >= max_depth or width < 0.001:
                return alive_branches

            # Fork length decreases with depth
            length = 0.045 * (1 - depth/max_depth * 0.5)

            # Ch fork: two branches (f-branch and g-branch)
            # Angle spread represents the selector bit
            spread = 25 * (1 - depth/max_depth * 0.3)

            # Left branch (g-selected, where e=0)
            angle_l = angle + spread
            x_l = x + length * np.sin(np.radians(angle_l))
            y_l = y - length * np.cos(np.radians(angle_l))

            # Right branch (f-selected, where e=1)
            angle_r = angle - spread
            x_r = x + length * np.sin(np.radians(angle_r))
            y_r = y - length * np.cos(np.radians(angle_r))

            # Color: green for surviving branches, dim for cancelled
            # At saturation (~50% survive), randomly cancel half
            survive_l = True
            survive_r = True
            if depth >= 4:  # after saturation
                # ~50% cancellation rate
                if np.random.random() < 0.5:
                    survive_l = False
                if np.random.random() < 0.5:
                    survive_r = False
                # But ensure at least one survives (function is not zero)
                if not survive_l and not survive_r:
                    if np.random.random() < 0.5:
                        survive_l = True
                    else:
                        survive_r = True

            # Draw branches
            w = max(0.3, width * 0.85)

            if survive_l:
                color_l = plt.cm.cool(depth / max_depth)
                ax.plot([x, x_l], [y, y_l], color=color_l, linewidth=w, alpha=0.8, solid_capstyle='round')
                alive_branches = branch(x_l, y_l, angle_l, depth + 1, width * 0.7, alive_branches + 1)
            else:
                ax.plot([x, x_l], [y, y_l], color='#da3633', linewidth=w*0.5, alpha=0.15, solid_capstyle='round')

            if survive_r:
                color_r = plt.cm.cool(depth / max_depth)
                ax.plot([x, x_r], [y, y_r], color=color_r, linewidth=w, alpha=0.8, solid_capstyle='round')
                alive_branches = branch(x_r, y_r, angle_r, depth + 1, width * 0.7, alive_branches + 1)
            else:
                ax.plot([x, x_r], [y, y_r], color='#da3633', linewidth=w*0.5, alpha=0.15, solid_capstyle='round')

            return alive_branches

        # Draw the root
        ax.plot([start_x, start_x], [start_y, start_y - 0.03], color='#e6edf3',
               linewidth=2, solid_capstyle='round')

        total = branch(start_x, start_y - 0.03, 0, 0, 3.0, 1)
        return total

    total_branches = draw_tree(ax2)

    ax2.set_xlim(0, 1)
    ax2.set_ylim(0, 1.05)
    ax2.set_aspect('equal')
    ax2.axis('off')
    ax2.set_title('SHA-256 Fork Tree: Ch/Maj Branching with x⊕x=0 Cancellation',
                  fontsize=14, color='#e6edf3', fontweight='bold', pad=20)

    # Add round labels on the right side
    for r in range(0, 16):
        y_pos = 1.0 - 0.03 - r * 0.045 * (1 - r/32)
        if y_pos > 0.1:
            ax2.text(0.98, y_pos, f'R{r}', fontsize=7, color='#8b949e',
                    ha='right', va='center')

    # Legend
    ax2.text(0.02, 0.08, 'Bright = surviving terms (the polynomial)',
            fontsize=9, color='#58a6ff', transform=ax2.transAxes)
    ax2.text(0.02, 0.04, 'Dim red = cancelled terms (x⊕x = 0)',
            fontsize=9, color='#da3633', transform=ax2.transAxes)
    ax2.text(0.02, 0.00, f'~50% survive at equilibrium — the Bailey structure',
            fontsize=9, color='#f0883e', transform=ax2.transAxes)

    plt.tight_layout()
    plt.savefig('sha256_fractal.png', dpi=150, bbox_inches='tight', facecolor='#0d1117')
    plt.close()
    print("Saved: sha256_fractal.png")

    # ═══════════════════════════════════════════════════════════
    # SECOND FIGURE: The full state evolution
    # ═══════════════════════════════════════════════════════════

    fig2, ax3 = plt.subplots(1, 1, figsize=(24, 14), facecolor='#0d1117')
    ax3.set_facecolor('#0d1117')

    # Run actual SHA-256 and track bit differences
    # For each round: how many bits change from the previous state?
    random.seed(42)
    msg = [random.getrandbits(32) & M32 for _ in range(16)]

    # Run SHA-256
    W = list(msg)
    for t in range(16, 64):
        s0 = rotr32(W[t-15],7) ^ rotr32(W[t-15],18) ^ (W[t-15]>>3)
        s1 = rotr32(W[t-2],17) ^ rotr32(W[t-2],19) ^ (W[t-2]>>10)
        W.append((W[t-16]+s0+W[t-7]+s1) & M32)

    a,b,c,d,e,f,g,h = IV
    states = []

    for t in range(64):
        states.append([a,b,c,d,e,f,g,h])
        T1 = (h+Sig1(e)+Ch(e,f,g)+K[t]+W[t]) & M32
        T2 = (Sig0(a)+Maj(a,b,c)) & M32
        h=g;g=f;f=e;e=(d+T1)&M32;d=c;c=b;b=a;a=(T1+T2)&M32

    states.append([a,b,c,d,e,f,g,h])

    # Visualize each state as a heatmap row
    # Each row = one round, columns = 256 bits of state (8 words × 32 bits)
    bit_matrix = np.zeros((65, 256))
    for t in range(65):
        for wi in range(8):
            for bi in range(32):
                bit_matrix[t, wi*32 + bi] = (states[t][wi] >> bi) & 1

    # XOR delta (how bits change between rounds)
    delta_matrix = np.zeros((64, 256))
    for t in range(64):
        for col in range(256):
            delta_matrix[t, col] = bit_matrix[t+1, col] != bit_matrix[t, col]

    # Create the heatmap
    im = ax3.imshow(delta_matrix, aspect='auto', cmap='inferno',
                    interpolation='nearest', extent=[0, 256, 64, 0])

    # Add state variable labels
    for wi, name in enumerate(['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h']):
        ax3.axvline(x=wi*32, color='#30363d', linewidth=0.5, alpha=0.5)
        ax3.text(wi*32 + 16, -1.5, name, fontsize=12, color='#e6edf3',
                ha='center', fontweight='bold')

    # Mark the left/right split
    ax3.axvline(x=128, color='#58a6ff', linewidth=2, alpha=0.7)
    ax3.text(64, -3.5, 'LEFT (Maj side)', fontsize=11, color='#58a6ff',
            ha='center', fontweight='bold')
    ax3.text(192, -3.5, 'RIGHT (Ch side)', fontsize=11, color='#3fb950',
            ha='center', fontweight='bold')

    # Mark round 16
    ax3.axhline(y=16, color='#f0883e', linewidth=1.5, linestyle='--', alpha=0.7)
    ax3.text(260, 16, 'Round 16\n(degree saturates)', fontsize=9, color='#f0883e', va='center')

    # Mark the shift register pattern
    ax3.annotate('Shift register:\nb→c→d (copy)\nf→g→h (copy)',
                xy=(96, 50), fontsize=9, color='#8b949e',
                bbox=dict(boxstyle='round,pad=0.3', facecolor='#161b22', edgecolor='#30363d'))

    ax3.annotate('Active computation:\na (T1+T2)\ne (d+T1)',
                xy=(10, 50), fontsize=9, color='#f0883e',
                bbox=dict(boxstyle='round,pad=0.3', facecolor='#161b22', edgecolor='#30363d'))

    ax3.set_xlabel('Bit position (8 words × 32 bits)', fontsize=12, color='#e6edf3')
    ax3.set_ylabel('Round', fontsize=12, color='#e6edf3')
    ax3.set_title('SHA-256 State Evolution: Bit Changes Per Round\n'
                  'Bright = bit flipped, Dark = unchanged',
                  fontsize=14, color='#e6edf3', fontweight='bold')
    ax3.tick_params(colors='#8b949e')

    plt.colorbar(im, ax=ax3, label='Bit changed', fraction=0.02, pad=0.02)

    plt.tight_layout()
    plt.savefig('sha256_state_evolution.png', dpi=150, bbox_inches='tight', facecolor='#0d1117')
    plt.close()
    print("Saved: sha256_state_evolution.png")


if __name__ == "__main__":
    build_fractal()
