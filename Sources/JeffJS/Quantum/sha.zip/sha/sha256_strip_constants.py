#!/usr/bin/env python3
"""
Strip K and IV from SHA-256 and observe the weight matrix.

Hypothesis: The sqrt/cbrt constants are what randomize the polynomial
to 50% fill. Without them, the underlying algebraic structure should
be visible — possibly showing the "ramp" pattern the user describes.

Test variants:
1. Full SHA-256 (baseline)
2. K=0, IV=0 (bare structure)
3. K=0, IV=standard (no round constants)
4. K=standard, IV=0 (no initial state)
5. K=all same constant, IV=standard (flat K)
"""

import hashlib
import numpy as np
from math import comb
import time
import struct

M32 = 0xFFFFFFFF

def rotr(x, n): return ((x >> n) | (x << (32 - n))) & M32
def shr(x, n): return x >> n
def Sigma1(x): return rotr(x, 6) ^ rotr(x, 11) ^ rotr(x, 25)
def Sigma0(x): return rotr(x, 2) ^ rotr(x, 13) ^ rotr(x, 22)
def sigma1(x): return rotr(x, 17) ^ rotr(x, 19) ^ shr(x, 10)
def sigma0(x): return rotr(x, 7) ^ rotr(x, 18) ^ shr(x, 3)
def Ch(e, f, g): return (e & f) ^ ((~e) & g) & M32
def Maj(a, b, c): return (a & b) ^ (a & c) ^ (b & c)

K_STANDARD = [
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5,
    0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3,
    0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
    0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7,
    0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13,
    0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3,
    0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5,
    0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
    0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
]
IV_STANDARD = [0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
               0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19]

def sha256_custom(msg_byte, K_vals, IV_vals):
    """SHA-256 compression with custom K and IV."""
    # Pad single byte to 512-bit block (same as hashlib)
    msg = bytes([msg_byte])
    padded = msg + b'\x80' + b'\x00' * 54 + struct.pack('>Q', 8)
    W = list(struct.unpack('>16I', padded))
    for t in range(16, 64):
        W.append((sigma1(W[t-2]) + W[t-7] + sigma0(W[t-15]) + W[t-16]) & M32)

    a, b, c, d, e, f, g, h = IV_vals
    for t in range(64):
        T1 = (h + Sigma1(e) + Ch(e, f, g) + K_vals[t] + W[t]) & M32
        T2 = (Sigma0(a) + Maj(a, b, c)) & M32
        h=g; g=f; f=e; e=(d+T1)&M32; d=c; c=b; b=a; a=(T1+T2)&M32

    return tuple((s + iv) & M32 for s, iv in zip([a,b,c,d,e,f,g,h], IV_vals))

def hash_to_bits_256(hash_words):
    """Convert 8 × 32-bit words to 256 bits."""
    bits = np.zeros(256, dtype=np.uint8)
    for w in range(8):
        for b in range(32):
            bits[w*32 + b] = (hash_words[w] >> b) & 1
    return bits

def mobius_transform(Y, n_bits):
    a = Y.copy()
    for i in range(n_bits):
        mask = 1 << i
        for x in range(len(a)):
            if x & mask:
                a[x] ^= a[x ^ mask]
    return a

def analyze_variant(name, K_vals, IV_vals, n_bits=8):
    N = 1 << n_bits
    OUT_BITS = 256

    print(f"\n{'─'*70}")
    print(f"  {name}")
    print(f"{'─'*70}")

    # Generate hashes
    Y = np.zeros((N, OUT_BITS), dtype=np.uint8)
    for val in range(N):
        h = sha256_custom(val, K_vals, IV_vals)
        Y[val] = hash_to_bits_256(h)

    # ANF extraction
    W = np.zeros_like(Y)
    for ob in range(OUT_BITS):
        W[:, ob] = mobius_transform(Y[:, ob], n_bits)

    # Verify roundtrip
    Y_check = np.zeros_like(Y)
    for ob in range(OUT_BITS):
        Y_check[:, ob] = mobius_transform(W[:, ob], n_bits)
    assert np.array_equal(Y_check, Y), "Roundtrip failed!"

    # === ANALYSIS ===
    total = int(np.sum(W))
    density = total / W.size
    terms_per_bit = np.sum(W, axis=0).astype(float)

    print(f"  Density: {density*100:.1f}% (random=50%)")
    print(f"  Terms/bit: {np.mean(terms_per_bit):.1f} ± {np.std(terms_per_bit):.1f} "
          f"(random={N/2:.0f} ± {np.sqrt(N)/2:.1f})")

    # Degree distribution
    degree_counts = np.zeros(n_bits + 1, dtype=np.int64)
    degree_fill = np.zeros(n_bits + 1)
    for m in range(N):
        deg = bin(m).count('1')
        degree_counts[deg] += int(np.sum(W[m, :]))

    print(f"\n  Degree distribution:")
    max_count = max(degree_counts) if max(degree_counts) > 0 else 1
    for d in range(n_bits + 1):
        n_possible = comb(n_bits, d) * OUT_BITS
        fill = degree_counts[d] / n_possible * 100 if n_possible > 0 else 0
        pct = degree_counts[d] / total * 100 if total > 0 else 0
        bar_len = int(degree_counts[d] / max_count * 30)
        bar = "█" * bar_len
        print(f"    deg {d:2d}: {degree_counts[d]:6,} ({pct:5.1f}%) "
              f"fill={fill:5.1f}% {bar}")

    # Unused monomials
    mono_pop = np.sum(W, axis=1)
    n_unused = int(np.sum(mono_pop == 0))
    print(f"\n  Unused monomials: {n_unused}/{N} ({n_unused/N*100:.1f}%)")

    # Check for block structure in W
    # Look at each 32-bit output word
    print(f"\n  Per-word density:")
    for w in range(8):
        word_slice = W[:, w*32:(w+1)*32]
        word_density = np.sum(word_slice) / word_slice.size
        print(f"    Word {w}: {word_density*100:.1f}%")

    # Low-degree term analysis
    print(f"\n  Low-degree terms (these reveal structure):")
    # Degree 0 = constant term (monomial index 0)
    const_bits = W[0, :]
    n_const = int(np.sum(const_bits))
    print(f"    Constant (deg 0): {n_const}/256 output bits have constant=1")

    # Degree 1 = linear terms
    linear_active = 0
    for b in range(n_bits):
        m = 1 << b
        n_active = int(np.sum(W[m, :]))
        if n_active > 0:
            linear_active += 1
    print(f"    Linear (deg 1): {linear_active}/{n_bits} input bits appear in linear terms")

    return {
        'name': name,
        'density': density,
        'degree_counts': degree_counts.tolist(),
        'terms_per_bit': float(np.mean(terms_per_bit)),
        'n_unused': n_unused,
        'W': W,
    }

def visualize_matrix(W, name, n_bits):
    """Print a compact visualization of the weight matrix."""
    N = W.shape[0]
    OUT = W.shape[1]

    # Compress to a small grid: group monomials by degree, output by word
    print(f"\n  Weight matrix heatmap ({name}):")
    print(f"  Rows = monomial degree (0..{n_bits}), Cols = hash word (0..7)")
    print(f"  Value = fill % at that (degree, word) block")
    print()

    header = "       " + "".join(f"  W{w}  " for w in range(8))
    print(header)
    print("       " + "------" * 8)

    for d in range(n_bits + 1):
        row = f"  d={d:2d} |"
        for w in range(8):
            # Get all monomials of degree d, all bits in word w
            mono_indices = [m for m in range(N) if bin(m).count('1') == d]
            bit_indices = list(range(w*32, (w+1)*32))
            if len(mono_indices) == 0:
                row += "  --  "
                continue
            block = W[np.ix_(mono_indices, bit_indices)]
            fill = np.sum(block) / block.size * 100
            # Color code
            if fill < 10:
                row += f" {fill:4.0f}% "
            elif fill < 40:
                row += f" {fill:4.0f}%▪"
            elif fill < 60:
                row += f" {fill:4.0f}%█"
            elif fill < 90:
                row += f" {fill:4.0f}%▪"
            else:
                row += f" {fill:4.0f}% "
        print(row)

def main():
    N_BITS = 8

    # Verify our custom implementation matches hashlib
    print("Verifying custom SHA-256 matches hashlib...")
    for v in [0, 1, 42, 255]:
        custom = sha256_custom(v, K_STANDARD, IV_STANDARD)
        official = hashlib.sha256(bytes([v])).digest()
        custom_bytes = b''.join(w.to_bytes(4, 'big') for w in custom)
        assert custom_bytes == official, f"Mismatch at {v}!"
    print("✓ Verified\n")

    results = []

    # 1. Standard SHA-256
    r1 = analyze_variant("STANDARD SHA-256 (baseline)", K_STANDARD, IV_STANDARD, N_BITS)
    results.append(r1)
    visualize_matrix(r1['W'], "standard", N_BITS)

    # 2. K=0, IV=0 (bare algebraic structure)
    K_ZERO = [0] * 64
    IV_ZERO = [0] * 8
    r2 = analyze_variant("K=0, IV=0 (bare structure)", K_ZERO, IV_ZERO, N_BITS)
    results.append(r2)
    visualize_matrix(r2['W'], "K=0 IV=0", N_BITS)

    # 3. K=0, IV=standard
    r3 = analyze_variant("K=0, IV=standard", K_ZERO, IV_STANDARD, N_BITS)
    results.append(r3)
    visualize_matrix(r3['W'], "K=0", N_BITS)

    # 4. K=standard, IV=0
    r4 = analyze_variant("K=standard, IV=0", K_STANDARD, IV_ZERO, N_BITS)
    results.append(r4)
    visualize_matrix(r4['W'], "IV=0", N_BITS)

    # 5. K=constant (same value every round)
    K_FLAT = [0x428a2f98] * 64  # K[0] repeated
    r5 = analyze_variant("K=flat (same every round)", K_FLAT, IV_STANDARD, N_BITS)
    results.append(r5)

    # 6. Only first 16 rounds (before schedule expansion matters)
    def sha256_16rounds(msg_byte, K_vals, IV_vals):
        msg = bytes([msg_byte])
        padded = msg + b'\x80' + b'\x00' * 54 + struct.pack('>Q', 8)
        W = list(struct.unpack('>16I', padded))
        a, b, c, d, e, f, g, h = IV_vals
        for t in range(16):  # Only 16 rounds!
            T1 = (h + Sigma1(e) + Ch(e, f, g) + K_vals[t] + W[t]) & M32
            T2 = (Sigma0(a) + Maj(a, b, c)) & M32
            h=g; g=f; f=e; e=(d+T1)&M32; d=c; c=b; b=a; a=(T1+T2)&M32
        return tuple((s + iv) & M32 for s, iv in zip([a,b,c,d,e,f,g,h], IV_vals))

    # Custom variant for 16 rounds
    N = 1 << N_BITS
    Y16 = np.zeros((N, 256), dtype=np.uint8)
    for val in range(N):
        h = sha256_16rounds(val, K_STANDARD, IV_STANDARD)
        Y16[val] = hash_to_bits_256(h)
    W16 = np.zeros_like(Y16)
    for ob in range(256):
        W16[:, ob] = mobius_transform(Y16[:, ob], N_BITS)
    total16 = int(np.sum(W16))
    print(f"\n{'─'*70}")
    print(f"  16 ROUNDS ONLY (K=standard, IV=standard)")
    print(f"{'─'*70}")
    print(f"  Density: {total16/W16.size*100:.1f}%")
    deg_counts_16 = np.zeros(N_BITS+1, dtype=np.int64)
    for m in range(N):
        deg = bin(m).count('1')
        deg_counts_16[deg] += int(np.sum(W16[m, :]))
    print(f"  Degree distribution:")
    for d in range(N_BITS+1):
        n_poss = comb(N_BITS, d) * 256
        fill = deg_counts_16[d] / n_poss * 100 if n_poss > 0 else 0
        pct = deg_counts_16[d] / total16 * 100 if total16 > 0 else 0
        print(f"    deg {d}: {deg_counts_16[d]:6,} ({pct:5.1f}%) fill={fill:5.1f}%")
    visualize_matrix(W16, "16 rounds", N_BITS)

    # 16 rounds, K=0, IV=0
    Y16bare = np.zeros((N, 256), dtype=np.uint8)
    for val in range(N):
        h = sha256_16rounds(val, K_ZERO, IV_ZERO)
        Y16bare[val] = hash_to_bits_256(h)
    W16bare = np.zeros_like(Y16bare)
    for ob in range(256):
        W16bare[:, ob] = mobius_transform(Y16bare[:, ob], N_BITS)
    total16b = int(np.sum(W16bare))
    print(f"\n{'─'*70}")
    print(f"  16 ROUNDS, K=0, IV=0 (bare 16-round structure)")
    print(f"{'─'*70}")
    print(f"  Density: {total16b/W16bare.size*100:.1f}%")
    deg_counts_16b = np.zeros(N_BITS+1, dtype=np.int64)
    for m in range(N):
        deg = bin(m).count('1')
        deg_counts_16b[deg] += int(np.sum(W16bare[m, :]))
    print(f"  Degree distribution:")
    for d in range(N_BITS+1):
        n_poss = comb(N_BITS, d) * 256
        fill = deg_counts_16b[d] / n_poss * 100 if n_poss > 0 else 0
        pct = deg_counts_16b[d] / total16b * 100 if total16b > 0 else 0
        print(f"    deg {d}: {deg_counts_16b[d]:6,} ({pct:5.1f}%) fill={fill:5.1f}%")
    visualize_matrix(W16bare, "16r bare", N_BITS)

    # === COMPARISON ===
    print(f"\n{'='*70}")
    print(f"COMPARISON: How constants affect structure")
    print(f"{'='*70}")
    print(f"\n{'Name':40s} | {'Density':>8} | {'Unused':>7} | {'Const':>5} | {'Linear':>6}")
    print("-" * 75)
    for r in results:
        const_bits = int(np.sum(r['W'][0, :]))
        linear = sum(1 for b in range(N_BITS) if np.sum(r['W'][1<<b, :]) > 0)
        print(f"{r['name']:40s} | {r['density']*100:7.1f}% | {r['n_unused']:5d}/{N} | "
              f"{const_bits:5d} | {linear:4d}/{N_BITS}")

if __name__ == "__main__":
    main()
