#!/usr/bin/env python3
"""
SHA-256 Backdoor Hunt — Applying Dual_EC_DRBG Lessons

Dual_EC pattern:
  - Two "independent" constants with a hidden scalar relationship
  - Q = e * P, where e is the secret
  - One number unlocks the reverse direction

Applied to SHA-256:
  - K values (cube roots of primes) and IV (square roots of primes)
  - Both derived from primes — suspicious that they share the same source
  - What hidden relationships exist between K and IV?

We search for:
  1. Scalar relationships between K values and IV
  2. Linear recurrence in K values (mod 2^32)
  3. Block-level structure (K values in groups of 16)
  4. Relationships between K sums and IV values
  5. The "secret e" — a single number that transforms K into something simple
"""

import math

# ═══════════════════════════════════════════════════════════════
# Constants — regenerated from scratch to verify
# ═══════════════════════════════════════════════════════════════

def generate_k():
    """Generate K from cube roots of first 64 primes."""
    primes = []
    n = 2
    while len(primes) < 64:
        if all(n % p != 0 for p in primes):
            primes.append(n)
        n += 1
    return [int((n ** (1/3) % 1) * 2**32) & 0xFFFFFFFF for n in primes]

def generate_iv():
    """Generate IV from square roots of first 8 primes."""
    primes = [2, 3, 5, 7, 11, 13, 17, 19]
    return [int((math.sqrt(n) % 1) * 2**32) & 0xFFFFFFFF for n in primes]

K = [
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5,
    0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3,
    0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
    0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7,
    0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13,
    0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3,
    0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5,
    0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
    0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
]

IV = [
    0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
    0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19,
]

M32 = 0xFFFFFFFF

def main():
    print("═" * 72)
    print("  SHA-256 Backdoor Hunt: Dual_EC Analogy")
    print("═" * 72)

    # ═══════════════════════════════════════════════════════════
    # TEST 1: Verify constants match the derivation
    # ═══════════════════════════════════════════════════════════
    print(f"\n  TEST 1: Verify K and IV derivation from primes")
    print(f"  {'─' * 66}")

    k_gen = generate_k()
    iv_gen = generate_iv()

    k_match = sum(1 for a, b in zip(K, k_gen) if a == b)
    iv_match = sum(1 for a, b in zip(IV, iv_gen) if a == b)
    print(f"  K values match cube roots: {k_match}/64")
    print(f"  IV values match square roots: {iv_match}/8")
    if k_match < 64 or iv_match < 8:
        print(f"  ⚠ Precision issues in float derivation (expected)")
        print(f"    Using hardcoded NIST values for analysis")

    # ═══════════════════════════════════════════════════════════
    # TEST 2: Scalar relationships between K and IV
    # (Dual_EC had Q = e * P — one scalar linking two constants)
    # ═══════════════════════════════════════════════════════════
    print(f"\n  TEST 2: Search for scalar 'e' linking K to IV")
    print(f"  If K[i] = e * IV[j] mod 2³², there's a Dual_EC-style link")
    print(f"  {'─' * 66}")

    # For each (K[i], IV[j]) pair, compute the "scalar" e = K[i] * IV[j]^(-1) mod 2^32
    # Then check if that same e relates OTHER pairs
    from collections import Counter

    def modinv(a, m=2**32):
        """Modular inverse (only exists for odd a)."""
        if a % 2 == 0:
            return None
        # Extended Euclidean
        g, x, _ = extended_gcd(a % m, m)
        if g != 1:
            return None
        return x % m

    def extended_gcd(a, b):
        if a == 0:
            return b, 0, 1
        g, x, y = extended_gcd(b % a, a)
        return g, y - (b // a) * x, x

    # Compute all possible e values from K[i] = e * IV[j] mod 2^32
    e_values = Counter()
    e_details = {}

    for j in range(8):
        inv_iv = modinv(IV[j])
        if inv_iv is None:
            continue
        for i in range(64):
            e = (K[i] * inv_iv) % (2**32)
            e_values[e] += 1
            if e not in e_details:
                e_details[e] = []
            e_details[e].append((i, j))

    # Check if any e value appears more than once (would indicate structure)
    most_common = e_values.most_common(10)
    print(f"\n  Most repeated 'e' values (K[i] = e × IV[j] mod 2³²):")
    found_pattern = False
    for e, count in most_common:
        if count > 1:
            found_pattern = True
            pairs = e_details[e][:4]
            pair_str = ", ".join(f"K[{i}]/IV[{j}]" for i, j in pairs)
            print(f"    e = 0x{e:08x}: appears {count}× — {pair_str}")
    if not found_pattern:
        print(f"    No repeated e values. No simple K = e*IV relationship.")

    # ═══════════════════════════════════════════════════════════
    # TEST 3: K-block sums and their relationship to IV
    # ═══════════════════════════════════════════════════════════
    print(f"\n  TEST 3: K-block structure (groups of 16)")
    print(f"  {'─' * 66}")

    blocks = [K[i:i+16] for i in range(0, 64, 16)]
    block_sums = [(sum(b) % 2**32) for b in blocks]
    block_xors = [0] * 4
    for bi, b in enumerate(blocks):
        x = 0
        for v in b:
            x ^= v
        block_xors[bi] = x

    print(f"\n  Block sums (mod 2³²):")
    for i, s in enumerate(block_sums):
        print(f"    Block {i} (K[{i*16}..{i*16+15}]): sum = 0x{s:08x}")

    print(f"\n  Block XORs:")
    for i, x in enumerate(block_xors):
        print(f"    Block {i}: XOR = 0x{x:08x}")

    # Check if block sums relate to IV
    print(f"\n  Block sums vs IV values:")
    for i, s in enumerate(block_sums):
        for j, iv in enumerate(IV):
            diff = (s - iv) % 2**32
            xor = s ^ iv
            if bin(diff).count('1') <= 4 or bin(xor).count('1') <= 4:
                print(f"    ★ Block sum {i} and IV[{j}] differ by only "
                      f"{bin(xor).count('1')} bits!")

    # Total sum of all K
    total_k = sum(K) % 2**32
    total_iv = sum(IV) % 2**32
    print(f"\n  Sum of all K: 0x{total_k:08x}")
    print(f"  Sum of all IV: 0x{total_iv:08x}")
    print(f"  K_sum XOR IV_sum: 0x{(total_k ^ total_iv):08x}")
    print(f"  K_sum + IV_sum mod 2³²: 0x{((total_k + total_iv) % 2**32):08x}")

    # ═══════════════════════════════════════════════════════════
    # TEST 4: Linear recurrence in K values
    # Does K satisfy K[t] = a*K[t-1] + b*K[t-2] + c mod 2^32?
    # ═══════════════════════════════════════════════════════════
    print(f"\n  TEST 4: Linear recurrence search in K values")
    print(f"  Looking for K[t] = a×K[t-1] + b×K[t-2] + c (mod 2³²)")
    print(f"  {'─' * 66}")

    # Try to solve for (a, b, c) using first 3 equations
    # K[2] = a*K[1] + b*K[0] + c
    # K[3] = a*K[2] + b*K[1] + c
    # K[4] = a*K[3] + b*K[2] + c
    # This is a 3x3 system mod 2^32

    found_recurrence = False
    # Brute search for simple small multipliers
    for a_test in range(-3, 4):
        for b_test in range(-3, 4):
            c_test = (K[2] - a_test * K[1] - b_test * K[0]) % 2**32
            # Check if this works for K[3], K[4], K[5]
            valid = True
            for t in range(3, min(10, 64)):
                predicted = (a_test * K[t-1] + b_test * K[t-2] + c_test) % 2**32
                if predicted != K[t]:
                    valid = False
                    break
            if valid:
                print(f"  ★ FOUND: K[t] = {a_test}×K[t-1] + {b_test}×K[t-2] + 0x{c_test:08x}")
                found_recurrence = True

    if not found_recurrence:
        print(f"  No simple (a,b,c) recurrence found.")

    # ═══════════════════════════════════════════════════════════
    # TEST 5: Multiplicative relationships between K values
    # ═══════════════════════════════════════════════════════════
    print(f"\n  TEST 5: Multiplicative relationships between K values")
    print(f"  K[i] × K[j] mod 2³² = K[k] ?")
    print(f"  {'─' * 66}")

    k_set = set(K)
    mult_hits = []
    for i in range(64):
        for j in range(i+1, 64):
            prod = (K[i] * K[j]) % 2**32
            if prod in k_set:
                k_idx = K.index(prod)
                mult_hits.append((i, j, k_idx))

    if mult_hits:
        for i, j, k in mult_hits[:5]:
            print(f"    K[{i}] × K[{j}] = K[{k}]  (mod 2³²)")
    else:
        print(f"  No K[i] × K[j] = K[k] relationships found.")

    # ═══════════════════════════════════════════════════════════
    # TEST 6: K values as polynomial evaluations
    # If K[i] = P(prime_i) for some polynomial P, the structure is algebraic
    # ═══════════════════════════════════════════════════════════
    print(f"\n  TEST 6: K values as polynomial evaluations")
    print(f"  Are the K values evaluations of a low-degree polynomial")
    print(f"  at the prime numbers, mod 2³²?")
    print(f"  {'─' * 66}")

    primes = []
    n = 2
    while len(primes) < 64:
        if all(n % p != 0 for p in primes):
            primes.append(n)
        n += 1

    # Check: K[i] = a*p_i + b mod 2^32 (degree 1)?
    if primes[1] != primes[0]:
        a_cand = ((K[1] - K[0]) * modinv((primes[1] - primes[0]) % 2**32, 2**32)) % 2**32 if modinv((primes[1] - primes[0]) % 2**32, 2**32) else None
        if a_cand:
            b_cand = (K[0] - a_cand * primes[0]) % 2**32
            matches = sum(1 for i in range(64) if (a_cand * primes[i] + b_cand) % 2**32 == K[i])
            print(f"  Linear fit K[i] = a×p + b: {matches}/64 match")
        else:
            print(f"  Can't compute linear fit (even difference)")

    # ═══════════════════════════════════════════════════════════
    # TEST 7: The Dual_EC exact analogy
    # In Dual_EC: Q = e × P on elliptic curve
    # In SHA-256: Is there e such that K_block[i] = e × K_block[i-1] mod 2^32
    #             (treating each 16-round block's K as a "point")?
    # ═══════════════════════════════════════════════════════════
    print(f"\n  TEST 7: Block-to-block scalar relationship")
    print(f"  Is there 'e' such that K_block_B = e × K_block_A (element-wise)?")
    print(f"  {'─' * 66}")

    for bi in range(3):
        bj = bi + 1
        block_a = blocks[bi]
        block_b = blocks[bj]
        # For each element, compute e = B[k] * A[k]^(-1) mod 2^32
        e_candidates = []
        for k in range(16):
            inv = modinv(block_a[k])
            if inv:
                e = (block_b[k] * inv) % 2**32
                e_candidates.append(e)
        if e_candidates:
            # Check if all e values are the same
            if len(set(e_candidates)) == 1:
                print(f"  ★ Block {bi} → Block {bj}: UNIFORM e = 0x{e_candidates[0]:08x}")
            else:
                unique = len(set(e_candidates))
                print(f"    Block {bi} → Block {bj}: {unique} different e values (no uniform scalar)")

    # ═══════════════════════════════════════════════════════════
    # TEST 8: Additive relationships
    # K[i] + K[j] = K[k] or K[i] + K[j] = IV[m] ?
    # ═══════════════════════════════════════════════════════════
    print(f"\n  TEST 8: Additive closure")
    print(f"  K[i] + K[j] = K[k] mod 2³² ?")
    print(f"  K[i] + K[j] = IV[m] mod 2³² ?")
    print(f"  {'─' * 66}")

    add_k_hits = 0
    add_iv_hits = []
    iv_set = set(IV)

    for i in range(64):
        for j in range(i, 64):
            s = (K[i] + K[j]) % 2**32
            if s in k_set and s != K[i] and s != K[j]:
                add_k_hits += 1
            if s in iv_set:
                add_iv_hits.append((i, j, IV.index(s)))

    print(f"  K[i] + K[j] = K[k]: {add_k_hits} hits")
    if add_iv_hits:
        print(f"  K[i] + K[j] = IV[m]: {len(add_iv_hits)} hits!")
        for i, j, m in add_iv_hits[:5]:
            print(f"    K[{i}] + K[{j}] = IV[{m}]  "
                  f"(0x{K[i]:08x} + 0x{K[j]:08x} = 0x{IV[m]:08x})")
    else:
        print(f"  K[i] + K[j] = IV[m]: 0 hits")

    # ═══════════════════════════════════════════════════════════
    # TEST 9: XOR relationships
    # ═══════════════════════════════════════════════════════════
    print(f"\n  TEST 9: XOR relationships")
    print(f"  K[i] ⊕ K[j] = K[k] or IV[m] ?")
    print(f"  {'─' * 66}")

    xor_k = 0
    xor_iv = []
    for i in range(64):
        for j in range(i+1, 64):
            x = K[i] ^ K[j]
            if x in k_set:
                xor_k += 1
            if x in iv_set:
                xor_iv.append((i, j, IV.index(x)))

    print(f"  K[i] ⊕ K[j] = K[k]: {xor_k} hits")
    if xor_iv:
        print(f"  K[i] ⊕ K[j] = IV[m]: {len(xor_iv)} hits!")
        for i, j, m in xor_iv[:5]:
            print(f"    K[{i}] ⊕ K[{j}] = IV[{m}]  "
                  f"(0x{K[i]:08x} ⊕ 0x{K[j]:08x} = 0x{IV[m]:08x})")
    else:
        print(f"  K[i] ⊕ K[j] = IV[m]: 0 hits")

    # ═══════════════════════════════════════════════════════════
    # TEST 10: Consecutive K differences — is the sequence structured?
    # ═══════════════════════════════════════════════════════════
    print(f"\n  TEST 10: Consecutive K differences")
    print(f"  D[i] = K[i+1] - K[i] mod 2³²")
    print(f"  {'─' * 66}")

    diffs = [(K[i+1] - K[i]) % 2**32 for i in range(63)]
    diff_set = set(diffs)
    print(f"  {len(diff_set)} unique differences out of 63")

    # Check if differences repeat
    diff_counts = Counter(diffs)
    repeated = [(d, c) for d, c in diff_counts.items() if c > 1]
    if repeated:
        print(f"  Repeated differences:")
        for d, c in sorted(repeated, key=lambda x: -x[1])[:5]:
            indices = [i for i in range(63) if diffs[i] == d]
            print(f"    0x{d:08x} appears {c}×: at positions {indices}")
    else:
        print(f"  All differences are unique.")

    # ═══════════════════════════════════════════════════════════
    # TEST 11: Do K values form a group under any operation?
    # Check: K[i] * K[j] mod p = K[(i+j) mod 64]? (multiplicative group)
    # ═══════════════════════════════════════════════════════════
    print(f"\n  TEST 11: Group structure search")
    print(f"  Does K[i] ★ K[j] = K[f(i,j)] for some operation ★?")
    print(f"  {'─' * 66}")

    # Check if K is a permutation of a geometric sequence: K[i] = g^i mod m
    # If so, K[i]*K[j] = K[i+j mod ord(g)]
    # Test: K[1]^i mod 2^32 = K[i]?
    g = K[1]
    power = 1
    geo_match = 0
    for i in range(64):
        if power == K[i]:
            geo_match += 1
        power = (power * g) % 2**32

    print(f"  Geometric sequence K[1]^i mod 2³²: {geo_match}/64 match")

    # ═══════════════════════════════════════════════════════════
    # Summary
    # ═══════════════════════════════════════════════════════════
    print(f"\n{'═' * 72}")
    print(f"  DUAL_EC → SHA-256 MAPPING")
    print(f"{'═' * 72}")
    print(f"""
  Dual_EC_DRBG:                    SHA-256:
  ─────────────                    ────────
  Two curve points P, Q            64 K values + 8 IV values
  Both "from standards"            Both "from prime roots"
  Secret: Q = e × P               Secret: ???
  e is ONE scalar                  ??? might be one number too
  Enables: output → state          Would enable: hash → message

  The Dual_EC lesson:
    The backdoor was a SIMPLE ALGEBRAIC RELATIONSHIP
    between two constants that looked independent.

  If SHA-256 has the same:
    There's a simple relationship between K and IV
    (or between K blocks) that makes the 64-round
    composition collapse to something invertible.

  What we haven't tried yet:
    • Relationships in GF(2³²) or GF(2)[x]/p(x) (finite fields)
    • K as evaluations of a rational function
    • K blocks as elements of a matrix group
    • The Σ rotation constants (2,13,22 / 6,11,25) as part of the secret
""")

if __name__ == "__main__":
    main()
