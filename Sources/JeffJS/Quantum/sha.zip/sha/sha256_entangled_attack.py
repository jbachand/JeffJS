#!/usr/bin/env python3
"""
SHA-256 Entangled Schedule+Backward Attack

The key insight: don't search h-values separately from W values.
Entangle the message (W[0]..W[15]) with the backward computation
through the schedule. The schedule is LINEAR — it creates a
low-dimensional manifold in the quantum state space.

The composed function:
  W[0..15] → schedule → W[48..63] → backward rounds → state → matches hash?

This composed function maps message to backward-state. If it has
periodic or low-degree structure, QFT can extract the solution
like Shor's extracts the period of modular exponentiation.

Tests:
1. Compute the composed function for all inputs (mini-SHA, tractable)
2. Check for periodicity, collisions, algebraic degree
3. Run quantum period finding on the composed function
4. Compare: flat Grover's vs structured quantum search
"""

import numpy as np
import random

BITS = 4
MASK = (1 << BITS) - 1
N = 1 << BITS  # 16 per word

def rotr(x, n):
    n = n % BITS
    return ((x >> n) | (x << (BITS - n))) & MASK

def Ch(e, f, g):  return ((e & f) ^ ((e ^ MASK) & g)) & MASK
def Maj(a, b, c): return ((a & b) ^ (a & c) ^ (b & c)) & MASK
def Sigma0(a):    return (rotr(a, 1) ^ rotr(a, 2) ^ rotr(a, 3)) & MASK
def Sigma1(e):    return (rotr(e, 1) ^ rotr(e, 2) ^ rotr(e, 3)) & MASK
def sigma0(x):    return (rotr(x, 1) ^ rotr(x, 2) ^ (x >> 1)) & MASK
def sigma1(x):    return (rotr(x, 2) ^ rotr(x, 3) ^ (x >> 1)) & MASK

REAL_K = [k & MASK for k in [
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5,
    0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3,
    0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
]]
MINI_IV = [v & MASK for v in [
    0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
    0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19,
]]

def mini_sha_compress(msg_words, n_rounds=16):
    """Full mini-SHA compression. Returns hash."""
    W = list(msg_words[:16])
    while len(W) < 16: W.append(0)
    for t in range(16, max(n_rounds, 16)):
        W.append((sigma1(W[t-2]) + W[t-7] + sigma0(W[t-15]) + W[t-16]) & MASK)
    a, b, c, d, e, f, g, h = MINI_IV
    for t in range(n_rounds):
        S1 = Sigma1(e); ch = Ch(e, f, g)
        T1 = (h + S1 + ch + REAL_K[t % len(REAL_K)] + W[t]) & MASK
        S0 = Sigma0(a); maj = Maj(a, b, c)
        T2 = (S0 + maj) & MASK
        h = g; g = f; f = e; e = (d + T1) & MASK
        d = c; c = b; b = a; a = (T1 + T2) & MASK
    return [(MINI_IV[i] + v) & MASK for i, v in enumerate([a,b,c,d,e,f,g,h])]


class QSim:
    """Quantum simulator for period finding."""
    def __init__(self, n):
        self.n = n
        self.dim = 1 << n
        self.state = np.zeros(self.dim, dtype=np.complex128)
        self.state[0] = 1.0

    def hadamard(self, q):
        s = 1 << q; inv = 1/np.sqrt(2)
        new = self.state.copy()
        for i in range(self.dim):
            j = i ^ s
            if i < j:
                a, b = self.state[i], self.state[j]
                new[i] = (a + b) * inv
                new[j] = (a - b) * inv
        self.state = new

    def controlled_phase(self, ctrl, tgt, angle):
        sc, st = 1 << ctrl, 1 << tgt
        p = np.exp(1j * angle)
        for i in range(self.dim):
            if (i & sc) and (i & st):
                self.state[i] *= p

    def swap(self, q1, q2):
        s1, s2 = 1 << q1, 1 << q2
        new = self.state.copy()
        for i in range(self.dim):
            if ((i >> q1) & 1) != ((i >> q2) & 1):
                new[i ^ s1 ^ s2] = self.state[i]
        self.state = new

    def qft(self, qubits):
        nq = len(qubits)
        for i in range(nq):
            self.hadamard(qubits[i])
            for j in range(i+1, nq):
                self.controlled_phase(qubits[j], qubits[i], np.pi / (1 << (j-i)))
        for i in range(nq // 2):
            self.swap(qubits[i], qubits[nq-1-i])

    def apply_function(self, in_q, out_q, func):
        new = np.zeros_like(self.state)
        for i in range(self.dim):
            if abs(self.state[i]) < 1e-15: continue
            x = sum(((i >> q) & 1) << bi for bi, q in enumerate(in_q))
            y = sum(((i >> q) & 1) << bi for bi, q in enumerate(out_q))
            fy = func(x) ^ y
            j = i
            for bi, q in enumerate(out_q):
                if fy & (1 << bi): j |= (1 << q)
                else: j &= ~(1 << q)
            new[j] += self.state[i]
        self.state = new

    def measure_register(self, qubits):
        nq = len(qubits)
        probs = np.zeros(1 << nq)
        for i in range(self.dim):
            val = sum(((i >> q) & 1) << bi for bi, q in enumerate(qubits))
            probs[val] += abs(self.state[i])**2
        measured = np.random.choice(len(probs), p=probs/probs.sum())
        for i in range(self.dim):
            val = sum(((i >> q) & 1) << bi for bi, q in enumerate(qubits))
            if val != measured: self.state[i] = 0
        norm = np.sqrt(np.sum(np.abs(self.state)**2))
        if norm > 0: self.state /= norm
        return measured

    def measure_probs(self, qubits):
        nq = len(qubits)
        probs = np.zeros(1 << nq)
        for i in range(self.dim):
            val = sum(((i >> q) & 1) << bi for bi, q in enumerate(qubits))
            probs[val] += abs(self.state[i])**2
        return probs


# ═══════════════════════════════════════════════════════════════
# The composed function: message → hash (mini-SHA)
# This is what we're looking for structure in.
# ═══════════════════════════════════════════════════════════════

def test_composed_function():
    """
    For tractability, test with REDUCED input:
    Fix W[2]...W[15] and vary only W[0] and W[1] (8 bits total).
    The composed function maps 8 bits → hash.
    """
    print("═" * 72)
    print("  TEST 1: Composed Function Structure")
    print("  F(W₀, W₁) = mini-SHA hash (with W₂..W₁₅ fixed)")
    print("  Looking for: periodicity, collisions, low degree")
    print("═" * 72)

    random.seed(42)
    # Fix W[2]..W[15]
    fixed_W = [random.getrandbits(BITS) for _ in range(16)]
    target_hash = mini_sha_compress(fixed_W)

    print(f"\n  Fixed message: {fixed_W}")
    print(f"  Target hash:   {target_hash}")

    # Vary W[0] and W[1] (8 bits = 256 combinations)
    n_input = 2 * BITS  # 8 bits
    n_combinations = 1 << n_input  # 256

    # Build truth table: input (W0,W1) → first word of hash
    hash_values = []
    full_hashes = []

    for x in range(n_combinations):
        w0 = x & MASK
        w1 = (x >> BITS) & MASK
        msg = [w0, w1] + fixed_W[2:]
        h = mini_sha_compress(msg)
        hash_values.append(h[0])  # first hash word
        full_hashes.append(tuple(h))

    # Collision analysis
    unique_outputs = len(set(hash_values))
    unique_full = len(set(full_hashes))

    # Find which inputs produce the TARGET hash
    preimages = [x for x in range(n_combinations) if full_hashes[x] == tuple(target_hash)]

    print(f"\n  Input space: {n_combinations} (W₀×W₁ = {N}×{N})")
    print(f"  Unique first-word outputs: {unique_outputs}/{n_combinations}")
    print(f"  Unique full hash outputs:  {unique_full}/{n_combinations}")
    print(f"  Preimages of target hash:  {len(preimages)}")
    if preimages:
        for p in preimages[:5]:
            w0, w1 = p & MASK, (p >> BITS) & MASK
            print(f"    W₀={w0}, W₁={w1} → hash={list(full_hashes[p])}")

    # Periodicity check on first hash word
    print(f"\n  Periodicity check (first hash word):")
    for p in range(1, min(32, n_combinations)):
        periodic = all(hash_values[x] == hash_values[(x + p) % n_combinations]
                      for x in range(n_combinations))
        if periodic:
            print(f"    ★ EXACT PERIOD: {p}")
            break
    else:
        print(f"    No exact period in first hash word")

    # FFT on first hash word
    signal = np.array(hash_values, dtype=np.float64)
    signal -= signal.mean()
    spectrum = np.abs(np.fft.fft(signal))
    spectrum[0] = 0
    top_freqs = sorted(range(len(spectrum)//2), key=lambda i: -spectrum[i])[:5]
    print(f"\n  Top FFT frequencies: {[(f, f'{spectrum[f]:.1f}') for f in top_freqs]}")

    # Collision structure
    from collections import Counter
    collision_counts = Counter(hash_values)
    max_collision = max(collision_counts.values())
    collision_sizes = Counter(collision_counts.values())
    print(f"\n  Collision structure (first hash word):")
    print(f"    Max collisions: {max_collision} inputs → same output")
    print(f"    Distribution: {dict(collision_sizes)}")
    print(f"    (key = collision size, value = how many outputs have that many preimages)")

    return hash_values, full_hashes, target_hash, fixed_W, preimages


def test_quantum_on_composed():
    """
    Run Shor-like quantum circuit on the composed function.
    Input: W₀ (4 bits). Output: first hash word (4 bits).
    With W₁..W₁₅ fixed, this is a 4-bit → 4-bit function.
    """
    print(f"\n{'═' * 72}")
    print("  TEST 2: Quantum Period Finding on Composed Function")
    print("  F(W₀) = first word of mini-SHA(W₀, W₁_fixed, ..., W₁₅_fixed)")
    print("  Shor's circuit: |W₀⟩|0⟩ → |W₀⟩|F(W₀)⟩ → QFT|W₀⟩ → measure")
    print("═" * 72)

    random.seed(42)
    np.random.seed(42)
    fixed_W = [random.getrandbits(BITS) for _ in range(16)]
    target_hash = mini_sha_compress(fixed_W)
    target_w0 = fixed_W[0]

    def composed_f(w0):
        msg = [w0] + fixed_W[1:]
        h = mini_sha_compress(msg)
        return h[0]  # first hash word

    # Classical truth table
    values = [composed_f(w0) for w0 in range(N)]
    print(f"\n  F(W₀) truth table:")
    print(f"  W₀:   {' '.join(f'{w:2d}' for w in range(N))}")
    print(f"  F(W₀):{' '.join(f'{v:2d}' for v in values)}")

    unique = len(set(values))
    print(f"  Unique outputs: {unique}/{N}")

    # Collisions
    from collections import Counter
    collisions = Counter(values)
    multi = {v: c for v, c in collisions.items() if c > 1}
    if multi:
        print(f"  Collisions: {multi}")
        for val, count in multi.items():
            inputs = [w for w in range(N) if composed_f(w) == val]
            print(f"    F(W₀)={val}: W₀ ∈ {inputs}")
    else:
        print(f"  No collisions (injective)")

    # Quantum circuit: Shor-style
    n_total = BITS * 2
    sim = QSim(n_total)
    in_q = list(range(BITS))
    out_q = list(range(BITS, n_total))

    # Hadamard on input
    for q in in_q: sim.hadamard(q)

    # Apply F
    sim.apply_function(in_q, out_q, composed_f)

    # Measure output → collapse to one coset
    measured_out = sim.measure_register(out_q)
    coset = [w for w in range(N) if composed_f(w) == measured_out]

    print(f"\n  Quantum measurement:")
    print(f"    Measured output register: {measured_out}")
    print(f"    Coset (W₀ values producing this output): {coset}")
    print(f"    Target W₀={target_w0} in coset: {target_w0 in coset}")

    # QFT on input
    sim.qft(in_q)
    probs = sim.measure_probs(in_q)

    print(f"\n  QFT probability distribution:")
    for v in range(N):
        bar = '█' * int(probs[v] * 60)
        peak = " ← PEAK" if probs[v] > 1.5/N else ""
        print(f"    |{v:04b}⟩ ({v:2d}): {probs[v]:.4f} {bar}{peak}")


def test_two_word_quantum():
    """
    Quantum search with W₀ AND W₁ as input (8 bits).
    This tests whether the entanglement between schedule positions
    creates exploitable structure.
    """
    print(f"\n{'═' * 72}")
    print("  TEST 3: Two-Word Quantum Attack (W₀ × W₁)")
    print("  Input: 8 qubits (W₀ and W₁ entangled through schedule)")
    print("  Output: hash word (4 qubits)")
    print("  If schedule creates structure → QFT peaks")
    print("═" * 72)

    random.seed(42)
    np.random.seed(42)
    fixed_W = [random.getrandbits(BITS) for _ in range(16)]
    target_hash = mini_sha_compress(fixed_W)

    def composed_f_2word(x):
        w0 = x & MASK
        w1 = (x >> BITS) & MASK
        msg = [w0, w1] + fixed_W[2:]
        h = mini_sha_compress(msg)
        return h[0]

    n_input = BITS * 2  # 8 qubits for W0,W1
    n_output = BITS     # 4 qubits for hash word
    input_space = 1 << n_input  # 256

    # Classical analysis
    values = [composed_f_2word(x) for x in range(input_space)]
    unique = len(set(values))

    from collections import Counter
    collisions = Counter(values)
    target_val = target_hash[0]
    target_preimages = [x for x in range(input_space) if composed_f_2word(x) == target_val]

    print(f"\n  Input space: {input_space} (W₀×W₁)")
    print(f"  Unique outputs: {unique}")
    print(f"  Target hash word: {target_val}")
    print(f"  Preimages of target: {len(target_preimages)}")
    print(f"  Target W₀={fixed_W[0]}, W₁={fixed_W[1]} = input {fixed_W[0] | (fixed_W[1] << BITS)}")

    # Collision structure
    collision_sizes = Counter(collisions.values())
    print(f"  Collision distribution: {dict(collision_sizes)}")
    avg_preimages = input_space / unique
    print(f"  Average preimages per output: {avg_preimages:.1f}")

    # Quantum circuit
    n_total = n_input + n_output
    print(f"\n  Quantum circuit: {n_input} input + {n_output} output = {n_total} qubits")

    sim = QSim(n_total)
    in_q = list(range(n_input))
    out_q = list(range(n_input, n_total))

    for q in in_q: sim.hadamard(q)
    sim.apply_function(in_q, out_q, composed_f_2word)

    # Measure output → collapse to preimage set
    measured_out = sim.measure_register(out_q)
    coset = [x for x in range(input_space) if composed_f_2word(x) == measured_out]

    print(f"\n  Measured output: {measured_out}")
    print(f"  Coset size: {len(coset)} (reduced from {input_space})")
    target_x = fixed_W[0] | (fixed_W[1] << BITS)
    print(f"  Target in coset: {target_x in coset}")

    # QFT on input
    sim.qft(in_q)
    probs = sim.measure_probs(in_q)

    # Find peaks
    threshold = 2.0 / input_space
    peaks = [(v, probs[v]) for v in range(input_space) if probs[v] > threshold]
    peaks.sort(key=lambda x: -x[1])

    print(f"\n  QFT peaks (above {threshold:.4f}):")
    for v, p in peaks[:20]:
        w0 = v & MASK
        w1 = (v >> BITS) & MASK
        print(f"    |{v:3d}⟩ (W₀={w0}, W₁={w1}): {p:.4f}")

    print(f"\n  Total peaks: {len(peaks)}")
    print(f"  Uniform would give: {input_space} values at {1/input_space:.4f} each")
    print(f"  Peak concentration: {sum(p for _, p in peaks):.3f} of total probability "
          f"in {len(peaks)}/{input_space} values")


def test_full_message_structure():
    """
    For mini-SHA with 2-word messages (8 bits), enumerate ALL inputs
    and analyze the full structure of the hash function.
    """
    print(f"\n{'═' * 72}")
    print("  TEST 4: Full Structure Analysis (8-bit message space)")
    print("  Enumerate all 256 messages, find ALL preimages of target hash")
    print("═" * 72)

    random.seed(42)
    fixed_W = [random.getrandbits(BITS) for _ in range(16)]
    target_hash = tuple(mini_sha_compress(fixed_W))

    # Enumerate ALL 2-word messages
    hash_to_msgs = {}
    for w0 in range(N):
        for w1 in range(N):
            msg = [w0, w1] + fixed_W[2:]
            h = tuple(mini_sha_compress(msg))
            if h not in hash_to_msgs:
                hash_to_msgs[h] = []
            hash_to_msgs[h].append((w0, w1))

    n_unique_hashes = len(hash_to_msgs)
    preimage_sizes = [len(v) for v in hash_to_msgs.values()]
    target_preimages = hash_to_msgs.get(target_hash, [])

    print(f"\n  Total messages: {N*N}")
    print(f"  Unique hashes: {n_unique_hashes}")
    print(f"  Avg preimages per hash: {N*N/n_unique_hashes:.1f}")
    print(f"  Min preimage set: {min(preimage_sizes)}")
    print(f"  Max preimage set: {max(preimage_sizes)}")
    print(f"\n  Target hash: {list(target_hash)}")
    print(f"  Preimages: {target_preimages}")
    print(f"  Original (W₀={fixed_W[0]}, W₁={fixed_W[1]}) in preimages: "
          f"{(fixed_W[0], fixed_W[1]) in target_preimages}")

    # Check if preimage set has algebraic structure
    if len(target_preimages) > 1:
        print(f"\n  Preimage structure analysis:")
        # XOR differences between preimages
        diffs_xor = []
        diffs_add = []
        for i in range(len(target_preimages)):
            for j in range(i+1, len(target_preimages)):
                a = target_preimages[i]
                b = target_preimages[j]
                dx = (a[0] ^ b[0], a[1] ^ b[1])
                da = ((a[0] - b[0]) & MASK, (a[1] - b[1]) & MASK)
                diffs_xor.append(dx)
                diffs_add.append(da)
        print(f"    XOR differences between preimages: {diffs_xor}")
        print(f"    ADD differences between preimages: {diffs_add}")

        # Do preimages form a coset (closed under XOR)?
        is_coset = True
        for i in range(len(target_preimages)):
            for j in range(len(target_preimages)):
                xor_val = (target_preimages[i][0] ^ target_preimages[j][0],
                          target_preimages[i][1] ^ target_preimages[j][1])
                # Check if xor_val is also a valid difference
                # (i.e., preimages form an affine subspace)
                found = False
                for k in range(len(target_preimages)):
                    if ((target_preimages[0][0] ^ xor_val[0]) & MASK == target_preimages[k][0] and
                        (target_preimages[0][1] ^ xor_val[1]) & MASK == target_preimages[k][1]):
                        found = True
                        break
                if not found:
                    is_coset = False
                    break
            if not is_coset: break

        print(f"    Preimages form affine subspace: {'YES ★' if is_coset else 'NO'}")
        if is_coset:
            print(f"    ★ This means QFT will show SHARP PEAKS (like Shor's)!")
            print(f"    ★ The preimage structure is algebraic, not random!")

    # Compute collision ratio
    from collections import Counter
    size_dist = Counter(preimage_sizes)
    print(f"\n  Preimage size distribution:")
    for size in sorted(size_dist.keys()):
        count = size_dist[size]
        print(f"    {size} preimages: {count} hashes ({count*100/n_unique_hashes:.1f}%)")


def test_grover_vs_shor():
    """
    Direct comparison: Grover's flat search vs Shor-like structured search
    on the composed function.
    """
    print(f"\n{'═' * 72}")
    print("  TEST 5: Grover vs Shor — Head to Head")
    print("  Find a preimage of a target hash using both approaches")
    print("═" * 72)

    random.seed(42)
    np.random.seed(42)
    fixed_W = [random.getrandbits(BITS) for _ in range(16)]
    target_hash = mini_sha_compress(fixed_W)
    target_w0 = fixed_W[0]

    def is_preimage(w0):
        msg = [w0] + fixed_W[1:]
        return mini_sha_compress(msg) == target_hash

    # Method 1: Grover's
    print(f"\n  Method 1: Grover's (flat search, 4 qubits)")
    n_total = BITS * 2
    target_found_grover = None

    # Find the target state for Grover's oracle
    target_states = [w0 for w0 in range(N) if is_preimage(w0)]
    print(f"  Target states: {target_states}")

    if target_states:
        # Run Grover's
        n_solutions = len(target_states)
        n_iterations = max(1, int(np.pi/4 * np.sqrt(N / n_solutions)))

        sim = QSim(BITS)
        for q in range(BITS): sim.hadamard(q)

        for _ in range(n_iterations):
            # Oracle: phase flip target states
            for t in target_states:
                sim.state[t] *= -1
            # Diffusion
            for q in range(BITS): sim.hadamard(q)
            for q in range(BITS):
                sim.state[0] *= 1  # identity
            # Inversion about mean
            mean = np.mean(sim.state)
            sim.state = 2 * mean - sim.state
            for q in range(BITS): pass  # placeholder

        # Actually, let me just do Grover's properly
        sim2 = QSim(BITS)
        for q in range(BITS): sim2.hadamard(q)

        for iteration in range(n_iterations):
            # Oracle
            for t in target_states:
                sim2.state[t] *= -1
            # Diffusion: 2|ψ⟩⟨ψ| - I
            # Where |ψ⟩ = H^n|0⟩ = uniform superposition
            sim2_copy = sim2.state.copy()
            for q in range(BITS): sim2.hadamard(q)
            # Flip all except |0⟩
            for i in range(1, 1 << BITS):
                sim2.state[i] *= -1
            for q in range(BITS): sim2.hadamard(q)
            sim2.state *= -1  # overall phase

        probs = np.abs(sim2.state)**2
        measured = np.argmax(probs)
        print(f"  Grover iterations: {n_iterations}")
        print(f"  Measured: W₀={measured}, correct: {measured in target_states}")
        print(f"  P(correct): {sum(probs[t] for t in target_states):.4f}")

    # Method 2: Shor-like (structure extraction)
    print(f"\n  Method 2: Shor-like (period finding, {BITS*2} qubits)")

    def hash_first_word(w0):
        msg = [w0] + fixed_W[1:]
        return mini_sha_compress(msg)[0]

    sim3 = QSim(BITS * 2)
    in_q = list(range(BITS))
    out_q = list(range(BITS, BITS * 2))

    for q in in_q: sim3.hadamard(q)
    sim3.apply_function(in_q, out_q, hash_first_word)

    # Before measuring: look at entanglement structure
    print(f"\n  Before measurement — joint probability distribution:")
    joint_probs = np.abs(sim3.state)**2
    for out_val in range(N):
        inputs_with_prob = []
        for in_val in range(N):
            idx = in_val | (out_val << BITS)
            if joint_probs[idx] > 0.001:
                inputs_with_prob.append((in_val, joint_probs[idx]))
        if inputs_with_prob:
            in_str = ", ".join(f"W₀={iv}({p:.3f})" for iv, p in inputs_with_prob)
            is_target = out_val == target_hash[0]
            print(f"    hash[0]={out_val:2d}: {in_str}"
                  f"{'  ← TARGET' if is_target else ''}")

    # Measure output
    measured_out = sim3.measure_register(out_q)
    coset = [w for w in range(N) if hash_first_word(w) == measured_out]

    print(f"\n  Measured output: {measured_out}")
    print(f"  Collapsed to coset: {coset} (size {len(coset)})")
    print(f"  Target W₀={target_w0} in coset: {target_w0 in coset}")

    # QFT
    sim3.qft(in_q)
    probs3 = sim3.measure_probs(in_q)

    print(f"\n  QFT distribution:")
    for v in range(N):
        bar = '█' * int(probs3[v] * 60)
        peak = " ← PEAK" if probs3[v] > 1.5/N else ""
        print(f"    |{v:2d}⟩: {probs3[v]:.4f} {bar}{peak}")

    # Summary comparison
    print(f"\n  {'─' * 60}")
    print(f"  Comparison:")
    print(f"    Grover: {n_iterations} iterations on {N} candidates → P={sum(probs[t] for t in target_states):.3f}")
    print(f"    Shor:   1 circuit on {N} candidates → coset of {len(coset)} "
          f"({'contains target' if target_w0 in coset else 'MISS'})")
    print(f"    Shor reduces search by: {N/max(len(coset),1):.1f}×")


# ═══════════════════════════════════════════════════════════════

if __name__ == "__main__":
    hash_values, full_hashes, target_hash, fixed_W, preimages = test_composed_function()
    test_quantum_on_composed()
    test_two_word_quantum()
    test_full_message_structure()
    test_grover_vs_shor()

    print(f"\n{'═' * 72}")
    print(f"  WHAT THE ENTANGLEMENT GIVES US")
    print(f"{'═' * 72}")
    print(f"""
  The schedule entangles W₀...W₁₅ with W₄₈...W₆₃.
  The backward rounds entangle W values with h values.
  The state propagation entangles h values with each other.

  When we put W₀...W₁₅ in superposition and compute the
  entire chain (schedule + compression + backward check),
  the quantum state lives on the INTERSECTION of:
    • The schedule manifold (linear, low-dimensional)
    • The Ch/Maj constraints (affine, structured)
    • The hash constraint (256-bit equality check)

  The QFT reveals the STRUCTURE of this intersection.
  If it has peaks → the intersection is structured → Shor-like attack
  If it's flat → no structure → fall back to Grover's

  The K constants determine whether the intersection is structured.
  They were chosen by the NSA.
""")
