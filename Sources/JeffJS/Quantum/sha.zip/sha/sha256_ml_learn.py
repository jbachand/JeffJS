#!/usr/bin/env python3
"""
ML learns SHA-256 at small scale (8-bit words).

If a neural network can EXACTLY reproduce mini-SHA-256 outputs for ALL inputs,
it proves an alternative computation path exists — one that doesn't use the
64-round compression loop.

We train on ALL 2^(16*8) inputs... that's 2^128. Way too many.
Instead: 8-bit word size, but only 1-2 message words (8-16 input bits).
This gives 256 or 65536 total input/output pairs — fully enumerable.

The model must achieve 100% EXACT match on held-out test data.
"""

import numpy as np
import struct
import itertools

# ============================================================
# Mini SHA-256 with configurable word size
# ============================================================

def make_mini_sha256(BITS):
    """Create a mini SHA-256 with BITS-bit words."""
    MASK = (1 << BITS) - 1

    def rotr(x, n):
        n = n % BITS
        return ((x >> n) | (x << (BITS - n))) & MASK

    def shr(x, n):
        return (x >> min(n, BITS)) & MASK

    def Sigma1(x):
        if BITS >= 32:
            return rotr(x, 6) ^ rotr(x, 11) ^ rotr(x, 25)
        else:
            return rotr(x, max(1, 6*BITS//32)) ^ rotr(x, max(1, 11*BITS//32)) ^ rotr(x, max(1, 25*BITS//32))

    def Sigma0(x):
        if BITS >= 32:
            return rotr(x, 2) ^ rotr(x, 13) ^ rotr(x, 22)
        else:
            return rotr(x, max(1, 2*BITS//32)) ^ rotr(x, max(1, 13*BITS//32)) ^ rotr(x, max(1, 22*BITS//32))

    def sigma1(x):
        if BITS >= 32:
            return rotr(x, 17) ^ rotr(x, 19) ^ shr(x, 10)
        else:
            return rotr(x, max(1, 17*BITS//32)) ^ rotr(x, max(1, 19*BITS//32)) ^ shr(x, max(1, 10*BITS//32))

    def sigma0(x):
        if BITS >= 32:
            return rotr(x, 7) ^ rotr(x, 18) ^ shr(x, 3)
        else:
            return rotr(x, max(1, 7*BITS//32)) ^ rotr(x, max(1, 18*BITS//32)) ^ shr(x, max(1, 3*BITS//32))

    def Ch(e, f, g): return (e & f) ^ ((~e) & g) & MASK
    def Maj(a, b, c): return (a & b) ^ (a & c) ^ (b & c)

    # Scale K and IV to BITS
    K32 = [
        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5,
        0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
        0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3,
        0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
        0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
        0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
        0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7,
        0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
        0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13,
        0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3,
        0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
        0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5,
        0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
        0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
        0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
    ]
    IV32 = [0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
            0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19]

    K = [k >> (32 - BITS) for k in K32]
    IV_vals = [v >> (32 - BITS) for v in IV32]

    def compress(msg_words):
        """Compress 16 message words, return 8 hash words."""
        assert len(msg_words) == 16
        W = list(msg_words) + [0] * 48
        for t in range(16, 64):
            W[t] = (sigma1(W[t-2]) + W[t-7] + sigma0(W[t-15]) + W[t-16]) & MASK

        a, b, c, d, e, f, g, h = IV_vals
        for t in range(64):
            T1 = (h + Sigma1(e) + Ch(e, f, g) + K[t] + W[t]) & MASK
            T2 = (Sigma0(a) + Maj(a, b, c)) & MASK
            h = g; g = f; f = e; e = (d + T1) & MASK
            d = c; c = b; b = a; a = (T1 + T2) & MASK

        return tuple((s + iv) & MASK for s, iv in zip([a,b,c,d,e,f,g,h], IV_vals))

    return compress, BITS, MASK

# ============================================================
# Generate complete dataset
# ============================================================

def generate_dataset(bits, n_msg_words=1):
    """Generate ALL input/output pairs for mini-SHA-256.
    n_msg_words=1: 2^bits inputs (other 15 words = 0)
    n_msg_words=2: 2^(2*bits) inputs
    """
    compress, BITS, MASK = make_mini_sha256(bits)

    n_inputs = (1 << BITS) ** n_msg_words
    print(f"Generating {n_inputs} SHA-256-{bits} pairs ({n_msg_words} message word(s))...")

    X = []
    Y = []

    if n_msg_words == 1:
        for w0 in range(1 << BITS):
            msg = [w0] + [0] * 15
            h = compress(msg)
            X.append(w0)
            Y.append(h)
    elif n_msg_words == 2:
        for w0 in range(1 << BITS):
            for w1 in range(1 << BITS):
                msg = [w0, w1] + [0] * 14
                h = compress(msg)
                X.append((w0, w1))
                Y.append(h)

    return np.array(X), np.array(Y), compress

# ============================================================
# ML Models
# ============================================================

def train_lookup_table(X, Y, bits):
    """Baseline: just a lookup table. Always 100% if trained on full dataset."""
    table = {}
    for i in range(len(X)):
        key = tuple(X[i]) if X[i].ndim > 0 else (int(X[i]),)
        table[key] = tuple(Y[i])
    return table

def bits_to_binary(val, n_bits):
    """Convert integer to binary array."""
    return np.array([(val >> i) & 1 for i in range(n_bits)], dtype=np.float32)

def binary_to_int(bits_arr):
    """Convert binary array back to integer."""
    val = 0
    for i, b in enumerate(bits_arr):
        if b > 0.5:
            val |= (1 << i)
    return val

def train_neural_net(X, Y, bits, n_msg_words=1):
    """Train a neural network to learn SHA-256 mapping.
    Input: binary representation of message word(s)
    Output: binary representation of hash words
    """
    try:
        import torch
        import torch.nn as nn
        import torch.optim as optim
        HAS_TORCH = True
    except ImportError:
        HAS_TORCH = False

    if not HAS_TORCH:
        print("PyTorch not available, trying numpy-only approach...")
        return train_numpy_net(X, Y, bits, n_msg_words)

    # Convert to binary representation
    in_bits = bits * n_msg_words
    out_bits = bits * 8  # 8 hash words

    X_bin = np.zeros((len(X), in_bits), dtype=np.float32)
    Y_bin = np.zeros((len(X), out_bits), dtype=np.float32)

    for i in range(len(X)):
        if n_msg_words == 1:
            X_bin[i] = bits_to_binary(int(X[i]), in_bits)
        else:
            for w in range(n_msg_words):
                X_bin[i, w*bits:(w+1)*bits] = bits_to_binary(int(X[i][w]), bits)

        for w in range(8):
            Y_bin[i, w*bits:(w+1)*bits] = bits_to_binary(int(Y[i][w]), bits)

    # Split train/test
    n = len(X)
    perm = np.random.permutation(n)
    n_train = int(0.8 * n)
    train_idx = perm[:n_train]
    test_idx = perm[n_train:]

    X_train = torch.tensor(X_bin[train_idx])
    Y_train = torch.tensor(Y_bin[train_idx])
    X_test = torch.tensor(X_bin[test_idx])
    Y_test = torch.tensor(Y_bin[test_idx])

    print(f"  Train: {len(train_idx)}, Test: {len(test_idx)}")
    print(f"  Input bits: {in_bits}, Output bits: {out_bits}")

    # Try increasingly large networks
    results = {}

    for hidden_size in [64, 256, 1024]:
        for n_layers in [2, 4, 8]:
            layers = [nn.Linear(in_bits, hidden_size), nn.ReLU()]
            for _ in range(n_layers - 1):
                layers.extend([nn.Linear(hidden_size, hidden_size), nn.ReLU()])
            layers.append(nn.Linear(hidden_size, out_bits))
            layers.append(nn.Sigmoid())

            model = nn.Sequential(*layers)
            optimizer = optim.Adam(model.parameters(), lr=0.001)
            criterion = nn.BCELoss()

            best_acc = 0
            patience = 0

            for epoch in range(2000):
                # Training
                model.train()
                optimizer.zero_grad()
                pred = model(X_train)
                loss = criterion(pred, Y_train)
                loss.backward()
                optimizer.step()

                # Test accuracy (exact match)
                if epoch % 100 == 0 or epoch == 1999:
                    model.eval()
                    with torch.no_grad():
                        pred_test = model(X_test)
                        pred_bits = (pred_test > 0.5).float()
                        # Per-bit accuracy
                        bit_acc = (pred_bits == Y_test).float().mean().item()
                        # Exact match (all bits correct for a sample)
                        exact = (pred_bits == Y_test).all(dim=1).float().mean().item()

                    if exact > best_acc:
                        best_acc = exact
                        patience = 0
                    else:
                        patience += 1

                    if epoch % 500 == 0:
                        print(f"    h={hidden_size} L={n_layers} ep={epoch}: "
                              f"loss={loss.item():.4f} bit_acc={bit_acc:.4f} "
                              f"exact={exact:.4f} ({int(exact*len(test_idx))}/{len(test_idx)})")

            results[(hidden_size, n_layers)] = {
                'bit_acc': bit_acc,
                'exact_acc': best_acc,
                'model': model,
            }
            print(f"  → h={hidden_size} L={n_layers}: "
                  f"bit={bit_acc:.4f} exact={best_acc:.4f}")

    return results

def train_numpy_net(X, Y, bits, n_msg_words=1):
    """Simple numpy-only neural net for environments without torch."""
    in_bits = bits * n_msg_words
    out_bits = bits * 8

    X_bin = np.zeros((len(X), in_bits), dtype=np.float32)
    Y_bin = np.zeros((len(X), out_bits), dtype=np.float32)

    for i in range(len(X)):
        if n_msg_words == 1:
            X_bin[i] = bits_to_binary(int(X[i]), in_bits)
        else:
            for w in range(n_msg_words):
                X_bin[i, w*bits:(w+1)*bits] = bits_to_binary(int(X[i][w]), bits)
        for w in range(8):
            Y_bin[i, w*bits:(w+1)*bits] = bits_to_binary(int(Y[i][w]), bits)

    n = len(X)
    perm = np.random.permutation(n)
    n_train = int(0.8 * n)
    train_idx = perm[:n_train]
    test_idx = perm[n_train:]

    X_train, Y_train = X_bin[train_idx], Y_bin[train_idx]
    X_test, Y_test = X_bin[test_idx], Y_bin[test_idx]

    print(f"  Train: {n_train}, Test: {n - n_train}")
    print(f"  Input bits: {in_bits}, Output bits: {out_bits}")

    def sigmoid(x):
        return 1.0 / (1.0 + np.exp(-np.clip(x, -500, 500)))

    def sigmoid_deriv(x):
        s = sigmoid(x)
        return s * (1 - s)

    def relu(x):
        return np.maximum(0, x)

    def relu_deriv(x):
        return (x > 0).astype(np.float32)

    # 2-layer network
    hidden = 256
    np.random.seed(42)
    W1 = np.random.randn(in_bits, hidden).astype(np.float32) * 0.1
    b1 = np.zeros(hidden, dtype=np.float32)
    W2 = np.random.randn(hidden, hidden).astype(np.float32) * 0.1
    b2 = np.zeros(hidden, dtype=np.float32)
    W3 = np.random.randn(hidden, out_bits).astype(np.float32) * 0.1
    b3 = np.zeros(out_bits, dtype=np.float32)

    lr = 0.01
    batch_size = min(64, n_train)

    for epoch in range(5000):
        # Mini-batch
        idx = np.random.choice(n_train, batch_size, replace=False)
        xb = X_train[idx]
        yb = Y_train[idx]

        # Forward
        z1 = xb @ W1 + b1
        a1 = relu(z1)
        z2 = a1 @ W2 + b2
        a2 = relu(z2)
        z3 = a2 @ W3 + b3
        a3 = sigmoid(z3)

        # Loss (BCE)
        eps = 1e-7
        loss = -np.mean(yb * np.log(a3 + eps) + (1-yb) * np.log(1-a3 + eps))

        # Backward
        dz3 = a3 - yb  # sigmoid + BCE
        dW3 = a2.T @ dz3 / batch_size
        db3 = dz3.mean(axis=0)

        da2 = dz3 @ W3.T
        dz2 = da2 * relu_deriv(z2)
        dW2 = a1.T @ dz2 / batch_size
        db2 = dz2.mean(axis=0)

        da1 = dz2 @ W2.T
        dz1 = da1 * relu_deriv(z1)
        dW1 = xb.T @ dz1 / batch_size
        db1 = dz1.mean(axis=0)

        W3 -= lr * dW3; b3 -= lr * db3
        W2 -= lr * dW2; b2 -= lr * db2
        W1 -= lr * dW1; b1 -= lr * db1

        if epoch % 500 == 0:
            # Test
            z1t = X_test @ W1 + b1; a1t = relu(z1t)
            z2t = a1t @ W2 + b2; a2t = relu(z2t)
            z3t = a2t @ W3 + b3; a3t = sigmoid(z3t)
            pred = (a3t > 0.5).astype(np.float32)
            bit_acc = (pred == Y_test).mean()
            exact = (pred == Y_test).all(axis=1).mean()
            print(f"  Epoch {epoch}: loss={loss:.4f} bit_acc={bit_acc:.4f} "
                  f"exact={exact:.4f} ({int(exact*len(test_idx))}/{len(test_idx)})")

    # Final test
    z1t = X_test @ W1 + b1; a1t = relu(z1t)
    z2t = a1t @ W2 + b2; a2t = relu(z2t)
    z3t = a2t @ W3 + b3; a3t = sigmoid(z3t)
    pred = (a3t > 0.5).astype(np.float32)
    bit_acc = (pred == Y_test).mean()
    exact = (pred == Y_test).all(axis=1).mean()

    return {'bit_acc': float(bit_acc), 'exact_acc': float(exact)}

# ============================================================
# Per-bit models: train one model per output bit
# ============================================================

def train_per_bit_models(X, Y, bits, n_msg_words=1):
    """Train a separate model for each output bit.
    This is the RIGHT approach: SHA-256 output bits are Boolean functions
    of input bits. Each is a polynomial over GF(2).
    We already proved the degree saturates at ~16.
    For 8-bit words: degree ≤ 8 (can't exceed input dimension).
    So each output bit is a polynomial of degree ≤ 8 in 8 input bits.
    A polynomial of degree 8 in 8 variables has at most 2^8 = 256 monomials.
    That's a LINEAR model over GF(2) in the monomial feature space!
    """
    in_bits = bits * n_msg_words
    out_bits = bits * 8

    # Convert to binary
    X_bin = np.zeros((len(X), in_bits), dtype=np.uint8)
    Y_bin = np.zeros((len(X), out_bits), dtype=np.uint8)

    for i in range(len(X)):
        if n_msg_words == 1:
            for b in range(in_bits):
                X_bin[i, b] = (int(X[i]) >> b) & 1
        else:
            for w in range(n_msg_words):
                for b in range(bits):
                    X_bin[i, w*bits + b] = (int(X[i][w]) >> b) & 1
        for w in range(8):
            for b in range(bits):
                Y_bin[i, w*bits + b] = (int(Y[i][w]) >> b) & 1

    # Generate ALL monomials up to degree min(in_bits, 8)
    # For 8 input bits: 2^8 = 256 monomials (including constant)
    max_degree = min(in_bits, 8)
    print(f"\n=== Per-Bit ANF Models ===")
    print(f"Input bits: {in_bits}, Max degree: {max_degree}")

    # Generate monomial features
    n_samples = len(X)
    monomials = []  # list of tuples of bit indices
    for deg in range(max_degree + 1):
        for combo in itertools.combinations(range(in_bits), deg):
            monomials.append(combo)

    n_monomials = len(monomials)
    print(f"Total monomials: {n_monomials}")

    # Build feature matrix (each monomial = product of input bits)
    F = np.ones((n_samples, n_monomials), dtype=np.uint8)
    for j, mono in enumerate(monomials):
        for bit_idx in mono:
            F[:, j] &= X_bin[:, bit_idx]

    # For each output bit, solve for coefficients over GF(2)
    # F @ c = y (mod 2)
    # This is a GF(2) linear system. Since we have 2^8 = 256 samples
    # and 256 monomials, it's a square system!

    # Split train/test
    n = len(X)
    perm = np.random.permutation(n)
    n_train = int(0.8 * n)
    train_idx = perm[:n_train]
    test_idx = perm[n_train:]

    F_train, F_test = F[train_idx], F[test_idx]
    Y_train, Y_test = Y_bin[train_idx], Y_bin[test_idx]

    correct_bits = 0
    total_bits = 0
    exact_correct = np.ones(len(test_idx), dtype=bool)

    for out_bit in range(out_bits):
        y_train = Y_train[:, out_bit]
        y_test = Y_test[:, out_bit]

        # Solve over GF(2) using Gaussian elimination
        c = gf2_solve(F_train, y_train)
        if c is not None:
            pred = (F_test @ c) % 2
            acc = (pred == y_test).mean()
            correct_bits += (pred == y_test).sum()
            exact_correct &= (pred == y_test)
        else:
            acc = 0
            correct_bits += 0
            exact_correct[:] = False

        total_bits += len(y_test)

    bit_acc = correct_bits / total_bits
    exact_acc = exact_correct.mean()

    print(f"\nGF(2) polynomial fit:")
    print(f"  Per-bit accuracy: {bit_acc:.6f}")
    print(f"  Exact match: {exact_acc:.6f} ({int(exact_acc * len(test_idx))}/{len(test_idx)})")

    if exact_acc == 1.0:
        print(f"\n  *** 100% EXACT MATCH ***")
        print(f"  SHA-256-{bits} is PERFECTLY represented as")
        print(f"  {n_monomials} GF(2) polynomials of degree ≤ {max_degree}")
        print(f"  This IS the alternative computation path!")

    return {'bit_acc': bit_acc, 'exact_acc': exact_acc, 'n_monomials': n_monomials}

def gf2_solve(A, b):
    """Solve Ax = b over GF(2) using Gaussian elimination.
    Returns x or None if no solution."""
    m, n = A.shape
    # Augmented matrix
    M = np.hstack([A.copy(), b.reshape(-1, 1)]).astype(np.uint8)

    pivot_row = 0
    pivot_cols = []
    for col in range(n):
        # Find pivot
        found = False
        for row in range(pivot_row, m):
            if M[row, col] == 1:
                # Swap
                M[[pivot_row, row]] = M[[row, pivot_row]]
                found = True
                break
        if not found:
            continue

        pivot_cols.append(col)
        # Eliminate
        for row in range(m):
            if row != pivot_row and M[row, col] == 1:
                M[row] = M[row] ^ M[pivot_row]

        pivot_row += 1

    # Extract solution (free variables = 0)
    x = np.zeros(n, dtype=np.uint8)
    for i, col in enumerate(pivot_cols):
        x[col] = M[i, n]

    # Verify
    residual = (A @ x) % 2
    if not np.array_equal(residual, b % 2):
        return None

    return x

# ============================================================
# Main
# ============================================================

if __name__ == "__main__":
    BITS = 8

    print("=" * 60)
    print(f"SHA-256 ML Learning Experiment — {BITS}-bit words")
    print("=" * 60)

    # Generate full dataset with 1 message word
    X, Y, compress = generate_dataset(BITS, n_msg_words=1)
    print(f"Dataset: {len(X)} samples")
    print(f"Input: {BITS} bits, Output: {BITS * 8} = {BITS*8} bits")

    # Verify a few
    print(f"\nSample hashes:")
    for i in [0, 1, 127, 255]:
        print(f"  msg=[{X[i]}] → hash={tuple(Y[i])}")

    # Method 1: GF(2) polynomial (algebraic normal form)
    # This is the THEORETICALLY CORRECT approach since we proved
    # SHA-256 is a polynomial over the Boolean ring.
    result_anf = train_per_bit_models(X, Y, BITS, n_msg_words=1)

    # Method 2: Neural network
    print(f"\n=== Neural Network Models ===")
    result_nn = train_neural_net(X, Y, BITS, n_msg_words=1)

    # Summary
    print(f"\n{'='*60}")
    print(f"RESULTS SUMMARY — SHA-256-{BITS}")
    print(f"{'='*60}")
    print(f"GF(2) Polynomial (ANF):")
    print(f"  Exact accuracy: {result_anf['exact_acc']:.6f}")
    print(f"  Monomials used: {result_anf['n_monomials']}")
    if isinstance(result_nn, dict) and 'exact_acc' in result_nn:
        print(f"Neural Network (numpy):")
        print(f"  Exact accuracy: {result_nn['exact_acc']:.6f}")
    elif isinstance(result_nn, dict):
        best = max(result_nn.values(), key=lambda x: x['exact_acc'])
        print(f"Neural Network (best):")
        print(f"  Exact accuracy: {best['exact_acc']:.6f}")

    if result_anf['exact_acc'] == 1.0:
        print(f"\n*** PROVEN: An alternative computation path exists for SHA-256-{BITS} ***")
        print(f"*** It's a set of {BITS*8} polynomials over GF(2) ***")
        print(f"*** with {result_anf['n_monomials']} monomial terms each ***")
        print(f"*** No compression loop needed. ***")
