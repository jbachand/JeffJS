#!/usr/bin/env python3
"""
SHA-256 Bailey Chain Inversion — Following the Paper Step by Step

From Milne-Lilly (1992), equation (2.8a) for C_l:

  A'(N; C_l) = Π_k [(αx_k)_{N_k} / ((βx_k)_{N_k} · (qx_k/α)_{N_k})]
               × (β/α)^{Σ N_k}
               × A(N; C_l)

Forward chain: A → A' (one round of SHA-256)
Inverse chain: A' → A (undo one round)

Parameter mapping:
  l = 1       (C₁ — rank 1 symplectic)
  q = 2       (binary computation — rotation/shift base)
  x_k         (related to K constants — one per round)
  α, β        (transform parameters — related to IV?)
  N           (round index)

The inverse at each step:
  A(N) = A'(N) × [(βx_k)_{N_k} · (qx_k/α)_{N_k}] / [(αx_k)_{N_k}]
         × (α/β)^{Σ N_k}

We evaluate this step by step, testing different parameter identifications.
"""

import math
import random

M32 = 0xFFFFFFFF
MOD = 2**32

primes_64 = [2,3,5,7,11,13,17,19,23,29,31,37,41,43,47,53,59,61,67,71,73,79,83,89,
             97,101,103,107,109,113,127,131,137,139,149,151,157,163,167,173,179,181,
             191,193,197,199,211,223,227,229,233,239,241,251,257,263,269,271,277,281,
             283,293,307,311]

K = [int((p ** (1/3) % 1) * 2**32) & M32 for p in primes_64]
IV = [int((p ** 0.5 % 1) * 2**32) & M32 for p in primes_64[:8]]

def rotr32(x, n): return ((x >> n) | (x << (32 - n))) & M32
def Sig1(e): return rotr32(e,6)^rotr32(e,11)^rotr32(e,25)
def Sig0(a): return rotr32(a,2)^rotr32(a,13)^rotr32(a,22)
def Ch(e,f,g): return ((e&f)^((e^M32)&g))&M32
def Maj(a,b,c): return ((a&b)^(a&c)^(b&c))&M32

def sha256_compress(W16):
    W=list(W16)
    for t in range(16,64):
        s0=rotr32(W[t-15],7)^rotr32(W[t-15],18)^(W[t-15]>>3)
        s1=rotr32(W[t-2],17)^rotr32(W[t-2],19)^(W[t-2]>>10)
        W.append((W[t-16]+s0+W[t-7]+s1)&M32)
    a,b,c,d,e,f,g,h=IV
    states=[(a,b,c,d,e,f,g,h)]
    for t in range(64):
        T1=(h+Sig1(e)+Ch(e,f,g)+K[t]+W[t])&M32
        T2=(Sig0(a)+Maj(a,b,c))&M32
        h=g;g=f;f=e;e=(d+T1)&M32;d=c;c=b;b=a;a=(T1+T2)&M32
        states.append((a,b,c,d,e,f,g,h))
    return [(IV[i]+v)&M32 for i,v in enumerate(states[-1])], states, W


def q_poch(a, q, n, mod=MOD):
    """
    q-Pochhammer symbol: (a; q)_n = Π_{k=0}^{n-1} (1 - a·q^k) mod m
    For q=2: (a; 2)_n = Π (1 - a·2^k)
    """
    result = 1
    a_qk = a % mod
    for k in range(n):
        factor = (1 - a_qk) % mod
        result = (result * factor) % mod
        a_qk = (a_qk * q) % mod
    return result


def q_poch_gf2(a, q_shifts):
    """
    GF(2) q-Pochhammer: Π (1 ⊕ RotR(a, shift))
    Product in Boolean ring = AND
    """
    result = M32
    for s in q_shifts:
        result &= rotr32(a, s) ^ M32
    return result


def modinv(a, m=MOD):
    """Modular inverse. Returns None if not invertible."""
    if a % 2 == 0:
        return None  # even numbers not invertible mod 2^32
    return pow(a, -1, m)


def bailey_coefficient_C1(t, alpha, beta, x_k, q_val=2, n_terms=32):
    """
    Compute the Bailey chain coefficient from equation (2.8a) for C₁.

    Coefficient = Π [(αx_k)_{N} / ((βx_k)_{N} · (qx_k/α)_{N})]
                  × (β/α)^N

    For C₁ (l=1): single product (no r,s indices).
    N = n_terms (number of bit positions = 32)
    """
    ax = (alpha * x_k) % MOD
    bx = (beta * x_k) % MOD

    # qx/α — need α inverse
    alpha_inv = modinv(alpha)
    if alpha_inv is None:
        return None

    qx_over_a = (q_val * x_k % MOD * alpha_inv) % MOD

    # q-Pochhammer products
    numerator = q_poch(ax, q_val, n_terms)
    denom1 = q_poch(bx, q_val, n_terms)
    denom2 = q_poch(qx_over_a, q_val, n_terms)

    if denom1 == 0 or denom2 == 0:
        return None

    denom1_inv = modinv(denom1)
    denom2_inv = modinv(denom2)

    if denom1_inv is None or denom2_inv is None:
        return None

    # (β/α)^N
    beta_over_alpha = (beta * alpha_inv) % MOD
    power_term = pow(beta_over_alpha, n_terms, MOD)

    coeff = (numerator * denom1_inv % MOD * denom2_inv % MOD * power_term) % MOD
    return coeff


def bailey_inverse_coefficient_C1(t, alpha, beta, x_k, q_val=2, n_terms=32):
    """
    INVERSE coefficient = 1 / forward_coefficient
    = [(βx_k)_{N} · (qx_k/α)_{N}] / [(αx_k)_{N}]
      × (α/β)^N
    """
    coeff = bailey_coefficient_C1(t, alpha, beta, x_k, q_val, n_terms)
    if coeff is None or coeff == 0:
        return None
    return modinv(coeff)


def main():
    print("=" * 72)
    print("  BAILEY CHAIN INVERSION — Step by Step")
    print("  Following equation (2.8a) from Milne-Lilly (1992)")
    print("=" * 72)

    random.seed(42)
    msg = [random.getrandbits(32) & M32 for _ in range(16)]
    hash_out, states, W = sha256_compress(msg)
    final_state = [(hash_out[i] - IV[i]) & M32 for i in range(8)]

    print(f"\n  Message: {' '.join(f'{w:08x}' for w in msg[:4])}...")
    print(f"  Hash:    {' '.join(f'{w:08x}' for w in hash_out)}")

    # ═══════════════════════════════════════════════════════════
    # PARAMETER IDENTIFICATION
    #
    # The paper's parameters → SHA-256 mapping:
    #   q = 2 (binary base)
    #   x_k = K[t] (round constant, from cube root of prime t)
    #   α = ? (need to identify)
    #   β = ? (need to identify)
    #   N = 32 (word size = number of bit positions)
    #
    # Candidates for (α, β):
    #   1. α=IV_word, β=hash_word (start and end of chain)
    #   2. α=1, β=q=2 (simplest Bailey pair)
    #   3. α=sqrt(prime), β=cbrt(prime) (the root connection)
    #   4. α=IV_e, β=IV_h (right-side state pair, the Ch inputs)
    # ═══════════════════════════════════════════════════════════

    print(f"\n{'=' * 72}")
    print(f"  TESTING PARAMETER IDENTIFICATIONS")
    print(f"{'=' * 72}")

    param_sets = [
        ("α=1, β=2", 1, 2),
        ("α=IV[0], β=IV[4]", IV[0], IV[4]),
        ("α=IV[4], β=IV[7]", IV[4], IV[7]),  # e and h from IV
        ("α=IV[5], β=IV[6]", IV[5], IV[6]),  # f and g from IV (the Ch pair)
        ("α=3, β=7", 3, 7),  # small primes
        ("α=2, β=3", 2, 3),  # first two primes
    ]

    for label, alpha, beta in param_sets:
        print(f"\n  {label}:")

        # Compute Bailey coefficient at each round
        coeffs = []
        valid = True
        for t in range(64):
            x_k = K[t]
            c = bailey_coefficient_C1(t, alpha, beta, x_k)
            if c is None:
                valid = False
                break
            coeffs.append(c)

        if not valid:
            print(f"    Failed — some coefficients not computable (even/zero denominators)")
            continue

        # Apply INVERSE chain: start from hash, walk backward
        # At each round: pair_prev = pair_current × inverse_coefficient

        # Try applying the inverse coefficients to the final state
        # and see if we approach the initial state or message

        # Method: multiply each state word by the inverse coefficient for that round
        recovered = list(final_state)

        for t in range(63, -1, -1):
            x_k = K[t]
            inv_c = bailey_inverse_coefficient_C1(t, alpha, beta, x_k)
            if inv_c is None:
                valid = False
                break
            # Apply inverse coefficient to each state word
            recovered = [(w * inv_c) % MOD for w in recovered]

        if not valid:
            print(f"    Failed during inverse chain")
            continue

        # Check: does the recovered state match anything?
        matches_iv = sum(1 for i in range(8) if recovered[i] == IV[i])
        matches_msg = sum(1 for i in range(8) if recovered[i] == msg[i])
        matches_state0 = sum(1 for i in range(8) if recovered[i] == states[0][i])

        print(f"    Inverse chain applied (64 steps)")
        print(f"    Recovered: {' '.join(f'{w:08x}' for w in recovered[:4])}...")
        print(f"    Matches IV:       {matches_iv}/8")
        print(f"    Matches msg:      {matches_msg}/8")
        print(f"    Matches state[0]: {matches_state0}/8")

        if matches_iv > 0 or matches_msg > 0:
            print(f"    ★ PARTIAL MATCH!")

    # ═══════════════════════════════════════════════════════════
    # APPROACH 2: Per-word Bailey chain
    # Instead of one coefficient per round, use per-WORD coefficients
    # Each state word has its own α, β from its IV position
    # ═══════════════════════════════════════════════════════════

    print(f"\n{'=' * 72}")
    print(f"  APPROACH 2: Per-word Bailey chain")
    print(f"  Each state word i uses α=IV[i], x=K[t]")
    print(f"{'=' * 72}")

    for beta_choice, beta_label in [(2, "β=2"), (3, "β=3"),
                                     (7, "β=7"), (MOD-1, "β=-1")]:
        recovered = list(final_state)
        valid = True

        for t in range(63, -1, -1):
            new_recovered = []
            for wi in range(8):
                alpha = IV[wi]
                if alpha % 2 == 0:
                    alpha = alpha | 1  # make odd for invertibility
                x_k = K[t]
                inv_c = bailey_inverse_coefficient_C1(t, alpha, beta_choice, x_k, n_terms=4)
                if inv_c is None:
                    valid = False
                    break
                new_recovered.append((recovered[wi] * inv_c) % MOD)

            if not valid:
                break
            recovered = new_recovered

        if not valid:
            print(f"  {beta_label}: failed")
            continue

        matches_iv = sum(1 for i in range(8) if recovered[i] == IV[i])
        matches_msg = sum(1 for i in range(min(8, len(msg))) if recovered[i] == msg[i])
        print(f"  {beta_label}: matches IV={matches_iv}/8, msg={matches_msg}/8 | "
              f"{' '.join(f'{w:08x}' for w in recovered[:4])}...")

    # ═══════════════════════════════════════════════════════════
    # APPROACH 3: GF(2) Bailey chain
    # Use XOR/AND instead of mod-2^32 arithmetic
    # The q-Pochhammer in GF(2): (a;q)_n = AND of (1 ⊕ RotR(a, k))
    # ═══════════════════════════════════════════════════════════

    print(f"\n{'=' * 72}")
    print(f"  APPROACH 3: GF(2) Bailey chain")
    print(f"  Operations: XOR, AND, rotation (pure Boolean ring)")
    print(f"{'=' * 72}")

    # In GF(2):
    #   multiplication = AND
    #   addition = XOR
    #   q-Pochhammer = AND of (NOT RotR(a, k)) for k in shifts
    #   inverse of AND... doesn't exist in general
    #   BUT: the Bailey coefficient combines XOR and AND in specific ways

    # The Bailey coefficient in GF(2):
    # coeff = qPoch_gf2(α·x, shifts) XOR qPoch_gf2(β·x, shifts) XOR ...
    # This is NOT multiplicative — it's a combination of Boolean operations

    # Different approach for GF(2):
    # The round function in GF(2) is:
    #   T1 = h ⊕ Σ₁(e) ⊕ Ch(e,f,g) ⊕ K[t] ⊕ W[t]
    #   new_a = T1 ⊕ T2
    #   new_e = d ⊕ T1
    #
    # The Bailey inverse in GF(2) would XOR-combine:
    #   the state words with specific rotated/masked versions of K[t]

    # For each round going backward:
    # The LEFT side gives T1 (known)
    # The Bailey correction: a function of K[t] and the state that
    # separates h from W in the equation h ⊕ W = rhs

    # The q-Pochhammer product (a; q)_n in GF(2) with q=rotation:
    # Π_{k} (1 ⊕ RotR(a, shift_k))
    # = AND of NOT(RotR(a, shift_k))
    # This produces a MASK: bits where ALL rotated versions of a are 0

    # This mask tells you WHERE a is "inactive" across all rotations
    # WHERE a is inactive, Ch reduces to g (linear!)
    # WHERE a is active, Ch = f (also linear, but different branch)

    # The Bailey coefficient in GF(2) IS the Ch linearization mask!

    for t in [63, 62, 61, 60]:
        x_k = K[t]

        # Compute q-Pochhammer mask using Σ₁ rotation amounts
        sig1_shifts = [6, 11, 25]
        mask_sig1 = q_poch_gf2(x_k, sig1_shifts)

        # Compute using Σ₀ rotation amounts
        sig0_shifts = [2, 13, 22]
        mask_sig0 = q_poch_gf2(x_k, sig0_shifts)

        # The complementary rotations (schedule sigmas)
        lsig0_shifts = [7, 18]  # excluding the shift
        lsig1_shifts = [17, 19]  # excluding the shift
        mask_lsig0 = q_poch_gf2(x_k, lsig0_shifts)
        mask_lsig1 = q_poch_gf2(x_k, lsig1_shifts)

        # Combine: the full Bailey mask
        full_mask = mask_sig1  # start with Σ₁ mask

        # How many bits are "foldable" (where the mask is 1)?
        foldable = bin(full_mask).count('1')
        foldable_0 = bin(mask_sig0).count('1')

        actual_e = states[t][4]
        e_zeros = 32 - bin(actual_e).count('1')

        print(f"  Round {t}: K=0x{x_k:08x} (prime {primes_64[t]})")
        print(f"    Σ₁ mask: 0x{mask_sig1:08x} ({bin(mask_sig1).count('1')}/32 foldable)")
        print(f"    Σ₀ mask: 0x{mask_sig0:08x} ({bin(mask_sig0).count('1')}/32 foldable)")
        print(f"    Actual e zeros (where Ch=g): {e_zeros}/32")
        print(f"    Mask ∩ e_zeros: {bin(mask_sig1 & (actual_e ^ M32)).count('1')}/32")
        print()

    # ═══════════════════════════════════════════════════════════
    # APPROACH 4: The coefficient AS the fold
    # The Bailey coefficient doesn't multiply the state.
    # It SELECTS which bits to fold (XOR) and which to keep.
    # The fold = XOR with a rotated/masked K value.
    # ═══════════════════════════════════════════════════════════

    print(f"{'=' * 72}")
    print(f"  APPROACH 4: Coefficient as fold selector")
    print(f"  At each round: fold = state ⊕ (K[t] masked by q-Pochhammer)")
    print(f"{'=' * 72}")

    # XOR-only SHA-256 for testing
    def sha256_xor(W16):
        W=list(W16)
        for t in range(16,64):
            s0=rotr32(W[t-15],7)^rotr32(W[t-15],18)^(W[t-15]>>3)
            s1=rotr32(W[t-2],17)^rotr32(W[t-2],19)^(W[t-2]>>10)
            W.append(W[t-16]^s0^W[t-7]^s1)
        a,b,c,d,e,f,g,h=IV
        for t in range(64):
            T1=h^Sig1(e)^Ch(e,f,g)^K[t]^W[t]
            T2=Sig0(a)^Maj(a,b,c)
            h=g;g=f;f=e;e=d^T1;d=c;c=b;b=a;a=T1^T2
        return [IV[i]^v for i,v in enumerate([a,b,c,d,e,f,g,h])]

    hash_xor = sha256_xor(msg)
    final_xor = [hash_xor[i] ^ IV[i] for i in range(8)]

    # Try: at each backward round, XOR the state with masked K
    state_attempt = list(final_xor)

    print(f"\n  Starting from XOR-hash final state:")
    print(f"  {' '.join(f'{w:08x}' for w in state_attempt)}")
    print()

    for t in range(63, 47, -1):
        x_k = K[t]
        mask = q_poch_gf2(x_k, [6, 11, 25])  # Σ₁ q-Pochhammer mask

        # The fold: XOR specific state words with masked K
        # Which word to fold? The ones that Ch operates on: e (index 4)
        fold_val = x_k & mask  # only fold where mask allows

        state_attempt[4] ^= fold_val  # fold e
        state_attempt[0] ^= fold_val  # fold a (gets T1 contribution)

        # Check against actual state
        actual = list(states[t])
        matches = sum(1 for i in range(8) if state_attempt[i] == actual[i])

        if t >= 60 or matches > 0:
            print(f"  Round {t}: fold with K[{t}]&mask → {matches}/8 state matches"
                  f"{'  ★' if matches > 0 else ''}")

    print(f"\n{'=' * 72}")
    print(f"  STATUS")
    print(f"{'=' * 72}")
    print(f"""
  The direct coefficient multiplication (mod 2^32) doesn't immediately
  recover the state or message. The GF(2) mask approach shows structure
  but doesn't solve it directly either.

  What we've established:
    • The q-Pochhammer mask identifies WHERE Ch is foldable for each K[t]
    • The mask depends on the PRIME embedded in K[t] through its rotations
    • The fold operation combines XOR with masked rotation

  What the paper says but we haven't fully translated:
    • Equation (2.8b) has a SUMMATION structure (not just multiplication)
    • The C_l case involves PRODUCTS over pairs (1≤r<s≤l)
    • For C₁ (l=1): the pair product is empty (no r<s pairs when l=1)
    • The iteration involves BOTH α' and β' simultaneously
    • The A and B sequences transform TOGETHER, not independently

  The missing piece may be: the Bailey pair is (A, B) = TWO sequences.
  In SHA-256: the state has TWO active parts (a and e).
  The pair (a_sequence, e_sequence) across rounds IS the Bailey pair.
  The inverse transforms BOTH simultaneously using their coupling.
""")


if __name__ == "__main__":
    main()
