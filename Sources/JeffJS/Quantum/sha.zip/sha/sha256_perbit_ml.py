#!/usr/bin/env python3
"""
SHA-256 per-bit ML: train one model per output bit independently.

The weights of each model ARE the formula for that bit.
64 independent formulas. No loop. Embarrassingly parallel.

Each output bit is a Boolean function: {0,1}^8 → {0,1}
The right ML model for a Boolean function is a LINEAR model
over the MONOMIAL feature space (AND-products of input bits).
The weights = ANF coefficients = the formula.
"""

import numpy as np
import itertools
import time

def make_mini_sha256(BITS):
    MASK = (1 << BITS) - 1
    def rotr(x, n):
        n = n % BITS
        return ((x >> n) | (x << (BITS - n))) & MASK
    def shr(x, n): return (x >> min(n, BITS)) & MASK
    def S1(x):
        r = [max(1, r_*BITS//32) for r_ in [6,11,25]]
        return rotr(x,r[0])^rotr(x,r[1])^rotr(x,r[2])
    def S0(x):
        r = [max(1, r_*BITS//32) for r_ in [2,13,22]]
        return rotr(x,r[0])^rotr(x,r[1])^rotr(x,r[2])
    def s1(x):
        return rotr(x,max(1,17*BITS//32))^rotr(x,max(1,19*BITS//32))^shr(x,max(1,10*BITS//32))
    def s0(x):
        return rotr(x,max(1,7*BITS//32))^rotr(x,max(1,18*BITS//32))^shr(x,max(1,3*BITS//32))
    def Ch(e,f,g): return (e&f)^((~e)&g)&MASK
    def Maj(a,b,c): return (a&b)^(a&c)^(b&c)
    K32=[0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
         0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
         0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
         0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
         0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
         0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
         0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
         0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2]
    IV32=[0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19]
    K_v=[k>>(32-BITS) for k in K32]
    IV_v=[v>>(32-BITS) for v in IV32]
    def compress(msg):
        W=list(msg)+[0]*48
        for t in range(16,64): W[t]=(s1(W[t-2])+W[t-7]+s0(W[t-15])+W[t-16])&MASK
        a,b,c,d,e,f,g,h=IV_v
        for t in range(64):
            T1=(h+S1(e)+Ch(e,f,g)+K_v[t]+W[t])&MASK
            T2=(S0(a)+Maj(a,b,c))&MASK
            h=g;g=f;f=e;e=(d+T1)&MASK;d=c;c=b;b=a;a=(T1+T2)&MASK
        return tuple((s+iv)&MASK for s,iv in zip([a,b,c,d,e,f,g,h],IV_v))
    return compress, BITS, MASK

def int_to_bits(v, n):
    return np.array([(v>>i)&1 for i in range(n)], dtype=np.uint8)

def mono_label(indices, bit_names):
    if len(indices) == 0: return "1"
    return "·".join(bit_names[i] for i in indices)

# ============================================================

def main():
    BITS = 8
    compress, _, MASK = make_mini_sha256(BITS)
    N = 1 << BITS
    in_bits = BITS
    out_bits = BITS * 8

    print(f"SHA-256-{BITS}: Per-Bit Formula Extraction")
    print(f"{'='*60}")
    print(f"{N} inputs, {in_bits} input bits → {out_bits} output bits")
    print(f"Training {out_bits} independent models (one per output bit)")

    # Generate ALL data
    X_bin = np.zeros((N, in_bits), dtype=np.uint8)
    Y_bin = np.zeros((N, out_bits), dtype=np.uint8)
    for i in range(N):
        X_bin[i] = int_to_bits(i, in_bits)
        h = compress([i]+[0]*15)
        for w in range(8):
            for b in range(BITS):
                Y_bin[i, w*BITS+b] = (h[w]>>b)&1

    # Build monomial features
    monomials = []
    for deg in range(in_bits+1):
        for combo in itertools.combinations(range(in_bits), deg):
            monomials.append(combo)
    n_mono = len(monomials)

    F = np.ones((N, n_mono), dtype=np.uint8)
    for j, mono in enumerate(monomials):
        for bi in mono: F[:,j] &= X_bin[:,bi]

    print(f"Monomial features: {n_mono} (degree 0 through {in_bits})")

    # Bit names for display
    bit_names = [f"m{i}" for i in range(in_bits)]

    # ============ TRAIN EACH BIT INDEPENDENTLY ============
    print(f"\n{'='*60}")
    print(f"TRAINING: One GF(2) linear model per output bit")
    print(f"{'='*60}")

    weights = []  # The formula for each bit
    formulas = []  # Human-readable

    for ob in range(out_bits):
        y = Y_bin[:, ob]

        # GF(2) solve: F @ w = y (mod 2)
        m, n = F.shape
        M = np.hstack([F%2, (y%2).reshape(-1,1)]).astype(np.uint8)
        pivot_row = 0
        pivot_cols = []
        for col in range(n):
            found = False
            for row in range(pivot_row, m):
                if M[row, col] == 1:
                    M[[pivot_row, row]] = M[[row, pivot_row]]
                    found = True; break
            if not found: continue
            pivot_cols.append(col)
            for row in range(m):
                if row != pivot_row and M[row, col] == 1:
                    M[row] ^= M[pivot_row]
            pivot_row += 1

        w = np.zeros(n, dtype=np.uint8)
        for i, col in enumerate(pivot_cols):
            w[col] = M[i, n]

        weights.append(w)

        # Extract nonzero terms
        terms = []
        for j in range(n_mono):
            if w[j] == 1:
                terms.append(mono_label(monomials[j], bit_names))

        formulas.append(terms)

    # ============ SHOW FORMULAS ============
    print(f"\n{'='*60}")
    print(f"EXTRACTED FORMULAS (weights = ANF coefficients)")
    print(f"{'='*60}")

    for ob in range(out_bits):
        word_idx = ob // BITS
        bit_idx = ob % BITS
        name = f"h{word_idx}[{bit_idx}]"
        terms = formulas[ob]
        n_terms = len(terms)

        if n_terms <= 10:
            formula_str = " ⊕ ".join(terms)
        else:
            formula_str = " ⊕ ".join(terms[:5]) + f" ⊕ ... ({n_terms} terms total)"

        print(f"  {name:8s} = {formula_str}")

    # ============ VERIFY: COMPUTE SHA-256 FROM WEIGHTS ALONE ============
    print(f"\n{'='*60}")
    print(f"VERIFICATION: Computing SHA-256 using ONLY the weights")
    print(f"{'='*60}")

    t0 = time.time()
    n_correct = 0
    for test_val in range(N):
        # Step 1: Input bits
        x = int_to_bits(test_val, in_bits)

        # Step 2: Compute monomials (AND products)
        mono_vals = np.ones(n_mono, dtype=np.uint8)
        for j, mono in enumerate(monomials):
            for bi in mono: mono_vals[j] &= x[bi]

        # Step 3: Each output bit = dot product with its weights (mod 2)
        # ALL 64 BITS COMPUTED INDEPENDENTLY — NO LOOP DEPENDENCY
        out = np.array([(mono_vals @ weights[ob]) % 2 for ob in range(out_bits)])

        # Step 4: Reconstruct hash words
        hash_words = []
        for w in range(8):
            val = 0
            for b in range(BITS): val |= int(out[w*BITS+b]) << b
            hash_words.append(val)

        actual = compress([test_val]+[0]*15)
        if tuple(hash_words) == actual:
            n_correct += 1

    t1 = time.time()
    print(f"Correctness: {n_correct}/{N}")
    print(f"Time: {(t1-t0)*1000:.1f}ms")

    if n_correct == N:
        print(f"\n*** ALL {N} HASHES COMPUTED CORRECTLY ***")
        print(f"*** Using ONLY weight vectors — no SHA-256 rounds ***")

    # ============ STRUCTURE ANALYSIS ============
    print(f"\n{'='*60}")
    print(f"STRUCTURE OF THE FORMULAS")
    print(f"{'='*60}")

    total_terms = sum(len(f) for f in formulas)
    degrees = {}
    for ob in range(out_bits):
        for j in range(n_mono):
            if weights[ob][j] == 1:
                d = len(monomials[j])
                degrees[d] = degrees.get(d, 0) + 1

    print(f"Total nonzero terms: {total_terms}")
    print(f"Average per output bit: {total_terms/out_bits:.1f}")
    print(f"\nDegree distribution:")
    for d in sorted(degrees):
        print(f"  Degree {d}: {degrees[d]:5d} terms ({degrees[d]/total_terms*100:.1f}%)")

    # ============ INDEPENDENCE CHECK ============
    print(f"\n{'='*60}")
    print(f"INDEPENDENCE: Each bit is a standalone formula")
    print(f"{'='*60}")

    # Show that bits within the same hash word share NO state
    print(f"Monomial overlap between output bits of the same word:")
    for w in range(8):
        bits_in_word = list(range(w*BITS, (w+1)*BITS))
        shared = set(range(n_mono))
        for ob in bits_in_word:
            active = set(j for j in range(n_mono) if weights[ob][j] == 1)
            shared &= active
        print(f"  Word {w}: {len(shared)} monomials shared across ALL {BITS} bits")

    # ============ PARALLEL EVALUATION ============
    print(f"\n{'='*60}")
    print(f"PARALLEL EVALUATION: All bits at once via matrix multiply")
    print(f"{'='*60}")

    # Stack all weight vectors into a matrix
    W_matrix = np.stack(weights, axis=1)  # shape: (n_mono, out_bits)
    print(f"Weight matrix shape: {W_matrix.shape}")
    print(f"Nonzero entries: {np.sum(W_matrix)} / {W_matrix.size} ({np.sum(W_matrix)/W_matrix.size*100:.1f}%)")

    # Compute ALL hashes via single matrix multiply
    t0 = time.time()
    all_outputs = (F @ W_matrix) % 2  # shape: (N, out_bits)
    t1 = time.time()

    # Verify
    n_correct = 0
    for i in range(N):
        hash_words = []
        for w in range(8):
            val = 0
            for b in range(BITS): val |= int(all_outputs[i, w*BITS+b]) << b
            hash_words.append(val)
        if tuple(hash_words) == compress([i]+[0]*15):
            n_correct += 1

    print(f"Matrix multiply: {n_correct}/{N} correct")
    print(f"Time for ALL {N} hashes: {(t1-t0)*1000:.2f}ms")
    print(f"Formula: hash_bits = (monomials(input) × W) mod 2")
    print(f"  That's it. One matrix multiply. No rounds.")

    if n_correct == N:
        print(f"\n*** SHA-256-{BITS} = ONE GF(2) MATRIX MULTIPLY ***")
        print(f"*** F({N}×{n_mono}) @ W({n_mono}×{out_bits}) mod 2 ***")
        print(f"*** {N} hashes computed simultaneously ***")
        print(f"*** Each output bit is independent ***")
        print(f"*** The weight matrix W IS the alternative formula ***")

    # ============ INVERTIBILITY ============
    print(f"\n{'='*60}")
    print(f"INVERTIBILITY: Can we go backward?")
    print(f"{'='*60}")

    # Given a hash, can we find the input?
    # hash_bits = (F @ W) mod 2
    # We know hash_bits (64 bits) and W (the formula).
    # We want to find x (8 bits) such that monomials(x) @ W mod 2 = hash_bits.
    #
    # Since monomials(x) is determined by x (8 bits → 256 monomials),
    # and there are only 256 possible x values, we can:
    # 1. Precompute F @ W mod 2 for all x (already done above)
    # 2. Look up which x produces the target hash
    #
    # This is just a lookup table inversion.
    # But the POINT is: the formula structure might enable
    # algebraic inversion without enumeration.

    # Test: pick a random hash and find the preimage
    target_idx = 137
    target_hash = compress([target_idx]+[0]*15)
    target_bits = np.zeros(out_bits, dtype=np.uint8)
    for w in range(8):
        for b in range(BITS):
            target_bits[w*BITS+b] = (target_hash[w]>>b)&1

    # Method 1: Lookup (brute force)
    found = []
    for i in range(N):
        if np.array_equal(all_outputs[i], target_bits):
            found.append(i)

    print(f"Target: hash of msg={target_idx} → {target_hash}")
    print(f"Preimage(s) found by lookup: {found}")
    print(f"Correct: {target_idx in found}")

    # Method 2: Algebraic (GF(2) system inversion)
    # We have: for each output bit ob,
    #   sum_j w[ob][j] * mono_j(x) = target[ob]  (mod 2)
    # where mono_j(x) is the j-th monomial evaluated at x.
    # x has 8 bits → 256 monomials, but only 8 free variables.
    # The monomials are NOT independent (mono_{01} = mono_0 * mono_1).
    # This is a system of 64 QUADRATIC equations in 8 binary variables.
    # It's the XL problem we already solved.

    print(f"\nThe per-bit formula reduces SHA-256 inversion to:")
    print(f"  64 polynomial equations in 8 binary variables")
    print(f"  (same as the XL attack we already verified)")
    print(f"  Solvable at this scale. Degree saturates at ~16 for real SHA-256.")

if __name__ == "__main__":
    main()
