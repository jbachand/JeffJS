#!/usr/bin/env python3
"""
SHA-256 Polynomial Inversion — Fixed Scaling Test

Previous test was broken: Gaussian elimination on linearized system
doesn't enforce monomial consistency (z_{a|b} = z_a · z_b).
Result: spurious solutions that don't correspond to valid inputs.

Fix: use XL (Extended Linearization) with proper equation generation,
AND verify by evaluating the polynomial on valid binary inputs.

Two measurements:
1. EFFECTIVE DEGREE: at what degree d does the polynomial system
   have a UNIQUE solution? (checked by evaluating all valid inputs)
2. XL SOLVE: can the XL algorithm find the correct solution without
   brute force? (tested by comparing XL output with ground truth)
"""

import numpy as np
import random
import time
from math import comb

def make_sha(bits):
    mask = (1 << bits) - 1
    def rotr(x, n):
        n = n % bits
        return ((x >> n) | (x << (bits - n))) & mask
    def ch(e, f, g): return ((e & f) ^ ((e ^ mask) & g)) & mask
    def maj(a, b, c): return ((a & b) ^ (a & c) ^ (b & c)) & mask
    r0 = [max(1, r * bits // 32) for r in [2, 13, 22]]
    r1 = [max(1, r * bits // 32) for r in [6, 11, 25]]
    def S0(a): return (rotr(a, r0[0]) ^ rotr(a, r0[1]) ^ rotr(a, r0[2])) & mask
    def S1(e): return (rotr(e, r1[0]) ^ rotr(e, r1[1]) ^ rotr(e, r1[2])) & mask
    sr0 = [max(1, r * bits // 32) for r in [7, 18]]
    ss0 = max(1, 3 * bits // 32)
    sr1 = [max(1, r * bits // 32) for r in [17, 19]]
    ss1 = max(1, 10 * bits // 32)
    def s0(x): return (rotr(x, sr0[0]) ^ rotr(x, sr0[1]) ^ (x >> ss0)) & mask
    def s1(x): return (rotr(x, sr1[0]) ^ rotr(x, sr1[1]) ^ (x >> ss1)) & mask
    K = [k & mask for k in [
        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5,
        0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
        0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3,
        0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174]]
    IV = [v & mask for v in [
        0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
        0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19]]
    def compress(msg, nr=16):
        W = list(msg[:16])
        while len(W) < 16: W.append(0)
        for t in range(16, max(nr, 16)):
            W.append((s1(W[t-2]) + W[t-7] + s0(W[t-15]) + W[t-16]) & mask)
        a, b, c, d, e, f, g, h = IV
        for t in range(nr):
            T1 = (h + S1(e) + ch(e,f,g) + K[t%16] + W[t]) & mask
            T2 = (S0(a) + maj(a,b,c)) & mask
            h=g; g=f; f=e; e=(d+T1)&mask; d=c; c=b; b=a; a=(T1+T2)&mask
        return [(IV[i]+v)&mask for i,v in enumerate([a,b,c,d,e,f,g,h])]
    return compress, mask


def compute_anf(tt, nv):
    n = 1 << nv
    a = list(tt)
    for i in range(nv):
        s = 1 << i
        for j in range(n):
            if j & s: a[j] ^= a[j ^ s]
    return a


def gf2_solve(A, b):
    """GF(2) Gaussian elimination. Returns solution or None."""
    m, n = A.shape
    Ab = np.hstack([A.copy(), b.reshape(-1, 1)]).astype(np.uint8)
    pivots = []
    for col in range(n):
        piv = None
        for row in range(len(pivots), m):
            if Ab[row, col]: piv = row; break
        if piv is None: continue
        tr = len(pivots)
        if piv != tr: Ab[[tr, piv]] = Ab[[piv, tr]]
        for row in range(m):
            if row != tr and Ab[row, col]: Ab[row] ^= Ab[tr]
        pivots.append((tr, col))
    for row in range(len(pivots), m):
        if Ab[row, -1]: return None
    x = np.zeros(n, dtype=np.uint8)
    for r, c in pivots: x[c] = Ab[r, -1]
    return x


def test_at_scale(bits, n_free, n_rounds, n_trials):
    """
    For a given word size and number of free words:
    1. Measure effective degree (by checking all valid inputs)
    2. Test XL-based algebraic solve
    """
    sha, mask = make_sha(bits)
    n_input = n_free * bits
    n_space = 1 << n_input
    n_output = 8 * bits

    if n_space > 2**20:
        return None, None

    print(f"\n  {bits}-bit, {n_free} free word(s), {n_input} input bits, "
          f"{n_rounds} rounds, space=2^{n_input}")

    random.seed(42)
    fixed = [random.getrandbits(bits) & mask for _ in range(16)]

    # Build truth tables for all output bits
    t0 = time.time()
    all_anf = []
    for wi in range(8):
        for bi in range(bits):
            tt = []
            for x in range(n_space):
                ws = [(x >> (w*bits)) & mask for w in range(n_free)]
                msg = ws + fixed[n_free:]
                h = sha(msg, n_rounds)
                tt.append((h[wi] >> bi) & 1)
            all_anf.append(compute_anf(tt, n_input))
    build_t = time.time() - t0

    target_hash = sha(fixed, n_rounds)
    target_bits = []
    for wi in range(8):
        for bi in range(bits):
            target_bits.append((target_hash[wi] >> bi) & 1)
    target_x = sum((fixed[w] & mask) << (w * bits) for w in range(n_free))

    # ── MEASURE 1: Effective degree ──
    # For each degree d, count how many inputs satisfy ALL degree-≤-d equations
    # matching the target hash. If exactly 1 → degree d is sufficient.

    print(f"  Build: {build_t:.2f}s")

    eff_degree = None
    for d in range(1, n_input + 1):
        monos = [m for m in range(n_space) if bin(m).count('1') <= d]
        mono_set = set(monos)

        # For each input x, check if it satisfies ALL truncated equations
        n_solutions = 0
        solution_x = None
        for x in range(n_space):
            match = True
            for j in range(n_output):
                val = 0
                for m in monos:
                    if all_anf[j][m] and (x & m) == m:
                        val ^= 1
                # Also account for higher-degree terms that we're IGNORING
                # The truncated equation: Σ_{deg(m)≤d} anf[m]·z_m = target_j - Σ_{deg(m)>d} anf[m]·z_m
                # We can't compute the high-degree remainder without knowing x...
                # BUT if the target hash was computed from a SPECIFIC x*, then
                # the FULL equation is satisfied. The truncated equation is:
                # Σ_{deg(m)≤d} anf[m]·z_m = target_j for the correct x.
                # For wrong x, the truncated sum may or may not match.
                #
                # Actually, we should check the FULL polynomial, not truncated.
                # The question is: at what degree do the equations become UNIQUE?
                pass

            # Full check: evaluate the COMPLETE polynomial
            full_val = []
            for j in range(n_output):
                v = 0
                for m in range(n_space):
                    if all_anf[j][m] and (x & m) == m:
                        v ^= 1
                full_val.append(v)

            if full_val == target_bits:
                n_solutions += 1
                solution_x = x

        # This counts preimages of the target hash — should be 1 if hash is injective
        if d == 1:
            # Report total preimages
            print(f"  Preimages of target: {n_solutions}")
            if n_solutions != 1:
                print(f"  WARNING: multiple preimages, polynomial won't uniquely invert")

        # Now the REAL test: at degree d, using ONLY degree-≤-d monomials,
        # how many inputs produce the same TRUNCATED output as the target?
        target_trunc = []
        for j in range(n_output):
            v = 0
            for m in monos:
                if all_anf[j][m] and (target_x & m) == m:
                    v ^= 1
            target_trunc.append(v)

        # Count inputs matching this truncated output
        trunc_matches = 0
        for x in range(n_space):
            match = True
            for j in range(n_output):
                v = 0
                for m in monos:
                    if all_anf[j][m] and (x & m) == m:
                        v ^= 1
                if v != target_trunc[j]:
                    match = False
                    break
            if match:
                trunc_matches += 1

        n_monos = len(monos)
        if trunc_matches == 1:
            if eff_degree is None:
                eff_degree = d
            print(f"  Degree {d}: {n_monos:>6d} monomials, {trunc_matches} match ★ UNIQUE")
            break
        else:
            print(f"  Degree {d}: {n_monos:>6d} monomials, {trunc_matches} matches "
                  f"({trunc_matches}/{n_space} ambiguous)")
            if d >= 4 and trunc_matches >= n_space // 2:
                print(f"  (stopping — high ambiguity)")
                break

    # ── MEASURE 2: XL algebraic solve ──
    if eff_degree is not None:
        print(f"\n  Effective degree: {eff_degree}")

        # Build XL system at the effective degree
        d = eff_degree
        monos = [m for m in range(n_space) if bin(m).count('1') <= d]
        n_monos = len(monos)
        mono_idx = {m: i for i, m in enumerate(monos)}

        # Original equations
        A_orig = np.zeros((n_output, n_monos), dtype=np.uint8)
        b_orig = np.array(target_trunc[:n_output], dtype=np.uint8)
        for j in range(n_output):
            for m in monos:
                if all_anf[j][m]:
                    A_orig[j, mono_idx[m]] = 1

        # XL: multiply each equation by each atomic variable
        xl_degree = d + 1
        xl_monos = [m for m in range(n_space) if bin(m).count('1') <= xl_degree]
        n_xl_monos = len(xl_monos)
        xl_idx = {m: i for i, m in enumerate(xl_monos)}

        xl_rows = []
        xl_rhs = []

        # Original equations (in the xl monomial basis)
        for j in range(n_output):
            row = np.zeros(n_xl_monos, dtype=np.uint8)
            for m in monos:
                if all_anf[j][m]:
                    row[xl_idx[m]] = 1
            xl_rows.append(row)
            xl_rhs.append(target_trunc[j])

        # Multiplied equations: eq_j * x_i
        for j in range(n_output):
            for var in range(n_input):
                var_mask = 1 << var
                row = np.zeros(n_xl_monos, dtype=np.uint8)
                for m in monos:
                    if all_anf[j][m]:
                        new_m = m | var_mask
                        if new_m in xl_idx:
                            row[xl_idx[new_m]] ^= 1
                # RHS: target_j * x_var = target_j * z_{var_mask}
                rhs_row = np.zeros(n_xl_monos, dtype=np.uint8)
                if target_trunc[j] == 1 and var_mask in xl_idx:
                    # Equation becomes: LHS = z_{var_mask}
                    # Move to LHS: LHS - z_{var_mask} = 0
                    row[xl_idx[var_mask]] ^= 1
                xl_rows.append(row)
                xl_rhs.append(0)

        A_xl = np.array(xl_rows, dtype=np.uint8)
        b_xl = np.array(xl_rhs, dtype=np.uint8)

        print(f"  XL system: {A_xl.shape[0]} equations, {n_xl_monos} monomials (degree ≤ {xl_degree})")

        rank = np.linalg.matrix_rank(A_xl.astype(float))
        print(f"  Rank: {rank}")

        # Solve
        t1 = time.time()
        sol = gf2_solve(A_xl, b_xl)
        solve_t = time.time() - t1

        if sol is not None:
            # Extract atomic variables
            recovered = 0
            for var in range(n_input):
                vm = 1 << var
                if vm in xl_idx and sol[xl_idx[vm]]:
                    recovered |= vm

            ws = [(recovered >> (w*bits)) & mask for w in range(n_free)]
            msg = ws + fixed[n_free:]
            h = sha(msg, n_rounds)
            correct = (h == target_hash)

            print(f"  XL solution: x={recovered} → hash={'✓' if correct else '✗'} ({solve_t:.4f}s)")

            if correct:
                # Run trials
                successes = 0
                for trial in range(n_trials):
                    tmsg = [random.getrandbits(bits) & mask for _ in range(16)]
                    th = sha(tmsg, n_rounds)
                    tb = []
                    for wi in range(8):
                        for bi in range(bits):
                            tb.append((th[wi] >> bi) & 1)

                    # Rebuild ANF for this message
                    t_anf = []
                    for wi in range(8):
                        for bi in range(bits):
                            tt = []
                            for x in range(n_space):
                                ws2 = [(x >> (w*bits)) & mask for w in range(n_free)]
                                m2 = ws2 + tmsg[n_free:]
                                hh = sha(m2, n_rounds)
                                tt.append((hh[wi] >> bi) & 1)
                            t_anf.append(compute_anf(tt, n_input))

                    # Build target truncated
                    tx = sum((tmsg[w] & mask) << (w * bits) for w in range(n_free))
                    t_trunc = []
                    for j2 in range(n_output):
                        v = 0
                        for m in monos:
                            if t_anf[j2][m] and (tx & m) == m:
                                v ^= 1
                        t_trunc.append(v)

                    # Build XL for this trial
                    xl_r2 = []
                    xl_b2 = []
                    for j2 in range(n_output):
                        row = np.zeros(n_xl_monos, dtype=np.uint8)
                        for m in monos:
                            if t_anf[j2][m]:
                                row[xl_idx[m]] = 1
                        xl_r2.append(row)
                        xl_b2.append(t_trunc[j2])
                    for j2 in range(n_output):
                        for var in range(n_input):
                            var_mask = 1 << var
                            row = np.zeros(n_xl_monos, dtype=np.uint8)
                            for m in monos:
                                if t_anf[j2][m]:
                                    new_m = m | var_mask
                                    if new_m in xl_idx:
                                        row[xl_idx[new_m]] ^= 1
                            if t_trunc[j2] == 1 and var_mask in xl_idx:
                                row[xl_idx[var_mask]] ^= 1
                            xl_r2.append(row)
                            xl_b2.append(0)

                    s2 = gf2_solve(np.array(xl_r2, dtype=np.uint8),
                                   np.array(xl_b2, dtype=np.uint8))
                    if s2 is not None:
                        rec = 0
                        for var in range(n_input):
                            vm = 1 << var
                            if vm in xl_idx and s2[xl_idx[vm]]:
                                rec |= vm
                        ws3 = [(rec >> (w*bits)) & mask for w in range(n_free)]
                        m3 = ws3 + tmsg[n_free:]
                        if sha(m3, n_rounds) == th:
                            successes += 1

                print(f"  Verification: {successes}/{n_trials} correct")
                return eff_degree, successes, n_trials
            else:
                print(f"  XL found wrong solution — need higher XL degree")
        else:
            print(f"  XL: no solution found")

    return eff_degree, 0, n_trials


def main():
    print("═" * 72)
    print("  SHA-256 Polynomial Inversion — FIXED Scaling Test")
    print("  Proper effective degree measurement + XL solver")
    print("═" * 72)

    results = []

    # Series A: 1 free word, increasing word size
    print(f"\n{'═' * 72}")
    print(f"  1 free word, 16 rounds — scaling word size")
    print(f"{'═' * 72}")

    for bits in [4, 5, 6, 7, 8, 9, 10]:
        n_input = bits
        if (1 << n_input) > 2**20:
            print(f"\n  {bits}-bit: 2^{n_input} too large")
            continue
        d, s, t = test_at_scale(bits, 1, 16, 5)
        results.append((bits, 1, d, s, t))

    # Series B: 2 free words, small word sizes
    print(f"\n{'═' * 72}")
    print(f"  2 free words, 16 rounds — scaling word size")
    print(f"{'═' * 72}")

    for bits in [4, 5, 6]:
        n_input = 2 * bits
        if (1 << n_input) > 2**20:
            print(f"\n  {bits}-bit × 2: 2^{n_input} too large")
            continue
        d, s, t = test_at_scale(bits, 2, 16, 5)
        results.append((bits, 2, d, s, t))

    # Summary
    print(f"\n{'═' * 72}")
    print(f"  RESULTS")
    print(f"{'═' * 72}")
    print(f"\n  {'Bits':>4s} │ {'Free':>4s} │ {'Input':>5s} │ {'Eff.Deg':>7s} │ {'XL Solve':>10s} │ Monomials at eff.deg")
    print(f"  {'─'*4}─┼─{'─'*4}─┼─{'─'*5}─┼─{'─'*7}─┼─{'─'*10}─┼─{'─'*25}")

    for bits, free, d, s, t in results:
        ni = free * bits
        if d is not None:
            nm = sum(comb(ni, k) for k in range(d+1))
            print(f"  {bits:>4d} │ {free:>4d} │ {ni:>5d} │ {d:>7d} │ {s:>4d}/{t:<5d} │ {nm}")
        else:
            print(f"  {bits:>4d} │ {free:>4d} │ {ni:>5d} │ {'—':>7s} │ {'—':>10s} │")

    # Extrapolation
    solved = [(b, f, d) for b, f, d, s, t in results if d is not None]
    if solved:
        print(f"\n  Degree trend (1 free word):")
        one_word = [(b, d) for b, f, d in solved if f == 1]
        for b, d in one_word:
            print(f"    {b}-bit → degree {d}")

        if len(one_word) >= 3:
            degs = [d for _, d in one_word]
            bits_list = [b for b, _ in one_word]
            # Simple extrapolation
            if degs[-1] == degs[-2]:
                ext_d = degs[-1]
            else:
                # Linear extrapolation of degree vs bits
                slope = (degs[-1] - degs[0]) / (bits_list[-1] - bits_list[0])
                ext_d = int(degs[-1] + slope * (32 - bits_list[-1]))

            print(f"\n  Extrapolation to 32-bit (1 free word):")
            print(f"    Estimated degree: ~{ext_d}")
            nm32 = sum(comb(32, k) for k in range(ext_d + 1))
            print(f"    Monomials: C(32, ≤{ext_d}) = {nm32:,}")
            print(f"    XL equations: {8*32} × {32} = {8*32*32}")
            print(f"    XL monomials: C(32, ≤{ext_d+1}) = {sum(comb(32, k) for k in range(ext_d+2)):,}")
            feasible = nm32 < 10**8
            print(f"    Gaussian elimination: O({nm32}^2) ≈ {nm32**2:.1e}")
            print(f"    {'FEASIBLE ★' if feasible else 'Large — needs optimized solver'}")


if __name__ == "__main__":
    main()
