#!/usr/bin/env python3
"""
SHA-256 ML v2 — Fixed approach.

Key insight: SHA-256 IS a polynomial over GF(2). We proved this.
So the "ML" that works is: extract the ANF (algebraic normal form).

For 8-bit words, 1 message word:
- 8 input bits, 64 output bits
- Each output bit is a Boolean function of 8 input bits
- Max 2^8 = 256 possible monomials
- Exactly 256 possible inputs
- The system is SQUARE: 256 equations, 256 unknowns → unique solution

The experiment:
1. Fit the polynomial on ALL data (proves existence)
2. Fit on 80% and test on 20% at various degrees (proves learnability)
3. Try neural network with proper training
"""

import numpy as np
import itertools
import sys

M32 = 0xFFFFFFFF

def make_mini_sha256(BITS):
    MASK = (1 << BITS) - 1
    def rotr(x, n):
        n = n % BITS
        return ((x >> n) | (x << (BITS - n))) & MASK
    def shr(x, n):
        return (x >> min(n, BITS)) & MASK

    # Scale rotations proportionally
    def Sigma1(x):
        r = [max(1, r_*BITS//32) for r_ in [6, 11, 25]]
        return rotr(x, r[0]) ^ rotr(x, r[1]) ^ rotr(x, r[2])
    def Sigma0(x):
        r = [max(1, r_*BITS//32) for r_ in [2, 13, 22]]
        return rotr(x, r[0]) ^ rotr(x, r[1]) ^ rotr(x, r[2])
    def sigma1(x):
        r1, r2 = max(1, 17*BITS//32), max(1, 19*BITS//32)
        s = max(1, 10*BITS//32)
        return rotr(x, r1) ^ rotr(x, r2) ^ shr(x, s)
    def sigma0(x):
        r1, r2 = max(1, 7*BITS//32), max(1, 18*BITS//32)
        s = max(1, 3*BITS//32)
        return rotr(x, r1) ^ rotr(x, r2) ^ shr(x, s)

    def Ch(e, f, g): return (e & f) ^ ((~e) & g) & MASK
    def Maj(a, b, c): return (a & b) ^ (a & c) ^ (b & c)

    K32 = [
        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5,
        0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
        0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3,
        0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
        0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
        0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
        0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7,
        0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
        0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13,
        0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3,
        0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
        0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5,
        0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
        0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
        0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
    ]
    IV32 = [0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
            0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19]

    K_vals = [k >> (32 - BITS) for k in K32]
    IV_vals = [v >> (32 - BITS) for v in IV32]

    def compress(msg_words):
        W = list(msg_words) + [0] * 48
        for t in range(16, 64):
            W[t] = (sigma1(W[t-2]) + W[t-7] + sigma0(W[t-15]) + W[t-16]) & MASK
        a, b, c, d, e, f, g, h = IV_vals
        for t in range(64):
            T1 = (h + Sigma1(e) + Ch(e, f, g) + K_vals[t] + W[t]) & MASK
            T2 = (Sigma0(a) + Maj(a, b, c)) & MASK
            h=g; g=f; f=e; e=(d+T1)&MASK; d=c; c=b; b=a; a=(T1+T2)&MASK
        return tuple((s + iv) & MASK for s, iv in zip([a,b,c,d,e,f,g,h], IV_vals))

    return compress, BITS, MASK

def int_to_bits(val, n_bits):
    return np.array([(val >> i) & 1 for i in range(n_bits)], dtype=np.uint8)

def build_monomial_features(X_bin, max_degree):
    """Build feature matrix of all monomials up to max_degree."""
    n_samples, n_bits = X_bin.shape
    monomials = []
    for deg in range(max_degree + 1):
        for combo in itertools.combinations(range(n_bits), deg):
            monomials.append(combo)

    F = np.ones((n_samples, len(monomials)), dtype=np.uint8)
    for j, mono in enumerate(monomials):
        for bit_idx in mono:
            F[:, j] &= X_bin[:, bit_idx]
    return F, monomials

def gf2_solve_full(A, b):
    """Solve Ax = b over GF(2). Returns solution or None."""
    m, n = A.shape
    M = np.hstack([A % 2, (b % 2).reshape(-1, 1)]).astype(np.uint8)

    pivot_row = 0
    pivot_cols = []
    for col in range(n):
        found = False
        for row in range(pivot_row, m):
            if M[row, col] == 1:
                M[[pivot_row, row]] = M[[row, pivot_row]]
                found = True
                break
        if not found:
            continue
        pivot_cols.append(col)
        for row in range(m):
            if row != pivot_row and M[row, col] == 1:
                M[row] ^= M[pivot_row]
        pivot_row += 1

    # Check consistency
    for row in range(pivot_row, m):
        if M[row, n] == 1:
            return None  # Inconsistent

    x = np.zeros(n, dtype=np.uint8)
    for i, col in enumerate(pivot_cols):
        x[col] = M[i, n]

    return x

def experiment_full_fit(bits=8):
    """Fit GF(2) polynomial on ALL 2^bits inputs."""
    compress, BITS, MASK = make_mini_sha256(bits)
    N = 1 << BITS
    in_bits = BITS
    out_bits = BITS * 8

    print(f"\n{'='*60}")
    print(f"EXPERIMENT 1: Full fit on all {N} inputs ({BITS}-bit SHA-256)")
    print(f"{'='*60}")

    # Generate all data
    X_bin = np.zeros((N, in_bits), dtype=np.uint8)
    Y_bin = np.zeros((N, out_bits), dtype=np.uint8)

    for i in range(N):
        X_bin[i] = int_to_bits(i, in_bits)
        h = compress([i] + [0]*15)
        for w in range(8):
            for b in range(BITS):
                Y_bin[i, w*BITS + b] = (h[w] >> b) & 1

    # Build feature matrix with ALL monomials (degree up to BITS)
    F, monomials = build_monomial_features(X_bin, BITS)
    print(f"Feature matrix: {F.shape[0]} samples × {F.shape[1]} monomials")

    # Solve for each output bit
    n_solved = 0
    coefficients = []
    for out_bit in range(out_bits):
        c = gf2_solve_full(F, Y_bin[:, out_bit])
        if c is not None:
            pred = (F @ c) % 2
            if np.array_equal(pred, Y_bin[:, out_bit]):
                n_solved += 1
                n_nonzero = np.sum(c)
                coefficients.append((out_bit, c, n_nonzero))
            else:
                coefficients.append((out_bit, None, 0))
        else:
            coefficients.append((out_bit, None, 0))

    print(f"\nOutput bits with PERFECT polynomial fit: {n_solved}/{out_bits}")

    if n_solved == out_bits:
        print(f"\n*** ALL {out_bits} output bits perfectly fit by GF(2) polynomials ***")
        print(f"*** SHA-256-{BITS} has an EXACT polynomial representation ***")

        # Analyze polynomial structure
        total_terms = 0
        degree_hist = {}
        for out_bit, c, n_nz in coefficients:
            if c is not None:
                total_terms += n_nz
                for j in range(len(c)):
                    if c[j] == 1:
                        deg = len(monomials[j])
                        degree_hist[deg] = degree_hist.get(deg, 0) + 1

        print(f"\nTotal nonzero terms across all {out_bits} output polynomials: {total_terms}")
        print(f"Average terms per output bit: {total_terms/out_bits:.1f}")
        print(f"\nDegree distribution of nonzero terms:")
        for deg in sorted(degree_hist):
            print(f"  Degree {deg}: {degree_hist[deg]} terms")

    return n_solved == out_bits, coefficients, F, monomials

def experiment_generalization(bits=8):
    """Train on subset, test on held-out. Does the polynomial generalize?"""
    compress, BITS, MASK = make_mini_sha256(bits)
    N = 1 << BITS
    in_bits = BITS
    out_bits = BITS * 8

    print(f"\n{'='*60}")
    print(f"EXPERIMENT 2: Generalization test ({BITS}-bit SHA-256)")
    print(f"{'='*60}")

    # Generate all data
    X_bin = np.zeros((N, in_bits), dtype=np.uint8)
    Y_bin = np.zeros((N, out_bits), dtype=np.uint8)
    for i in range(N):
        X_bin[i] = int_to_bits(i, in_bits)
        h = compress([i] + [0]*15)
        for w in range(8):
            for b in range(BITS):
                Y_bin[i, w*BITS + b] = (h[w] >> b) & 1

    # Try different training set sizes and max degrees
    np.random.seed(42)
    perm = np.random.permutation(N)

    for max_deg in [4, 5, 6, 7, 8]:
        F, monomials = build_monomial_features(X_bin, max_deg)
        n_monomials = len(monomials)

        # Need at least n_monomials training samples for the system to be determined
        for train_frac in [0.5, 0.8, 0.9, 0.95]:
            n_train = int(train_frac * N)
            if n_train < n_monomials:
                continue  # underdetermined

            train_idx = perm[:n_train]
            test_idx = perm[n_train:]

            F_train = F[train_idx]
            F_test = F[test_idx]
            Y_train = Y_bin[train_idx]
            Y_test = Y_bin[test_idx]

            # Solve for each output bit on training data, test on held-out
            bits_correct = 0
            bits_total = 0
            exact_correct = np.ones(len(test_idx), dtype=bool)

            for out_bit in range(out_bits):
                c = gf2_solve_full(F_train, Y_train[:, out_bit])
                if c is not None:
                    pred = (F_test @ c) % 2
                    bits_correct += (pred == Y_test[:, out_bit]).sum()
                    exact_correct &= (pred == Y_test[:, out_bit])
                bits_total += len(test_idx)

            bit_acc = bits_correct / bits_total
            exact_acc = exact_correct.mean()
            n_test = len(test_idx)
            n_exact = int(exact_acc * n_test)

            status = "✓ PERFECT" if exact_acc == 1.0 else ""
            print(f"  deg≤{max_deg} ({n_monomials} mono) | "
                  f"train={n_train}/{N} | "
                  f"bit={bit_acc:.4f} exact={n_exact}/{n_test} "
                  f"{status}")

def experiment_2word(bits=4):
    """2 message words at smaller bit size."""
    compress, BITS, MASK = make_mini_sha256(bits)
    N = (1 << BITS) ** 2
    in_bits = BITS * 2
    out_bits = BITS * 8

    print(f"\n{'='*60}")
    print(f"EXPERIMENT 3: Two message words ({BITS}-bit SHA-256, {N} inputs)")
    print(f"{'='*60}")

    X_bin = np.zeros((N, in_bits), dtype=np.uint8)
    Y_bin = np.zeros((N, out_bits), dtype=np.uint8)

    idx = 0
    for w0 in range(1 << BITS):
        for w1 in range(1 << BITS):
            X_bin[idx, :BITS] = int_to_bits(w0, BITS)
            X_bin[idx, BITS:] = int_to_bits(w1, BITS)
            h = compress([w0, w1] + [0]*14)
            for w in range(8):
                for b in range(BITS):
                    Y_bin[idx, w*BITS + b] = (h[w] >> b) & 1
            idx += 1

    # Full fit
    F, monomials = build_monomial_features(X_bin, min(in_bits, 8))
    print(f"Feature matrix: {F.shape[0]} × {F.shape[1]}")

    n_solved = 0
    for out_bit in range(out_bits):
        c = gf2_solve_full(F, Y_bin[:, out_bit])
        if c is not None:
            pred = (F @ c) % 2
            if np.array_equal(pred, Y_bin[:, out_bit]):
                n_solved += 1

    print(f"Output bits with perfect fit: {n_solved}/{out_bits}")
    if n_solved == out_bits:
        print(f"*** PERFECT FIT on 2-word input ***")

    # Generalization test
    np.random.seed(42)
    perm = np.random.permutation(N)
    n_train = int(0.8 * N)
    train_idx = perm[:n_train]
    test_idx = perm[n_train:]

    F_train, F_test = F[train_idx], F[test_idx]
    Y_train, Y_test = Y_bin[train_idx], Y_bin[test_idx]

    bits_correct = 0
    exact_correct = np.ones(len(test_idx), dtype=bool)
    for out_bit in range(out_bits):
        c = gf2_solve_full(F_train, Y_train[:, out_bit])
        if c is not None:
            pred = (F_test @ c) % 2
            bits_correct += (pred == Y_test[:, out_bit]).sum()
            exact_correct &= (pred == Y_test[:, out_bit])

    bit_acc = bits_correct / (len(test_idx) * out_bits)
    exact_acc = exact_correct.mean()
    print(f"Generalization (80/20): bit={bit_acc:.4f} exact={exact_acc:.4f}")

def experiment_verify_formula(bits=8):
    """Extract the polynomial and verify it computes SHA-256 WITHOUT the loop."""
    compress, BITS, MASK = make_mini_sha256(bits)
    N = 1 << BITS

    print(f"\n{'='*60}")
    print(f"EXPERIMENT 4: Extract & verify formula ({BITS}-bit)")
    print(f"{'='*60}")

    # Generate all data
    X_bin = np.zeros((N, BITS), dtype=np.uint8)
    Y_bin = np.zeros((N, BITS * 8), dtype=np.uint8)
    for i in range(N):
        X_bin[i] = int_to_bits(i, BITS)
        h = compress([i] + [0]*15)
        for w in range(8):
            for b in range(BITS):
                Y_bin[i, w*BITS + b] = (h[w] >> b) & 1

    F, monomials = build_monomial_features(X_bin, BITS)

    # Solve for all output bits
    all_coeffs = []
    for out_bit in range(BITS * 8):
        c = gf2_solve_full(F, Y_bin[:, out_bit])
        all_coeffs.append(c)

    if any(c is None for c in all_coeffs):
        print("Some bits couldn't be fit. Aborting.")
        return

    # Now: compute SHA-256 WITHOUT the loop, using only the polynomial
    print(f"\nVerifying polynomial formula on random inputs...")
    n_correct = 0
    for test_val in range(N):
        # Compute via polynomial (NO SHA-256 loop)
        x_bits = int_to_bits(test_val, BITS)

        # Evaluate each monomial
        mono_vals = np.ones(len(monomials), dtype=np.uint8)
        for j, mono in enumerate(monomials):
            for bit_idx in mono:
                mono_vals[j] &= x_bits[bit_idx]

        # Compute each output bit
        hash_bits = np.zeros(BITS * 8, dtype=np.uint8)
        for out_bit in range(BITS * 8):
            hash_bits[out_bit] = (mono_vals @ all_coeffs[out_bit]) % 2

        # Reconstruct hash words
        hash_words = []
        for w in range(8):
            val = 0
            for b in range(BITS):
                val |= int(hash_bits[w*BITS + b]) << b
            hash_words.append(val)

        # Compare with actual SHA-256
        actual = compress([test_val] + [0]*15)
        if tuple(hash_words) == actual:
            n_correct += 1

    print(f"Polynomial formula correctness: {n_correct}/{N}")
    if n_correct == N:
        print(f"\n*** VERIFIED: The polynomial computes SHA-256-{BITS} ***")
        print(f"*** exactly, on ALL {N} inputs, WITHOUT the compression loop ***")
        print(f"*** This IS the alternative computation path. ***")

        # How much work does the polynomial evaluation take?
        total_terms = sum(np.sum(c) for c in all_coeffs)
        print(f"\nComplexity:")
        print(f"  SHA-256 loop: 64 rounds × ~10 ops = ~640 operations")
        print(f"  Polynomial: {total_terms} XOR operations + {len(monomials)} AND products")
        print(f"  Per output bit: ~{total_terms // (BITS*8)} XOR ops average")

if __name__ == "__main__":
    # Experiment 1: Full fit (proof of existence)
    success, coeffs, F, monos = experiment_full_fit(8)

    # Experiment 2: Generalization (learnability from subset)
    experiment_generalization(8)

    # Experiment 3: Two message words at 4 bits
    experiment_2word(4)

    # Experiment 4: Verify the formula actually works
    if success:
        experiment_verify_formula(8)
