#!/usr/bin/env python3
"""
SHA-256 Dual Path: Schedule vs Compression converge at each round.

At every round t:
  T1[t] = h[t] + Σ₁(e[t]) + Ch(e[t],f[t],g[t]) + K[t] + W[t]

T1[t] is KNOWN from the backward walk.
Σ₁, Ch, K are known or computable.
So: h[t] + W[t] = C[t] (known from hash)

h[t] comes from COMPRESSION (nonlinear, 63 rounds deep)
W[t] comes from SCHEDULE (linear in message words)

Two paths, one equation. For single byte: both are functions of one variable.
"""

import numpy as np
import struct
import hashlib
import time

M32 = 0xFFFFFFFF

def rotr(x, n): return ((x >> n) | (x << (32 - n))) & M32
def shr(x, n): return x >> n
def Sigma1(x): return rotr(x, 6) ^ rotr(x, 11) ^ rotr(x, 25)
def Sigma0(x): return rotr(x, 2) ^ rotr(x, 13) ^ rotr(x, 22)
def sigma1(x): return rotr(x, 17) ^ rotr(x, 19) ^ shr(x, 10)
def sigma0(x): return rotr(x, 7) ^ rotr(x, 18) ^ shr(x, 3)
def Ch(e, f, g): return (e & f) ^ ((~e) & g) & M32
def Maj(a, b, c): return (a & b) ^ (a & c) ^ (b & c)

K = [0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
     0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
     0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
     0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
     0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
     0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
     0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
     0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2]
IV = [0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,
      0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19]

def full_sha256(msg_byte):
    """Full compression, return all intermediates."""
    msg = bytes([msg_byte])
    padded = msg + b'\x80' + b'\x00' * 54 + struct.pack('>Q', 8)
    W = list(struct.unpack('>16I', padded))
    for t in range(16, 64):
        W.append((sigma1(W[t-2]) + W[t-7] + sigma0(W[t-15]) + W[t-16]) & M32)
    a,b,c,d,e,f,g,h = IV
    states = [(a,b,c,d,e,f,g,h)]
    t1v = []
    for t in range(64):
        T1 = (h + Sigma1(e) + Ch(e,f,g) + K[t] + W[t]) & M32
        T2 = (Sigma0(a) + Maj(a,b,c)) & M32
        t1v.append(T1)
        h=g;g=f;f=e;e=(d+T1)&M32;d=c;c=b;b=a;a=(T1+T2)&M32
        states.append((a,b,c,d,e,f,g,h))
    hash_out = [(states[64][i]+IV[i])&M32 for i in range(8)]
    return hash_out, states, t1v, W

def schedule_only(msg_byte):
    """Compute ONLY the message schedule — no compression."""
    msg = bytes([msg_byte])
    padded = msg + b'\x80' + b'\x00' * 54 + struct.pack('>Q', 8)
    W = list(struct.unpack('>16I', padded))
    for t in range(16, 64):
        W.append((sigma1(W[t-2]) + W[t-7] + sigma0(W[t-15]) + W[t-16]) & M32)
    return W

def backward_walk(hash_out):
    """Recover T1/T2 and C values from hash."""
    st = [(hash_out[i]-IV[i])&M32 for i in range(8)]
    a_f,b_f,c_f,d_f,e_f,f_f,g_f,h_f = st

    results = {}

    # Round 63
    T2 = (Sigma0(b_f) + Maj(b_f,c_f,d_f)) & M32
    T1 = (a_f - T2) & M32
    e_bef = (e_f - T1) & M32
    # C[63] = T1 - Σ₁(f_f) - Ch(f_f,g_f,h_f) - K[63]
    C63 = (T1 - Sigma1(f_f) - Ch(f_f,g_f,h_f) - K[63]) & M32
    results[63] = {'T1': T1, 'T2': T2, 'C': C63, 'sigma_var': f_f, 'ch_args': (f_f,g_f,h_f)}

    # Round 62
    T2 = (Sigma0(c_f) + Maj(c_f,d_f,e_bef)) & M32
    T1 = (b_f - T2) & M32
    f_bef = (f_f - T1) & M32
    C62 = (T1 - Sigma1(g_f) - Ch(g_f,h_f,0) - K[62]) & M32  # Ch has unknown a_old
    results[62] = {'T1': T1, 'T2': T2}

    # Round 61
    T2 = (Sigma0(d_f) + Maj(d_f,e_bef,f_bef)) & M32
    T1 = (c_f - T2) & M32
    g_bef = (g_f - T1) & M32
    results[61] = {'T1': T1, 'T2': T2}

    # Round 60
    T2 = (Sigma0(e_bef) + Maj(e_bef,f_bef,g_bef)) & M32
    T1 = (d_f - T2) & M32
    h_bef = (h_f - T1) & M32
    results[60] = {'T1': T1, 'T2': T2}

    # Round 59
    T2 = (Sigma0(f_bef) + Maj(f_bef,g_bef,h_bef)) & M32
    T1 = (e_bef - T2) & M32
    results[59] = {'T1': T1, 'T2': T2}

    return results, C63

def main():
    print("=" * 70)
    print("DUAL PATH: Schedule and Compression converge")
    print("=" * 70)

    # ============ VERIFY THE DUAL PATH ============
    print(f"\n--- Verify: h[63] + W[63] = C for all 256 inputs ---")

    n_verified = 0
    for byte_val in range(256):
        hash_out, states, t1v, W = full_sha256(byte_val)
        bw, C63 = backward_walk(hash_out)

        h63 = states[63][7]  # state h at time 63
        w63 = W[63]

        check = (h63 + w63) & M32
        if check == C63:
            n_verified += 1

    print(f"  Verified: {n_verified}/256 ✓")

    # ============ SCHEDULE-ONLY SHORTCUT ============
    print(f"\n{'='*70}")
    print("SCHEDULE-ONLY: Compute W[63], derive h[63] = C - W[63]")
    print("=" * 70)

    # Given a target hash, can we determine h[63] by computing W[63] for each candidate?
    target_byte = ord('A')
    hash_out, states, t1v, W_full = full_sha256(target_byte)
    bw, C63 = backward_walk(hash_out)

    print(f"\nTarget: SHA-256('A') = {hashlib.sha256(b'A').hexdigest()}")
    print(f"C[63] = {hex(C63)} (known from hash backward walk)")

    print(f"\nFor each byte candidate, compute schedule → W[63] → h[63]:")
    print(f"{'Byte':>4} | {'W[63] (schedule)':>18} | {'h[63] = C-W[63]':>18} | {'Actual h[63]':>18} | Match")
    print("-" * 85)

    t0 = time.time()
    found = []
    for byte_val in range(256):
        # CHEAP: only compute the schedule, NOT the full 64-round compression
        W = schedule_only(byte_val)
        w63 = W[63]
        h63_predicted = (C63 - w63) & M32

        # Get actual h[63] (expensive: full compression)
        _, actual_states, _, _ = full_sha256(byte_val)
        h63_actual = actual_states[63][7]

        match = h63_predicted == h63_actual

        if byte_val == target_byte or byte_val < 5 or byte_val == 255:
            char = chr(byte_val) if 32 <= byte_val < 127 else '.'
            print(f" {byte_val:3d} | {hex(w63):>18s} | {hex(h63_predicted):>18s} | "
                  f"{hex(h63_actual):>18s} | {'✓' if match else '✗'} {char}")

        if match and byte_val == target_byte:
            found.append(byte_val)

    t1 = time.time()

    # Now the REAL question: does this help us FIND the right byte?
    # Given C63 (from hash), for each candidate byte:
    # 1. Compute W[63] via schedule (CHEAP: ~48 ops)
    # 2. h[63] = C - W[63] (1 subtraction)
    # 3. But how do we VERIFY h[63] without full compression?

    print(f"\n{'='*70}")
    print("THE VERIFICATION PROBLEM")
    print("=" * 70)
    print(f"""
  For any candidate byte:
    W[63] = schedule(byte)          ← CHEAP (48 sigma ops)
    h[63] = C[63] - W[63]          ← FREE (1 subtraction)

  But h[63] is the state variable h at round 63.
  h[63] = g[62] = f[61] = e[60] = d[59] + T1[59]

  To CHECK if a candidate h[63] is correct, we'd need to run the
  full compression to see if we arrive at this h[63] at round 63.
  That's the full 63 rounds — no shortcut.

  UNLESS... we use it differently.
""")

    # ============ THE INSIGHT: MULTIPLE CONSTRAINTS ============
    print(f"{'='*70}")
    print("MULTIPLE CONSTRAINTS: One equation per round")
    print("=" * 70)

    # For the correct message, the addend equations at rounds 59-63
    # all hold simultaneously. Each equation links h[t] and W[t]:
    #   h[t] + W[t] + (known terms) = T1[t]
    #
    # W[t] comes from the schedule (linear in message).
    # h[t] comes from the compression (nonlinear in message).
    # T1[t] is known from the backward walk.
    #
    # For single-byte input: 5 equations, 1 unknown (the byte).
    # Massively overdetermined!

    print(f"\nFor the correct byte (0x{target_byte:02x} = 'A'):")
    print(f"  5 addend equations, each linking W[t] and h[t]:")

    for t in [63, 62, 61, 60, 59]:
        w_t = W_full[t]
        h_t = states[t][7]
        t1_known = bw[t]['T1'] if t in bw else t1v[t]

        # Full addend: T1 = h + Σ₁(e) + Ch(e,f,g) + K + W
        e_t = states[t][4]
        f_t = states[t][5]
        g_t = states[t][6]
        nonlinear = (h_t + Sigma1(e_t) + Ch(e_t,f_t,g_t)) & M32
        linear = (K[t] + w_t) & M32

        print(f"  R={t}: T1={hex(t1_known)} = h[{t}]+Σ₁Ch+K+W")
        print(f"       h[{t}]={hex(h_t)}  W[{t}]={hex(w_t)}")
        print(f"       nonlinear(compression)={hex(nonlinear)}  linear(schedule)={hex(linear)}")

    # ============ SCHEDULE COST vs COMPRESSION COST ============
    print(f"\n{'='*70}")
    print("COST COMPARISON: Schedule vs Full Compression")
    print("=" * 70)

    # Time schedule-only for all 256 candidates
    t0 = time.time()
    for byte_val in range(256):
        W = schedule_only(byte_val)
    t_sched = time.time() - t0

    # Time full compression for all 256 candidates
    t0 = time.time()
    for byte_val in range(256):
        hash_out, _, _, _ = full_sha256(byte_val)
    t_full = time.time() - t0

    # Time hashlib for comparison
    t0 = time.time()
    for byte_val in range(256):
        hashlib.sha256(bytes([byte_val])).digest()
    t_hashlib = time.time() - t0

    print(f"  Schedule only (256 candidates): {t_sched*1000:.2f}ms")
    print(f"  Full compression (256):          {t_full*1000:.2f}ms")
    print(f"  hashlib (256):                   {t_hashlib*1000:.2f}ms")
    print(f"  Schedule / Full ratio:           {t_sched/t_full:.2f}x")

    # ============ THE PICTURE ============
    print(f"\n{'='*70}")
    print("THE PICTURE")
    print("=" * 70)
    print(f"""
  Message ──→ Schedule ──→ W[63] ──┐
     │                              ├──→ W[63] + h[63] = C (KNOWN)
     └──→ Compression ──→ h[63] ──┘

  Two paths from the SAME source, meeting at a KNOWN sum.

  The schedule path is LINEAR (cheap).
  The compression path is NONLINEAR (expensive).

  For a preimage attack on a longer message:
  - W[t] = linear_function(msg_words)     ← 16 variables
  - h[t] = nonlinear_function(msg_words)  ← same 16 variables
  - 5 equations: h[t] + W[t] = C[t] for t=59..63

  The schedule gives W[59..63] as LINEAR functions of the message.
  The compression gives h[59..63] as NONLINEAR functions.
  Combined: 5 nonlinear equations in 16 unknowns.

  The schedule path is FREE — you just subtract it.
  What remains is: h[t] = C[t] - linear(msg)
  → 5 constraints on how the compression reaches specific h values.
  → The h values are determined by the MESSAGE through 59-63 rounds
     of nonlinear mixing.
  → But they MUST hit specific targets (C[t] - W[t]).
""")

if __name__ == "__main__":
    main()
