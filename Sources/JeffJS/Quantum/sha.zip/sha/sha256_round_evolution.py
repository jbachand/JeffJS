#!/usr/bin/env python3
"""
SHA-256 weight matrix evolution: round by round.

Watch the polynomial go from structured to random.
1 round → 2 → 4 → 8 → 16 → 32 → 64 rounds.
K=0, IV=0 to see the BARE algebraic structure.
"""

import numpy as np
from math import comb
import struct
import time

M32 = 0xFFFFFFFF

def rotr(x, n): return ((x >> n) | (x << (32 - n))) & M32
def shr(x, n): return x >> n
def Sigma1(x): return rotr(x, 6) ^ rotr(x, 11) ^ rotr(x, 25)
def Sigma0(x): return rotr(x, 2) ^ rotr(x, 13) ^ rotr(x, 22)
def sigma1(x): return rotr(x, 17) ^ rotr(x, 19) ^ shr(x, 10)
def sigma0(x): return rotr(x, 7) ^ rotr(x, 18) ^ shr(x, 3)
def Ch(e, f, g): return (e & f) ^ ((~e) & g) & M32
def Maj(a, b, c): return (a & b) ^ (a & c) ^ (b & c)

def sha256_n_rounds(msg_byte, n_rounds, use_K=False, use_IV=False):
    K = [0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
         0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
         0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
         0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
         0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
         0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
         0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
         0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2]
    IV = [0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,
          0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19]

    msg = bytes([msg_byte])
    padded = msg + b'\x80' + b'\x00' * 54 + struct.pack('>Q', 8)
    W = list(struct.unpack('>16I', padded))
    for t in range(16, 64):
        W.append((sigma1(W[t-2]) + W[t-7] + sigma0(W[t-15]) + W[t-16]) & M32)

    iv = IV if use_IV else [0]*8
    k = K if use_K else [0]*64
    a,b,c,d,e,f,g,h = iv

    for t in range(n_rounds):
        T1 = (h + Sigma1(e) + Ch(e,f,g) + k[t] + W[t]) & M32
        T2 = (Sigma0(a) + Maj(a,b,c)) & M32
        h=g;g=f;f=e;e=(d+T1)&M32;d=c;c=b;b=a;a=(T1+T2)&M32

    return tuple((s+i)&M32 for s,i in zip([a,b,c,d,e,f,g,h], iv))

def hash_to_bits(hw):
    bits = np.zeros(256, dtype=np.uint8)
    for w in range(8):
        for b in range(32):
            bits[w*32+b] = (hw[w]>>b)&1
    return bits

def mobius(Y, n_bits):
    a = Y.copy()
    for i in range(n_bits):
        mask = 1 << i
        for x in range(len(a)):
            if x & mask:
                a[x] ^= a[x ^ mask]
    return a

def analyze_rounds(n_rounds, n_bits=8, use_K=False, use_IV=False):
    N = 1 << n_bits

    Y = np.zeros((N, 256), dtype=np.uint8)
    for val in range(N):
        h = sha256_n_rounds(val, n_rounds, use_K, use_IV)
        Y[val] = hash_to_bits(h)

    # Check if any output bits are constant (same for all inputs)
    const_bits = 0
    zero_bits = 0
    for ob in range(256):
        if np.all(Y[:, ob] == Y[0, ob]):
            const_bits += 1
            if np.all(Y[:, ob] == 0):
                zero_bits += 1

    W = np.zeros_like(Y)
    for ob in range(256):
        W[:, ob] = mobius(Y[:, ob], n_bits)

    total = int(np.sum(W))
    density = total / W.size if W.size > 0 else 0

    # Degree distribution
    deg_counts = np.zeros(n_bits+1, dtype=np.int64)
    deg_fill = np.zeros(n_bits+1)
    for m in range(N):
        deg = bin(m).count('1')
        deg_counts[deg] += int(np.sum(W[m, :]))

    # Effective degree
    eff_deg = 0
    for d in range(n_bits, -1, -1):
        if deg_counts[d] > 0:
            eff_deg = d; break

    # Per-word density
    word_density = []
    for w in range(8):
        ws = W[:, w*32:(w+1)*32]
        wd = np.sum(ws) / ws.size if ws.size > 0 else 0
        word_density.append(wd)

    # Per-word effective degree
    word_eff_deg = []
    for w in range(8):
        ws = W[:, w*32:(w+1)*32]
        wed = 0
        for m in range(N):
            deg = bin(m).count('1')
            if np.sum(ws[m, :]) > 0:
                wed = max(wed, deg)
        word_eff_deg.append(wed)

    # Count distinct output hashes (collision check)
    unique_hashes = len(set(tuple(Y[i]) for i in range(N)))

    return {
        'n_rounds': n_rounds,
        'density': density,
        'eff_deg': eff_deg,
        'deg_counts': deg_counts,
        'word_density': word_density,
        'word_eff_deg': word_eff_deg,
        'const_bits': const_bits,
        'zero_bits': zero_bits,
        'unique_hashes': unique_hashes,
        'W': W,
    }

def print_heatmap(W, n_bits, label):
    N = 1 << n_bits
    print(f"\n  Heatmap: density by (degree × word) — {label}")
    header = "       " + "".join(f"  W{w}  " for w in range(8))
    print(header)
    print("       " + "------" * 8)

    for d in range(n_bits + 1):
        mono_indices = [m for m in range(N) if bin(m).count('1') == d]
        if not mono_indices: continue
        row = f"  d={d:2d} |"
        for w in range(8):
            block = W[np.ix_(mono_indices, list(range(w*32, (w+1)*32)))]
            fill = np.sum(block) / block.size * 100
            if fill == 0:
                row += "    0  "
            elif fill < 5:
                row += f" {fill:4.1f}% "
            elif fill < 20:
                row += f" {fill:4.0f}%░"
            elif fill < 40:
                row += f" {fill:4.0f}%▒"
            elif fill < 60:
                row += f" {fill:4.0f}%█"
            elif fill < 80:
                row += f" {fill:4.0f}%▓"
            elif fill < 95:
                row += f" {fill:4.0f}%▒"
            elif fill < 100:
                row += f" {fill:4.0f}%░"
            else:
                row += f"  100% "
        print(row)

def main():
    N_BITS = 8
    round_counts = [1, 2, 3, 4, 6, 8, 12, 16, 24, 32, 48, 64]

    # ============ BARE STRUCTURE (K=0, IV=0) ============
    print("=" * 70)
    print("ROUND-BY-ROUND EVOLUTION — K=0, IV=0 (bare algebraic structure)")
    print("=" * 70)

    bare_results = []
    for nr in round_counts:
        r = analyze_rounds(nr, N_BITS, use_K=False, use_IV=False)
        bare_results.append(r)

        # Compact output
        deg_str = ""
        for d in range(N_BITS+1):
            n_poss = comb(N_BITS, d) * 256
            fill = r['deg_counts'][d] / n_poss * 100 if n_poss > 0 else 0
            deg_str += f"{fill:4.0f}"

        wd_str = " ".join(f"{d*100:3.0f}" for d in r['word_density'])

        print(f"  R={nr:2d} | density={r['density']*100:5.1f}% | "
              f"eff_deg={r['eff_deg']} | const={r['const_bits']:3d} | "
              f"unique={r['unique_hashes']:3d}/256")

    # ============ DETAILED VIEW OF KEY TRANSITIONS ============
    print(f"\n{'='*70}")
    print("DETAILED: Degree fill % at each round (bare)")
    print("=" * 70)
    print(f"{'Rounds':>6} |", end="")
    for d in range(N_BITS+1):
        print(f" d={d:d}  ", end="")
    print(" | density")
    print("-" * 80)

    for r in bare_results:
        print(f"  R={r['n_rounds']:2d}  |", end="")
        for d in range(N_BITS+1):
            n_poss = comb(N_BITS, d) * 256
            fill = r['deg_counts'][d] / n_poss * 100 if n_poss > 0 else 0
            if fill == 0:
                print("    0 ", end="")
            elif fill < 10:
                print(f" {fill:4.1f} ", end="")
            else:
                print(f" {fill:4.0f}%", end="")
        print(f" | {r['density']*100:.1f}%")

    # ============ HEATMAPS AT KEY ROUNDS ============
    for nr in [1, 2, 3, 4, 8, 16, 64]:
        r = [x for x in bare_results if x['n_rounds'] == nr][0]
        print_heatmap(r['W'], N_BITS, f"R={nr}, bare")

    # ============ WORD-LEVEL DEGREE EVOLUTION ============
    print(f"\n{'='*70}")
    print("PER-WORD effective degree evolution (bare)")
    print("=" * 70)
    print(f"{'Rounds':>6} |", end="")
    for w in range(8):
        print(f"  W{w} ", end="")
    print()
    print("-" * 55)
    for r in bare_results:
        print(f"  R={r['n_rounds']:2d}  |", end="")
        for w in range(8):
            print(f"  {r['word_eff_deg'][w]:2d} ", end="")
        print()

    # ============ WITH K AND IV ============
    print(f"\n{'='*70}")
    print("COMPARISON: Bare vs Full (K+IV) at each round count")
    print("=" * 70)

    print(f"{'Rounds':>6} | {'Bare density':>12} | {'Full density':>12} | "
          f"{'Bare deg':>8} | {'Full deg':>8}")
    print("-" * 65)

    for nr in round_counts:
        rb = [x for x in bare_results if x['n_rounds'] == nr][0]
        rf = analyze_rounds(nr, N_BITS, use_K=True, use_IV=True)
        print(f"  R={nr:2d}  | {rb['density']*100:11.1f}% | {rf['density']*100:11.1f}% | "
              f"{rb['eff_deg']:8d} | {rf['eff_deg']:8d}")

    # ============ CRITICAL TRANSITION ZONE ============
    print(f"\n{'='*70}")
    print("CRITICAL TRANSITION: Rounds 1-8 detailed (bare, K=0, IV=0)")
    print("=" * 70)

    for nr in range(1, 9):
        r = analyze_rounds(nr, N_BITS, use_K=False, use_IV=False)
        print(f"\n  --- Round {nr} ---")
        print(f"  Density: {r['density']*100:.1f}%")
        print(f"  Effective degree: {r['eff_deg']}")
        print(f"  Constant output bits: {r['const_bits']}/256")
        print(f"  Unique hashes: {r['unique_hashes']}/256")
        print(f"  Word densities: {' '.join(f'{d*100:.0f}%' for d in r['word_density'])}")
        print(f"  Word degrees:   {' '.join(f'{d:3d}' for d in r['word_eff_deg'])}")

        # Show degree distribution
        dd = []
        for d in range(N_BITS+1):
            n_poss = comb(N_BITS, d) * 256
            fill = r['deg_counts'][d] / n_poss * 100 if n_poss > 0 else 0
            dd.append(f"d{d}={fill:.0f}%")
        print(f"  Fill: {' '.join(dd)}")

if __name__ == "__main__":
    main()
