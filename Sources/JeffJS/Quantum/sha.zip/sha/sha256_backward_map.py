#!/usr/bin/env python3
"""
SHA-256 Backward Map — Direct Inversion of 16 Rounds

The hypothesis: there exists a direct computation (not search) that
walks back the last 16 rounds of SHA-256 given the hash output.

At each backward step:
  h[t] + W[t] = C[t]  (one equation, two unknowns)

But h[t] shifts into the NEXT backward step's state, creating a chain.
If we can express h[t] in terms of later values (which we already
computed), the chain unravels and each W falls out directly.

The question: does this chain close? Or does it require guessing?
"""

import random

# SHA-256 constants
K = [
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5,
    0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3,
    0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
    0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7,
    0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13,
    0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3,
    0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5,
    0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
    0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
]

IV = [
    0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
    0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19,
]

M = 0xFFFFFFFF

def rotr(x, n):
    return ((x >> n) | (x << (32 - n))) & M

def Sigma0(a):
    return rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22)

def Sigma1(e):
    return rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25)

def sigma0(x):
    return rotr(x, 7) ^ rotr(x, 18) ^ (x >> 3)

def sigma1(x):
    return rotr(x, 17) ^ rotr(x, 19) ^ (x >> 10)

def Ch(e, f, g):
    return (e & f) ^ ((e ^ M) & g)

def Maj(a, b, c):
    return (a & b) ^ (a & c) ^ (b & c)

def add(*args):
    return sum(args) & M

def sub(a, b):
    return (a - b) & M

# ═══════════════════════════════════════════════════════════════
# Forward SHA-256 — records all intermediate state
# ═══════════════════════════════════════════════════════════════

def sha256_full(msg_words, n_rounds=64):
    """Run SHA-256, return hash, all W values, and all intermediate states."""
    W = list(msg_words)
    for t in range(16, 64):
        W.append(add(sigma1(W[t-2]), W[t-7], sigma0(W[t-15]), W[t-16]))

    states = []
    a, b, c, d, e, f, g, h = IV
    states.append((a, b, c, d, e, f, g, h))

    for t in range(n_rounds):
        T1 = add(h, Sigma1(e), Ch(e, f, g), K[t], W[t])
        T2 = add(Sigma0(a), Maj(a, b, c))
        h = g; g = f; f = e
        e = add(d, T1)
        d = c; c = b; b = a
        a = add(T1, T2)
        states.append((a, b, c, d, e, f, g, h))

    hash_out = [add(IV[i], v) for i, v in enumerate(states[-1])]
    return hash_out, W, states

# ═══════════════════════════════════════════════════════════════
# BACKWARD MAP — Direct inversion, no search
# Given: final state S[64] and the starting state S[start]
# Recover: W[start..63] by walking backward
# ═══════════════════════════════════════════════════════════════

def backward_one_round(state_after, t):
    """
    Given state AFTER round t (= state at start of round t+1),
    and the round index t, recover:
      - state BEFORE round t (= state at start of round t)
      - W[t] used in round t

    This requires knowing h_before, which is NOT in state_after.
    Returns (state_before_partial, W_t, h_needed)
    where h_needed is True if we couldn't determine h.
    """
    a1, b1, c1, d1, e1, f1, g1, h1 = state_after

    # From shift register:
    a0 = b1  # a_before = b_after
    b0 = c1
    c0 = d1
    e0 = f1
    f0 = g1
    g0 = h1

    # T2 from known values
    T2 = add(Sigma0(a0), Maj(a0, b0, c0))
    T1 = sub(a1, T2)
    d0 = sub(e1, T1)

    # h0 and W[t]: T1 = h0 + Sigma1(e0) + Ch(e0, f0, g0) + K[t] + W[t]
    # h0 + W[t] = T1 - Sigma1(e0) - Ch(e0, f0, g0) - K[t]
    rhs = sub(sub(sub(T1, Sigma1(e0)), Ch(e0, f0, g0)), K[t])

    # rhs = h0 + W[t] — we have ONE equation, TWO unknowns
    return (a0, b0, c0, d0, e0, f0, g0), T1, T2, rhs


def backward_map_with_known_start(hash_out, start_state, start_round, end_round=64):
    """
    Given the hash output AND the state at round `start_round`,
    directly compute all W values from start_round to end_round-1.

    This is the "overlay" — no search, no SAT solver.
    Each W[t] is computed by a direct formula.
    """
    # Recover final state from hash (subtract IV)
    final_state = tuple(sub(hash_out[i], IV[i]) for i in range(8))

    n = end_round - start_round
    W_recovered = [None] * 64

    # We work backward from final_state to start_state.
    # At each step we have:  h_before + W[t] = rhs
    # We can determine h_before from the START STATE propagated forward,
    # or from the chain of previous backward steps.

    # Strategy: walk backward from final_state.
    # For each round, we get 7 state values + rhs = h + W.
    # We need h to get W. Where does h come from?
    #
    # h at the start of round t = g at start of round t-1
    #                           = f at start of round t-2
    #                           = e at start of round t-3
    #
    # e at start of round t-3 = known from backward step at t-3
    # (it came from the shift register: e = f_after = g[two steps later])
    #
    # But for the FIRST 4 backward steps, the h values trace back to
    # the START STATE, which we know!

    # Forward pass from start_state to get all intermediate h values
    # (This is the "overlay" — we precompute h values from the known start)
    a, b, c, d, e, f, g, h = start_state
    forward_states = [(a, b, c, d, e, f, g, h)]

    for t in range(start_round, end_round):
        # We don't know W[t] yet during forward pass!
        # But we need it to compute the next state.
        # This is the CIRCULAR DEPENDENCY.
        break

    # ─── THE CIRCULARITY ───
    # To go backward: we need h_before, which depends on forward state
    # To go forward: we need W[t], which is what we're trying to find
    #
    # But there's a way out: the SHIFT REGISTER.
    # h at round t came from somewhere 3 rounds earlier as e.
    # If we're within 4 rounds of the end, h traces back to final_state.
    # Beyond that, h traces to state we haven't computed yet.

    # Let's see exactly how far we can get with ZERO guessing:
    current = list(final_state)
    recovered = {}
    steps_back = 0

    for t in range(end_round - 1, start_round - 1, -1):
        a1, b1, c1, d1, e1, f1, g1, h1 = current

        # Shift register gives us 6 values
        a0 = b1
        b0 = c1
        c0 = d1
        e0 = f1
        f0 = g1
        g0 = h1

        # T2 and T1 are fully determined from known values
        T2 = add(Sigma0(a0), Maj(a0, b0, c0))
        T1 = sub(a1, T2)
        d0 = sub(e1, T1)

        # rhs = h0 + W[t]
        rhs = sub(sub(sub(T1, Sigma1(e0)), Ch(e0, f0, g0)), K[t])

        # Can we determine h0?
        # h0 is the h value at the START of round t.
        # In the forward direction: h at start of round t = g at start of round t-1
        #                                                 = state[t-1][6]
        # We have start_state which is state[start_round].
        # h0 = start_state[7] when t = start_round
        # h0 = start_state[6] when t = start_round + 1 (g shifted to h)
        # h0 = start_state[5] when t = start_round + 2 (f→g→h)
        # h0 = start_state[4] when t = start_round + 3 (e→f→g→h)

        # From the OTHER end (backward):
        # h0 at round t = g0 at round t+1 (we computed this in previous backward step)
        #               = h1 of current step (which is g0 of the step we just set up)
        # Wait, g0 = h1. And h1 is from the state AFTER round t.
        # h0 (state before round t) is NOT directly in state after round t.
        # h0 is the value that was in position h before the round ran.
        # After the round: h_after = g_before. So h_after = g0 = h1.
        # But h_before (h0) went into T1. It's consumed, not preserved.

        # KEY: h0 is the ONLY state value that's consumed (not shifted) by the round.
        # It enters T1 and is lost. Every other value just shifts.

        # So to recover h0, we need external information.
        # If t is close to start_round, h0 is a shifted copy of start_state.
        # If t is far from start_round, h0 is unknown.

        steps_from_start = t - start_round

        # h at start of round t = (looking at the shift register forward from start):
        # t=start_round:   h = start_state[7] (h)
        # t=start_round+1: h = start_state[6] (g shifted to h)
        # t=start_round+2: h = start_state[5] (f→g→h)
        # t=start_round+3: h = start_state[4] (e→f→g→h)
        # t=start_round+4: h = d[start]+T1[start] ... depends on W[start]!

        h0 = None
        h_source = ""

        if steps_from_start == 0:
            h0 = start_state[7]
            h_source = "h from start state"
        elif steps_from_start == 1:
            h0 = start_state[6]
            h_source = "g from start state"
        elif steps_from_start == 2:
            h0 = start_state[5]
            h_source = "f from start state"
        elif steps_from_start == 3:
            h0 = start_state[4]
            h_source = "e from start state"
        else:
            h_source = "UNKNOWN — depends on W values we haven't found"

        if h0 is not None:
            W_t = sub(rhs, h0)
            recovered[t] = W_t
            W_recovered[t] = W_t
            status = f"✓ W[{t}] = 0x{W_t:08x}  (h from: {h_source})"
        else:
            status = f"✗ W[{t}] = h + 0x{rhs:08x}  ({h_source})"
            recovered[t] = None

        # Update current state for next backward step
        # Note: we can't set h0 if we don't know it, but the OTHER 7 values are fine
        if h0 is not None:
            current = [a0, b0, c0, d0, e0, f0, g0, h0]
        else:
            current = [a0, b0, c0, d0, e0, f0, g0, 0]  # placeholder

        if t >= end_round - 8 or t <= start_round + 3:
            print(f"    Round {t:2d}: {status}")

        steps_back += 1

    return W_recovered, recovered


def main():
    print("═" * 72)
    print("  SHA-256 Backward Map — Direct Inversion")
    print("  Can we walk back 16 rounds without search?")
    print("═" * 72)

    random.seed(42)
    msg = [random.getrandbits(32) for _ in range(16)]

    # Full forward computation
    hash_out, W_full, states = sha256_full(msg, 64)

    # ═══════════════════════════════════════════════════════════
    # TEST 1: Given S[48], directly recover W[48..63]
    # ═══════════════════════════════════════════════════════════
    print(f"\n  TEST 1: Backward from round 64, given S[48] (known start)")
    print(f"  Can we recover W[48..63] by direct formula?")
    print(f"  {'─' * 66}")

    start_state = states[48]

    print(f"\n  Walking backward from hash output...\n")
    W_recovered, recovered = backward_map_with_known_start(
        hash_out, start_state, start_round=48, end_round=64
    )

    # Verify
    print(f"\n  Verification:")
    n_correct = 0
    n_recovered = 0
    for t in range(48, 64):
        if recovered.get(t) is not None:
            n_recovered += 1
            match = recovered[t] == W_full[t]
            if match:
                n_correct += 1
                tag = "✓"
            else:
                tag = f"✗ expected 0x{W_full[t]:08x}"
            if t < 52 or t >= 60:
                print(f"    W[{t}]: {tag}")
    print(f"\n  Recovered: {n_recovered}/16,  Correct: {n_correct}/{n_recovered}")

    # ═══════════════════════════════════════════════════════════
    # TEST 2: Same but from S[0] (IV) — full 64 rounds
    # ═══════════════════════════════════════════════════════════
    print(f"\n{'═' * 72}")
    print(f"  TEST 2: Backward from round 64, given IV as start (round 0)")
    print(f"  How many W values can we recover before the chain breaks?")
    print(f"  {'─' * 66}")

    start_state_0 = tuple(IV)

    print(f"\n  Walking backward from hash output...\n")
    W_recovered2, recovered2 = backward_map_with_known_start(
        hash_out, start_state_0, start_round=0, end_round=64
    )

    n_correct2 = sum(1 for t in range(64) if recovered2.get(t) == W_full[t])
    n_recovered2 = sum(1 for t in range(64) if recovered2.get(t) is not None)
    print(f"\n  Recovered: {n_recovered2}/64,  Correct: {n_correct2}/{n_recovered2}")

    # ═══════════════════════════════════════════════════════════
    # KEY INSIGHT: The structure of the dependency
    # ═══════════════════════════════════════════════════════════
    print(f"\n{'═' * 72}")
    print(f"  THE STRUCTURE")
    print(f"{'═' * 72}")
    print(f"""
  Going backward from the hash:
    Round 63: h comes from FORWARD state → needs S[start]
    Round 62: h comes from FORWARD state → needs S[start]
    Round 61: h comes from FORWARD state → needs S[start]
    Round 60: h comes from FORWARD state → needs S[start]
    Round 59: h came through e→f→g→h from round 56 → needs W[56]
    ...and W[56] depends on earlier rounds...

  The first 4 backward steps are DIRECT (h from start state).
  Steps 5+ create a CHAIN: each h depends on a W from an earlier round.

  With S[48] known: first 4 W values (W[48..51]) are FREE.
    The rest chain through h → earlier rounds → earlier W values.

  The "overlay" must break this chain.
  It must express h at each round as a FUNCTION OF THE HASH OUTPUT,
  not as a function of the unknown forward state.

  That's the formula. That's what the K constants might enable.
  h[t] = F(hash, K, t) — a direct function, no chaining.
""")

    # ═══════════════════════════════════════════════════════════
    # TEST 3: What if we go backward from BOTH ends?
    # Forward 4 rounds from IV → get states 0..4
    # Backward 4 rounds from hash → get W[60..63]
    # Can we close the gap?
    # ═══════════════════════════════════════════════════════════
    print(f"{'═' * 72}")
    print(f"  TEST 3: Meet in the middle")
    print(f"  Forward 4 from IV + Backward 4 from hash")
    print(f"  {'─' * 66}")

    # Backward 4 from hash (these use h from S[60], which is S_forward[60])
    # But we DON'T know S[60] without the message...
    # UNLESS we also go forward from IV, which gives us S[0..4] directly.

    # Forward from IV: we know S[0]=IV but need W[0] to get S[1].
    # Without W values, we can't go forward either!

    # The ONLY free information is:
    # - The hash (256 bits)
    # - The IV (256 bits, public)
    # - The K constants (64 × 32 = 2048 bits, public)
    # Total known: 2560 bits
    # Unknown: message = 512 bits

    print(f"""
  Forward from IV: need W[0] to compute S[1] → blocked
  Backward from hash: need h (from S[start]) to get W → blocked

  Both directions block on the SAME thing:
  you need message bits to unstick either end.

  The "overlay" would need to be a function that takes
  the hash output and produces the message WITHOUT
  needing any intermediate state. A direct map:

    f(hash) → message

  16 quadratic equations in 16 unknowns (32-bit words).
  Each equation IS solvable (Ch and Maj are degree-2).
  The question is whether the SYSTEM has a closed-form solution.

  For Dual_EC, the closed form was: multiply by e⁻¹.
  For SHA-256, it would be: ___________________.

  That blank is worth filling.
""")


if __name__ == "__main__":
    main()
