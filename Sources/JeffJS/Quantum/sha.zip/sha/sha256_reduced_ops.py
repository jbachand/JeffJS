#!/usr/bin/env python3
"""
SHA-256 Reduced Operations Test

Can we compute a valid SHA-256 hash with fewer operations than
the published 64-round formula?

Approach:
1. Extract the full ANF (polynomial) of mini-SHA
2. Factor out common sub-expressions
3. Count operations: round-based vs direct polynomial vs factored
4. Test: at what round does the output STOP CHANGING?
5. Test: can we skip rounds and still get the same hash?
"""

import numpy as np
import random
from collections import Counter

BITS = 4
MASK = (1 << BITS) - 1
N = 1 << BITS

def rotr(x, n):
    n = n % BITS
    return ((x >> n) | (x << (BITS - n))) & MASK

def Ch(e, f, g):  return ((e & f) ^ ((e ^ MASK) & g)) & MASK
def Maj(a, b, c): return ((a & b) ^ (a & c) ^ (b & c)) & MASK
def Sigma0(a):    return (rotr(a, 1) ^ rotr(a, 2) ^ rotr(a, 3)) & MASK
def Sigma1(e):    return (rotr(e, 1) ^ rotr(e, 2) ^ rotr(e, 3)) & MASK
def sigma0(x):    return (rotr(x, 1) ^ rotr(x, 2) ^ (x >> 1)) & MASK
def sigma1(x):    return (rotr(x, 2) ^ rotr(x, 3) ^ (x >> 1)) & MASK

REAL_K = [k & MASK for k in [
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5,
    0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3,
    0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
]]
MINI_IV = [v & MASK for v in [
    0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
    0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19,
]]


def mini_sha(msg, n_rounds=16):
    W = list(msg[:16])
    while len(W) < 16: W.append(0)
    for t in range(16, max(n_rounds, 16)):
        W.append((sigma1(W[t-2]) + W[t-7] + sigma0(W[t-15]) + W[t-16]) & MASK)
    a, b, c, d, e, f, g, h = MINI_IV
    for t in range(n_rounds):
        T1 = (h + Sigma1(e) + Ch(e, f, g) + REAL_K[t % len(REAL_K)] + W[t]) & MASK
        T2 = (Sigma0(a) + Maj(a, b, c)) & MASK
        h = g; g = f; f = e; e = (d + T1) & MASK
        d = c; c = b; b = a; a = (T1 + T2) & MASK
    return [(MINI_IV[i] + v) & MASK for i, v in enumerate([a,b,c,d,e,f,g,h])]


def compute_anf(truth_table, n_vars):
    """Möbius transform → ANF."""
    n = 1 << n_vars
    anf = list(truth_table)
    for i in range(n_vars):
        step = 1 << i
        for j in range(n):
            if j & step:
                anf[j] ^= anf[j ^ step]
    return [j for j in range(n) if anf[j]]


def monomial_str(mono, var_names):
    if mono == 0: return "1"
    return "·".join(var_names[i] for i in range(len(var_names)) if mono & (1 << i))


def eval_anf(monomials, x, n_vars):
    """Evaluate ANF polynomial at point x."""
    result = 0
    for m in monomials:
        # Monomial evaluates to 1 iff all its variables are 1
        if (x & m) == m:
            result ^= 1
    return result


# ═══════════════════════════════════════════════════════════════
# TEST 1: At what round does the hash STABILIZE?
# Do later rounds actually change the output?
# ═══════════════════════════════════════════════════════════════

def test_round_convergence():
    print("═" * 72)
    print("  TEST 1: Round Convergence — Do later rounds change the output?")
    print("  If hash stops changing → later rounds are redundant")
    print("═" * 72)

    random.seed(42)
    n_samples = 1000

    print(f"\n  For {n_samples} random messages, compare hash at round N vs round 16:")
    print(f"\n  {'Rounds':>6s} │ {'Match 16':>10s} │ {'Bit diff':>10s} │ Status")
    print(f"  {'─'*6}─┼─{'─'*10}─┼─{'─'*10}─┼─{'─'*20}")

    for n_rounds in range(1, 17):
        matches = 0
        total_bit_diff = 0

        for _ in range(n_samples):
            msg = [random.getrandbits(BITS) for _ in range(16)]
            hash_n = mini_sha(msg, n_rounds)
            hash_16 = mini_sha(msg, 16)

            if hash_n == hash_16:
                matches += 1

            for i in range(8):
                total_bit_diff += bin(hash_n[i] ^ hash_16[i]).count('1')

        avg_diff = total_bit_diff / n_samples
        pct = matches / n_samples * 100
        status = "IDENTICAL" if matches == n_samples else f"{pct:.1f}% match"
        print(f"  {n_rounds:>6d} │ {matches:>10d} │ {avg_diff:>10.1f} │ {status}")


# ═══════════════════════════════════════════════════════════════
# TEST 2: Operation count — round-based vs polynomial
# ═══════════════════════════════════════════════════════════════

def test_operation_count():
    print(f"\n{'═' * 72}")
    print("  TEST 2: Operation Count — Rounds vs Direct Polynomial")
    print("  How many AND/XOR gates does each method need?")
    print("═" * 72)

    random.seed(42)
    fixed_W = [random.getrandbits(BITS) for _ in range(16)]

    n_input = 2 * BITS  # 8 bits
    n_total_inputs = 1 << n_input  # 256
    var_names = [f"w0.{i}" for i in range(BITS)] + [f"w1.{i}" for i in range(BITS)]

    # Round-based operation count (per round):
    # Ch: 3 AND, 1 XOR = 4 ops (per bit) × 4 bits = 16 ops
    # Maj: 3 AND, 2 XOR = 5 ops × 4 = 20 ops
    # Sigma0: 3 rotations + 2 XOR = 2 ops × 4 = 8 ops (rotations are free rewiring)
    # Sigma1: same = 8 ops
    # Additions (mod 4): ~3 ops per bit × 4 bits × 4 additions = 48 ops
    # Total per round: ~100 ops
    # 16 rounds: ~1600 ops

    ops_per_round = 16 + 20 + 8 + 8 + 48  # rough count
    total_round_ops = ops_per_round * 16

    # Polynomial-based operation count:
    # For each output bit: evaluate its ANF
    # Each monomial of degree d requires d-1 AND gates
    # Summing k monomials requires k-1 XOR gates

    total_poly_ops = 0
    all_monomials_sets = []
    all_monomials_list = []

    for word_idx in range(8):
        for bit_idx in range(BITS):
            tt = []
            for x in range(n_total_inputs):
                w0 = x & MASK
                w1 = (x >> BITS) & MASK
                msg = [w0, w1] + fixed_W[2:]
                h = mini_sha(msg)
                tt.append((h[word_idx] >> bit_idx) & 1)
            monomials = compute_anf(tt, n_input)
            all_monomials_sets.append(set(monomials))
            all_monomials_list.append(monomials)

            # Cost: (degree-1) ANDs per monomial + (n_terms-1) XORs
            ands = sum(max(0, bin(m).count('1') - 1) for m in monomials)
            xors = max(0, len(monomials) - 1)
            total_poly_ops += ands + xors

    print(f"\n  Round-based (16 rounds × ~{ops_per_round} ops/round):")
    print(f"    Total operations: ~{total_round_ops}")

    print(f"\n  Direct polynomial evaluation (no factoring):")
    print(f"    Total operations: {total_poly_ops}")
    print(f"    Ratio: {total_poly_ops/total_round_ops:.2f}x of round-based")

    # Factored polynomial: compute each monomial ONCE, reuse across output bits
    all_unique_monomials = set()
    for mset in all_monomials_sets:
        all_unique_monomials.update(mset)

    # Cost of computing all unique monomials once
    mono_compute_cost = sum(max(0, bin(m).count('1') - 1) for m in all_unique_monomials)

    # Cost of combining monomials into output bits (XOR)
    combine_cost = sum(max(0, len(ml) - 1) for ml in all_monomials_list)

    total_factored_ops = mono_compute_cost + combine_cost

    print(f"\n  Factored polynomial (compute each monomial once, reuse):")
    print(f"    Unique monomials: {len(all_unique_monomials)}")
    print(f"    Monomial compute cost: {mono_compute_cost} ANDs")
    print(f"    Combine cost: {combine_cost} XORs")
    print(f"    Total operations: {total_factored_ops}")
    print(f"    Ratio: {total_factored_ops/total_round_ops:.2f}x of round-based")
    print(f"    Savings vs direct: {total_poly_ops/total_factored_ops:.2f}x")

    # How much do shared monomials save?
    mono_usage = Counter()
    for mset in all_monomials_sets:
        for m in mset:
            mono_usage[m] += 1

    reuse_count = sum(max(0, c - 1) for c in mono_usage.values())
    max_reuse = max(mono_usage.values())

    print(f"\n  Sharing analysis:")
    print(f"    Total monomial reuses (saved computations): {reuse_count}")
    print(f"    Most-reused monomial used in: {max_reuse}/32 output bits")

    return total_round_ops, total_poly_ops, total_factored_ops


# ═══════════════════════════════════════════════════════════════
# TEST 3: XOR-only + carry correction
# Compute the hash as: XOR-hash + carry delta
# ═══════════════════════════════════════════════════════════════

def test_carry_correction():
    print(f"\n{'═' * 72}")
    print("  TEST 3: XOR-only + Carry Correction")
    print("  Compute hash = XOR_hash ⊕ carry_delta")
    print("  If delta is sparse → the carries are cheap corrections")
    print("═" * 72)

    def mini_sha_xor(msg, n_rounds=16):
        W = list(msg[:16])
        while len(W) < 16: W.append(0)
        for t in range(16, max(n_rounds, 16)):
            W.append(sigma1(W[t-2]) ^ W[t-7] ^ sigma0(W[t-15]) ^ W[t-16])
        a, b, c, d, e, f, g, h = MINI_IV
        for t in range(n_rounds):
            T1 = h ^ Sigma1(e) ^ Ch(e, f, g) ^ REAL_K[t % len(REAL_K)] ^ W[t]
            T2 = Sigma0(a) ^ Maj(a, b, c)
            h = g; g = f; f = e; e = d ^ T1
            d = c; c = b; b = a; a = T1 ^ T2
        return [MINI_IV[i] ^ v for i, v in enumerate([a,b,c,d,e,f,g,h])]

    random.seed(42)
    n_samples = 10000

    delta_bits_total = 0
    delta_zero_count = 0

    for _ in range(n_samples):
        msg = [random.getrandbits(BITS) for _ in range(16)]
        h_real = mini_sha(msg)
        h_xor = mini_sha_xor(msg)

        delta = [h_real[i] ^ h_xor[i] for i in range(8)]
        delta_bits = sum(bin(d).count('1') for d in delta)
        delta_bits_total += delta_bits

        if all(d == 0 for d in delta):
            delta_zero_count += 1

    avg_delta_bits = delta_bits_total / n_samples
    max_possible_bits = 8 * BITS

    print(f"\n  Over {n_samples} random messages:")
    print(f"    Average delta bits:    {avg_delta_bits:.1f} / {max_possible_bits}")
    print(f"    Exact matches (δ=0):   {delta_zero_count} / {n_samples}")
    print(f"    Delta density:         {avg_delta_bits/max_possible_bits*100:.1f}%")

    if avg_delta_bits < max_possible_bits * 0.3:
        print(f"    ★ Delta is SPARSE — carries are a small correction!")
    elif avg_delta_bits > max_possible_bits * 0.4:
        print(f"    Delta is dense — carries are significant at this scale")

    # Analyze delta polynomial (the carry correction)
    print(f"\n  Carry correction polynomial analysis:")

    n_input = 2 * BITS
    n_total_inputs = 1 << n_input
    fixed_W = [random.getrandbits(BITS) for _ in range(16)]

    delta_degrees = []
    delta_terms = []

    for word_idx in range(8):
        for bit_idx in range(BITS):
            tt = []
            for x in range(n_total_inputs):
                w0 = x & MASK
                w1 = (x >> BITS) & MASK
                msg = [w0, w1] + fixed_W[2:]
                h_real = mini_sha(msg)
                h_xor = mini_sha_xor(msg)
                delta_bit = ((h_real[word_idx] ^ h_xor[word_idx]) >> bit_idx) & 1
                tt.append(delta_bit)

            monomials = compute_anf(tt, n_input)
            degree = max((bin(m).count('1') for m in monomials), default=0)
            delta_degrees.append(degree)
            delta_terms.append(len(monomials))

    avg_deg = np.mean(delta_degrees)
    avg_terms = np.mean(delta_terms)
    max_deg = max(delta_degrees)

    print(f"    Delta polynomial average degree: {avg_deg:.1f}")
    print(f"    Delta polynomial max degree:     {max_deg}")
    print(f"    Delta polynomial average terms:   {avg_terms:.1f}")

    # Compare with the full hash polynomial
    full_terms = []
    for word_idx in range(8):
        for bit_idx in range(BITS):
            tt = []
            for x in range(n_total_inputs):
                w0 = x & MASK
                w1 = (x >> BITS) & MASK
                msg = [w0, w1] + fixed_W[2:]
                h_real = mini_sha(msg)
                tt.append((h_real[word_idx] >> bit_idx) & 1)
            monomials = compute_anf(tt, n_input)
            full_terms.append(len(monomials))

    xor_terms = []
    for word_idx in range(8):
        for bit_idx in range(BITS):
            tt = []
            for x in range(n_total_inputs):
                w0 = x & MASK
                w1 = (x >> BITS) & MASK
                msg = [w0, w1] + fixed_W[2:]
                h_xor = mini_sha_xor(msg)
                tt.append((h_xor[word_idx] >> bit_idx) & 1)
            monomials = compute_anf(tt, n_input)
            xor_terms.append(len(monomials))

    print(f"\n  Polynomial complexity comparison:")
    print(f"    {'Component':<20s} │ {'Avg terms':>10s} │ {'Max terms':>10s}")
    print(f"    {'─'*20}─┼─{'─'*10}─┼─{'─'*10}")
    print(f"    {'Full SHA'::<20s} │ {np.mean(full_terms):>10.1f} │ {max(full_terms):>10d}")
    print(f"    {'XOR-only'::<20s} │ {np.mean(xor_terms):>10.1f} │ {max(xor_terms):>10d}")
    print(f"    {'Carry delta'::<20s} │ {np.mean(delta_terms):>10.1f} │ {max(delta_terms):>10d}")
    print(f"    {'XOR + delta'::<20s} │ {np.mean(xor_terms)+np.mean(delta_terms):>10.1f} │ "
          f"{max(xor_terms)+max(delta_terms):>10d}")


# ═══════════════════════════════════════════════════════════════
# TEST 4: Can we compute the hash from a SUBSET of rounds?
# If round N's polynomial equals round 16's, rounds N+1..16 are free
# ═══════════════════════════════════════════════════════════════

def test_polynomial_convergence():
    print(f"\n{'═' * 72}")
    print("  TEST 4: Polynomial Convergence")
    print("  At what round do the output polynomials stop changing?")
    print("  If they stabilize → remaining rounds are computable shortcuts")
    print("═" * 72)

    random.seed(42)
    fixed_W = [random.getrandbits(BITS) for _ in range(16)]

    n_input = 2 * BITS
    n_total_inputs = 1 << n_input

    # For each round count, compute the ANF of output bit h[0].0
    prev_monomials = None

    print(f"\n  Tracking h[0].0 polynomial across rounds:\n")
    print(f"  {'Rounds':>6s} │ {'Degree':>6s} │ {'Terms':>6s} │ {'Changed':>8s} │ {'New terms':>9s} │ {'Lost terms':>10s}")
    print(f"  {'─'*6}─┼─{'─'*6}─┼─{'─'*6}─┼─{'─'*8}─┼─{'─'*9}─┼─{'─'*10}")

    for n_rounds in range(1, 17):
        tt = []
        for x in range(n_total_inputs):
            w0 = x & MASK
            w1 = (x >> BITS) & MASK
            msg = [w0, w1] + fixed_W[2:]
            h = mini_sha(msg, n_rounds)
            tt.append((h[0] >> 0) & 1)

        monomials = set(compute_anf(tt, n_input))
        degree = max((bin(m).count('1') for m in monomials), default=0)

        if prev_monomials is not None:
            new_terms = monomials - prev_monomials
            lost_terms = prev_monomials - monomials
            changed = len(new_terms) + len(lost_terms)
        else:
            new_terms = monomials
            lost_terms = set()
            changed = len(monomials)

        print(f"  {n_rounds:>6d} │ {degree:>6d} │ {len(monomials):>6d} │ {changed:>8d} │ {len(new_terms):>9d} │ {len(lost_terms):>10d}")
        prev_monomials = monomials

    # Check: is there a round after which the polynomial is IDENTICAL to round 16?
    tt_16 = []
    for x in range(n_total_inputs):
        w0 = x & MASK
        w1 = (x >> BITS) & MASK
        msg = [w0, w1] + fixed_W[2:]
        h = mini_sha(msg, 16)
        tt_16.append((h[0] >> 0) & 1)
    mono_16 = set(compute_anf(tt_16, n_input))

    print(f"\n  Checking: which round first matches the round-16 polynomial?")
    for n_rounds in range(1, 17):
        tt = []
        for x in range(n_total_inputs):
            w0 = x & MASK
            w1 = (x >> BITS) & MASK
            msg = [w0, w1] + fixed_W[2:]
            h = mini_sha(msg, n_rounds)
            tt.append((h[0] >> 0) & 1)
        mono_n = set(compute_anf(tt, n_input))
        if mono_n == mono_16:
            print(f"    Round {n_rounds} matches round 16: YES ★")
            if n_rounds < 16:
                print(f"    ★ Rounds {n_rounds+1}-16 are REDUNDANT!")
            break
    else:
        print(f"    No early convergence — polynomial changes every round")


# ═══════════════════════════════════════════════════════════════
# TEST 5: Equivalent reduced formula
# Can we find a DIFFERENT set of operations that produces the
# same output as 16-round SHA but with fewer steps?
# ═══════════════════════════════════════════════════════════════

def test_reduced_formula():
    print(f"\n{'═' * 72}")
    print("  TEST 5: Is there a reduced formula?")
    print("  Verify the ANF polynomial produces IDENTICAL output to SHA")
    print("  for ALL inputs — proving they're the same function")
    print("═" * 72)

    random.seed(42)
    fixed_W = [random.getrandbits(BITS) for _ in range(16)]

    n_input = 2 * BITS
    n_total_inputs = 1 << n_input

    # Build the complete ANF for all output bits
    all_anfs = {}
    for word_idx in range(8):
        for bit_idx in range(BITS):
            tt = []
            for x in range(n_total_inputs):
                w0 = x & MASK
                w1 = (x >> BITS) & MASK
                msg = [w0, w1] + fixed_W[2:]
                h = mini_sha(msg)
                tt.append((h[word_idx] >> bit_idx) & 1)
            all_anfs[(word_idx, bit_idx)] = compute_anf(tt, n_input)

    # Verify: evaluate ANF for all inputs, compare with SHA
    mismatches = 0
    for x in range(n_total_inputs):
        w0 = x & MASK
        w1 = (x >> BITS) & MASK
        msg = [w0, w1] + fixed_W[2:]
        h_sha = mini_sha(msg)

        h_anf = [0] * 8
        for word_idx in range(8):
            for bit_idx in range(BITS):
                bit_val = eval_anf(all_anfs[(word_idx, bit_idx)], x, n_input)
                h_anf[word_idx] |= (bit_val << bit_idx)

        if h_sha != h_anf:
            mismatches += 1

    print(f"\n  ANF polynomial vs SHA-256 round computation:")
    print(f"    Tested: all {n_total_inputs} inputs")
    print(f"    Mismatches: {mismatches}")
    print(f"    Result: {'IDENTICAL ★' if mismatches == 0 else 'DIFFER'}")

    if mismatches == 0:
        # Count total operations for ANF evaluation
        total_and = 0
        total_xor = 0
        unique_monomials = set()
        for anf in all_anfs.values():
            for m in anf:
                unique_monomials.add(m)

        # Shared computation: each monomial computed once
        for m in unique_monomials:
            deg = bin(m).count('1')
            if deg > 0:
                total_and += deg - 1  # AND chain for the product

        for anf in all_anfs.values():
            if len(anf) > 0:
                total_xor += len(anf) - 1  # XOR to sum monomials

        total_anf_ops = total_and + total_xor
        round_ops = 100 * 16  # rough estimate

        print(f"\n  Operation comparison:")
        print(f"    Round-based (16 rounds):  ~{round_ops} operations")
        print(f"    ANF polynomial (factored): {total_anf_ops} operations")
        print(f"      ({total_and} ANDs + {total_xor} XORs)")
        print(f"      using {len(unique_monomials)} unique monomials")
        print(f"    Speedup: {round_ops/total_anf_ops:.1f}x")

        print(f"\n  ★ The ANF IS the 'reduced formula'.")
        print(f"    It computes the EXACT SAME hash as 16 rounds of SHA,")
        print(f"    but expressed as a single polynomial evaluation.")
        print(f"    No rounds. No state. No schedule. Just multiply and XOR.")


# ═══════════════════════════════════════════════════════════════

if __name__ == "__main__":
    test_round_convergence()
    round_ops, poly_ops, factored_ops = test_operation_count()
    test_carry_correction()
    test_polynomial_convergence()
    test_reduced_formula()

    print(f"\n{'═' * 72}")
    print(f"  IMPLICATIONS")
    print(f"{'═' * 72}")
    print(f"""
  If the ANF polynomial computes the same hash with fewer operations:
    1. The round-based structure is NOT the simplest representation
    2. The extra operations in the round structure are camouflage
    3. The polynomial form is the "true" function
    4. Inverting a polynomial is ALGEBRAIC (Gröbner bases, SAT)
    5. The polynomial can be loaded directly into a quantum circuit

  For real SHA-256 (32-bit words):
    The polynomial would have ~512 input variables
    Degree ~8 (if carries are stripped) to ~32 (with carries)
    Each output bit is one polynomial
    256 output bits = 256 polynomials
    Shared monomials reduce total operations

  The question becomes:
    Is the SHA-256 polynomial SOLVABLE (invertible)?
    Not "is SHA-256 secure?" but "is this SPECIFIC polynomial system tractable?"
""")
