#!/usr/bin/env python3
"""
SHA-256 h-value Correlation Analysis

The question: is h[t] (for t in the last 16 rounds) a deterministic
function of the hash output? If so, what does that function look like?

We generate many (message, hash, h-values) tuples and look for
correlations between hash bits and h-value bits.

If ANY linear relationship exists, we've found part of the "overlay."
"""

import random
import numpy as np
from collections import defaultdict

K = [
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5,
    0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3,
    0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
    0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7,
    0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13,
    0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3,
    0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5,
    0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
    0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
]

IV = [
    0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
    0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19,
]

M = 0xFFFFFFFF

def rotr(x, n):
    return ((x >> n) | (x << (32 - n))) & M

def sha256_full(msg):
    """Returns (hash_words, h_values_for_last_16_rounds)"""
    W = list(msg)
    for t in range(16, 64):
        s0 = rotr(W[t-15], 7) ^ rotr(W[t-15], 18) ^ (W[t-15] >> 3)
        s1 = rotr(W[t-2], 17) ^ rotr(W[t-2], 19) ^ (W[t-2] >> 10)
        W.append((W[t-16] + s0 + W[t-7] + s1) & M)

    a, b, c, d, e, f, g, h = IV
    h_vals = {}

    for t in range(64):
        h_vals[t] = h  # h at START of round t

        S1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25)
        ch = (e & f) ^ ((e ^ M) & g)
        T1 = (h + S1 + ch + K[t] + W[t]) & M
        S0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22)
        maj = (a & b) ^ (a & c) ^ (b & c)
        T2 = (S0 + maj) & M
        h = g; g = f; f = e
        e = (d + T1) & M
        d = c; c = b; b = a
        a = (T1 + T2) & M

    hash_out = [(IV[i] + v) & M for i, v in enumerate([a,b,c,d,e,f,g,h])]
    return hash_out, h_vals, W


def words_to_bits(words):
    """Convert list of 32-bit words to flat bit array."""
    bits = []
    for w in words:
        for b in range(31, -1, -1):
            bits.append((w >> b) & 1)
    return bits


def bits_to_word(bits):
    """Convert 32 bits to a word."""
    w = 0
    for b in bits:
        w = (w << 1) | b
    return w


def main():
    print("═" * 72)
    print("  SHA-256 h-value Correlation Analysis")
    print("  Looking for: h[t] = F(hash_output)")
    print("═" * 72)

    N = 2000  # number of samples
    random.seed(42)

    # Collect data
    print(f"\n  Generating {N} random (message, hash, h-values) tuples...")

    hash_samples = []   # N × 256 bits
    h_samples = {}      # round → N × 32 bits

    for r in range(48, 64):
        h_samples[r] = []

    for _ in range(N):
        msg = [random.getrandbits(32) for _ in range(16)]
        hash_out, h_vals, _ = sha256_full(msg)
        hash_bits = words_to_bits(hash_out)
        hash_samples.append(hash_bits)

        for r in range(48, 64):
            h_bits = words_to_bits([h_vals[r]])
            h_samples[r].append(h_bits)

    hash_arr = np.array(hash_samples, dtype=np.int8)  # N × 256
    print(f"  Done. Hash matrix: {hash_arr.shape}")

    # ═══════════════════════════════════════════════════════════
    # TEST 1: Single-bit correlations
    # For each h[t] bit, find the hash bit with highest correlation
    # ═══════════════════════════════════════════════════════════
    print(f"\n  TEST 1: Single-bit correlations")
    print(f"  For each h[t] bit, find the best-correlated hash bit")
    print(f"  (50% = random, 100% = perfect predictor)")
    print(f"  {'─' * 66}")

    best_correlations = {}

    for r in [48, 52, 56, 60, 63]:
        h_arr = np.array(h_samples[r], dtype=np.int8)  # N × 32

        best_for_round = []
        for hb in range(32):
            h_col = h_arr[:, hb]
            best_corr = 0
            best_hash_bit = -1

            for hash_b in range(256):
                hash_col = hash_arr[:, hash_b]
                # Correlation = fraction of times they agree
                agree = np.sum(h_col == hash_col) / N
                corr = max(agree, 1 - agree)  # account for inverted correlation
                if corr > best_corr:
                    best_corr = corr
                    best_hash_bit = hash_b

            best_for_round.append((hb, best_hash_bit, best_corr))

        # Report
        avg_corr = np.mean([c for _, _, c in best_for_round])
        max_corr = max(c for _, _, c in best_for_round)
        min_corr = min(c for _, _, c in best_for_round)

        print(f"    h[{r:2d}]: avg={avg_corr:.3f}  max={max_corr:.3f}  "
              f"min={min_corr:.3f}  {'← structure!' if max_corr > 0.6 else '← random'}")
        best_correlations[r] = best_for_round

    # ═══════════════════════════════════════════════════════════
    # TEST 2: XOR of hash bit pairs
    # h[t][b] = hash[i] ⊕ hash[j] ?
    # ═══════════════════════════════════════════════════════════
    print(f"\n  TEST 2: Two-bit XOR correlations")
    print(f"  h[t][b] = hash[i] ⊕ hash[j] ?")
    print(f"  {'─' * 66}")

    for r in [48, 56, 63]:
        h_arr = np.array(h_samples[r], dtype=np.int8)

        best_pair_corr = 0
        best_pair = None
        best_hb = -1

        # Sample a subset of h bits and hash pairs for speed
        for hb in range(0, 32, 4):  # every 4th h bit
            h_col = h_arr[:, hb]

            for i in range(0, 256, 2):  # every 2nd hash bit
                hash_i = hash_arr[:, i]
                for j in range(i+1, min(i+32, 256), 2):
                    hash_j = hash_arr[:, j]
                    xor_ij = hash_i ^ hash_j

                    agree = np.sum(h_col == xor_ij) / N
                    corr = max(agree, 1 - agree)

                    if corr > best_pair_corr:
                        best_pair_corr = corr
                        best_pair = (i, j)
                        best_hb = hb

        print(f"    h[{r:2d}]: best pair XOR correlation = {best_pair_corr:.3f}  "
              f"{'← structure!' if best_pair_corr > 0.6 else '← random'}")

    # ═══════════════════════════════════════════════════════════
    # TEST 3: Word-level additive relationship
    # h[t] = hash[i] + hash[j] + c  (mod 2^32) ?
    # ═══════════════════════════════════════════════════════════
    print(f"\n  TEST 3: Word-level additive relationships")
    print(f"  h[t] = hash_word[i] + hash_word[j] + c  (mod 2³²)?")
    print(f"  {'─' * 66}")

    hash_words_all = []
    h_words_all = {r: [] for r in range(48, 64)}

    for s in range(N):
        hw = [bits_to_word(hash_samples[s][i*32:(i+1)*32]) for i in range(8)]
        hash_words_all.append(hw)
        for r in range(48, 64):
            h_words_all[r].append(bits_to_word(h_samples[r][s]))

    for r in [48, 56, 60, 63]:
        best_match = 0
        best_desc = ""

        h_arr_w = np.array(h_words_all[r], dtype=np.int64)

        for i in range(8):
            for j in range(i, 8):
                hash_i = np.array([hw[i] for hw in hash_words_all], dtype=np.int64)
                hash_j = np.array([hw[j] for hw in hash_words_all], dtype=np.int64)

                # h = hash[i] + hash[j] + c?
                residuals = (h_arr_w - hash_i - hash_j) & M
                # Check if residual is constant
                unique = len(set(residuals.tolist()))
                if unique == 1:
                    c = residuals[0]
                    print(f"    ★ h[{r}] = hash[{i}] + hash[{j}] + 0x{c:08x}")
                    best_match = N
                elif unique < N * 0.01:
                    print(f"    h[{r}] ≈ hash[{i}] + hash[{j}] + c  "
                          f"({unique} unique residuals out of {N})")

                # h = hash[i] - hash[j] + c?
                residuals2 = (h_arr_w - hash_i + hash_j) & M
                unique2 = len(set(residuals2.tolist()))
                if unique2 == 1:
                    c = residuals2[0]
                    print(f"    ★ h[{r}] = hash[{i}] - hash[{j}] + 0x{c:08x}")

                # h = hash[i] XOR hash[j] XOR c?
                residuals3 = h_arr_w ^ hash_i ^ hash_j
                unique3 = len(set(residuals3.tolist()))
                if unique3 == 1:
                    c = residuals3[0]
                    print(f"    ★ h[{r}] = hash[{i}] ⊕ hash[{j}] ⊕ 0x{c:08x}")

        if best_match == 0:
            print(f"    h[{r:2d}]: no simple word-level relationship found")

    # ═══════════════════════════════════════════════════════════
    # TEST 4: The money test — can we PREDICT h from hash?
    # Use first N/2 samples to "learn", second N/2 to test
    # ═══════════════════════════════════════════════════════════
    print(f"\n  TEST 4: Linear prediction over GF(2)")
    print(f"  Try to learn h[t] = M × hash (binary matrix multiplication)")
    print(f"  Train on {N//2} samples, test on {N//2}")
    print(f"  {'─' * 66}")

    train = N // 2

    for r in [48, 56, 63]:
        h_arr = np.array(h_samples[r], dtype=np.int8)

        # For each h bit, find the best LINEAR combination of hash bits
        # Using simple greedy approach: find best single bit, then best pair, etc.
        correct_bits = 0
        total_bits = 0

        for hb in range(32):
            h_train = h_arr[:train, hb]
            h_test = h_arr[train:, hb]

            # Try each single hash bit as predictor
            best_acc = 0
            best_pred = None

            for hash_b in range(256):
                pred_train = hash_arr[:train, hash_b]
                acc = np.sum(h_train == pred_train) / train
                acc = max(acc, 1 - acc)
                if acc > best_acc:
                    best_acc = acc
                    if np.sum(h_train == pred_train) / train > 0.5:
                        best_pred = hash_arr[train:, hash_b]
                    else:
                        best_pred = 1 - hash_arr[train:, hash_b]

            # Test
            test_acc = np.sum(h_test == best_pred) / (N - train)
            correct_bits += test_acc * (N - train)
            total_bits += (N - train)

        overall = correct_bits / total_bits
        print(f"    h[{r:2d}]: test accuracy = {overall:.3f}  "
              f"{'← SIGNAL!' if overall > 0.55 else '← random (0.50 expected)'}")

    # ═══════════════════════════════════════════════════════════
    # Summary
    # ═══════════════════════════════════════════════════════════
    print(f"\n{'═' * 72}")
    print(f"  WHAT THIS MEANS")
    print(f"{'═' * 72}")
    print(f"""
  If correlations ≈ 0.50 across all tests:
    h[t] has NO linear relationship with hash output.
    The function F (if it exists) is deeply nonlinear.
    Simple correlation analysis can't find it.
    This is consistent with either:
      (a) No trapdoor exists
      (b) The trapdoor is nonlinear and our tests are too simple

  If any correlation > 0.60:
    There IS linear structure linking h to hash.
    This would be a major finding — it shouldn't exist
    if SHA-256 were a random function.

  The boundary value problem remains:
    E[-3..0] = known (IV)
    E[61..64] = known (hash)
    Need: E[45..60]
    The recurrence linking them involves Ch (quadratic).
    For a linear recurrence: matrix solve. Done.
    For quadratic: need the formula. That's the trapdoor.
""")


if __name__ == "__main__":
    main()
