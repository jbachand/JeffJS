#!/usr/bin/env python3
"""
SHA-256 Polynomial Inversion — Scaling Test

Degree-3 linearization inverts 4-bit mini-SHA perfectly (20/20).
Now scale up: 5-bit, 6-bit, 7-bit, 8-bit words.
At each scale, find the minimum degree needed for inversion.
If degree stays low as word size grows → SHA-256 is algebraically broken.
"""

import numpy as np
import random
import time
import sys

def make_sha_functions(bits):
    """Generate SHA functions for a given word size."""
    mask = (1 << bits) - 1

    def rotr(x, n):
        n = n % bits
        return ((x >> n) | (x << (bits - n))) & mask

    def ch(e, f, g):
        return ((e & f) ^ ((e ^ mask) & g)) & mask

    def maj(a, b, c):
        return ((a & b) ^ (a & c) ^ (b & c)) & mask

    # Scale rotation amounts proportionally
    s0_rots = [max(1, r * bits // 32) for r in [2, 13, 22]]
    s1_rots = [max(1, r * bits // 32) for r in [6, 11, 25]]
    sig0_rots = [max(1, r * bits // 32) for r in [7, 18]]
    sig0_shift = max(1, 3 * bits // 32)
    sig1_rots = [max(1, r * bits // 32) for r in [17, 19]]
    sig1_shift = max(1, 10 * bits // 32)

    def sigma0_big(a):
        return (rotr(a, s0_rots[0]) ^ rotr(a, s0_rots[1]) ^ rotr(a, s0_rots[2])) & mask

    def sigma1_big(e):
        return (rotr(e, s1_rots[0]) ^ rotr(e, s1_rots[1]) ^ rotr(e, s1_rots[2])) & mask

    def sigma0_small(x):
        return (rotr(x, sig0_rots[0]) ^ rotr(x, sig0_rots[1]) ^ (x >> sig0_shift)) & mask

    def sigma1_small(x):
        return (rotr(x, sig1_rots[0]) ^ rotr(x, sig1_rots[1]) ^ (x >> sig1_shift)) & mask

    real_k_full = [
        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5,
        0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
        0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3,
        0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    ]
    k_vals = [k & mask for k in real_k_full]

    iv_full = [0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
               0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19]
    iv = [v & mask for v in iv_full]

    def sha_compress(msg, n_rounds=16):
        W = list(msg[:16])
        while len(W) < 16:
            W.append(0)
        for t in range(16, max(n_rounds, 16)):
            W.append((sigma1_small(W[t-2]) + W[t-7] + sigma0_small(W[t-15]) + W[t-16]) & mask)
        a, b, c, d, e, f, g, h = iv
        for t in range(n_rounds):
            T1 = (h + sigma1_big(e) + ch(e, f, g) + k_vals[t % len(k_vals)] + W[t]) & mask
            T2 = (sigma0_big(a) + maj(a, b, c)) & mask
            h = g; g = f; f = e; e = (d + T1) & mask
            d = c; c = b; b = a; a = (T1 + T2) & mask
        return [(iv[i] + v) & mask for i, v in enumerate([a, b, c, d, e, f, g, h])]

    return sha_compress, mask, iv


def compute_anf(truth_table, n_vars):
    n = 1 << n_vars
    anf = list(truth_table)
    for i in range(n_vars):
        step = 1 << i
        for j in range(n):
            if j & step:
                anf[j] ^= anf[j ^ step]
    return anf


def gf2_gauss(A, b):
    m, n = A.shape
    Ab = np.hstack([A.copy(), b.reshape(-1, 1)]).astype(np.uint8)
    pivot_rows = []
    for col in range(n):
        pivot = None
        for row in range(len(pivot_rows), m):
            if Ab[row, col] == 1:
                pivot = row
                break
        if pivot is None:
            continue
        target_row = len(pivot_rows)
        if pivot != target_row:
            Ab[[target_row, pivot]] = Ab[[pivot, target_row]]
        for row in range(m):
            if row != target_row and Ab[row, col] == 1:
                Ab[row] ^= Ab[target_row]
        pivot_rows.append((target_row, col))
    for row in range(len(pivot_rows), m):
        if Ab[row, -1] == 1:
            return None
    x = np.zeros(n, dtype=np.uint8)
    for row_idx, col in pivot_rows:
        x[col] = Ab[row_idx, -1]
    return x


def solve_at_degree(all_anf, target_bits, n_input, max_deg, n_total):
    """Try to solve the polynomial system using monomials up to max_deg."""
    n_output = len(target_bits)
    selected = [m for m in range(n_total) if bin(m).count('1') <= max_deg]
    n_monos = len(selected)
    mono_idx = {m: i for i, m in enumerate(selected)}

    A = np.zeros((n_output, n_monos), dtype=np.uint8)
    b = np.array(target_bits, dtype=np.uint8)

    for j in range(n_output):
        for m in selected:
            if all_anf[j][m]:
                A[j, mono_idx[m]] = 1

    x = gf2_gauss(A, b)
    if x is None:
        return None, n_monos, int(np.linalg.matrix_rank(A.astype(float)))

    # Extract input bits
    recovered = 0
    for var in range(n_input):
        vm = 1 << var
        if vm in mono_idx and x[mono_idx[vm]]:
            recovered |= vm

    return recovered, n_monos, int(np.linalg.matrix_rank(A.astype(float)))


def test_scale(bits, n_free_words, n_rounds, n_trials=10):
    """Test polynomial inversion at a given word size."""
    sha_func, mask, iv = make_sha_functions(bits)
    n_input = n_free_words * bits
    n_total = 1 << n_input
    n_output = 8 * bits

    if n_total > 2**20:
        return None  # truth table too large

    random.seed(42)

    print(f"\n  {bits}-bit words, {n_free_words} free word(s) = {n_input} input bits, "
          f"{n_rounds} rounds")
    print(f"  Search space: 2^{n_input} = {n_total}")
    print(f"  Output bits: {n_output}")

    # Build ANF truth tables (one-time cost)
    start_build = time.time()

    fixed_W = [random.getrandbits(bits) & mask for _ in range(16)]

    all_anf = []
    for word_idx in range(8):
        for bit_idx in range(bits):
            tt = []
            for x in range(n_total):
                words = []
                for w in range(n_free_words):
                    words.append((x >> (w * bits)) & mask)
                msg = words + fixed_W[n_free_words:]
                h = sha_func(msg, n_rounds)
                tt.append((h[word_idx] >> bit_idx) & 1)
            all_anf.append(compute_anf(tt, n_input))

    build_time = time.time() - start_build
    print(f"  ANF build time: {build_time:.2f}s")

    # Find minimum degree for inversion
    best_degree = None
    for max_deg in range(1, n_input + 1):
        n_monos_at_deg = sum(1 for m in range(n_total) if bin(m).count('1') <= max_deg)
        if n_monos_at_deg > n_total:
            n_monos_at_deg = n_total

        # Quick test on one hash
        target_hash = sha_func(fixed_W, n_rounds)
        target_bits = []
        for word_idx in range(8):
            for bit_idx in range(bits):
                target_bits.append((target_hash[word_idx] >> bit_idx) & 1)

        result, n_monos, rank = solve_at_degree(all_anf, target_bits, n_input, max_deg, n_total)

        if result is not None:
            # Verify
            words = []
            for w in range(n_free_words):
                words.append((result >> (w * bits)) & mask)
            msg = words + fixed_W[n_free_words:]
            h = sha_func(msg, n_rounds)
            correct = h == target_hash

            if correct:
                best_degree = max_deg
                print(f"  ★ Solved at degree {max_deg}: {n_monos} monomials, rank {rank}")
                break
            else:
                print(f"    Degree {max_deg}: {n_monos} monomials, rank {rank} — wrong solution")
        else:
            print(f"    Degree {max_deg}: {n_monos} monomials, rank {rank} — no solution")

    if best_degree is None:
        print(f"  ✗ Could not solve at any degree")
        return None

    # Run trials
    successes = 0
    total_solve = 0.0

    for trial in range(n_trials):
        msg = [random.getrandbits(bits) & mask for _ in range(16)]
        target_hash = sha_func(msg, n_rounds)
        target_bits = []
        for word_idx in range(8):
            for bit_idx in range(bits):
                target_bits.append((target_hash[word_idx] >> bit_idx) & 1)

        # Rebuild ANF for this fixed_W (the non-free words change per trial)
        trial_anf = []
        for word_idx in range(8):
            for bit_idx in range(bits):
                tt = []
                for x in range(n_total):
                    words = []
                    for w in range(n_free_words):
                        words.append((x >> (w * bits)) & mask)
                    trial_msg = words + msg[n_free_words:]
                    h = sha_func(trial_msg, n_rounds)
                    tt.append((h[word_idx] >> bit_idx) & 1)
                trial_anf.append(compute_anf(tt, n_input))

        start_solve = time.time()
        result, _, _ = solve_at_degree(trial_anf, target_bits, n_input, best_degree, n_total)
        solve_time = time.time() - start_solve
        total_solve += solve_time

        if result is not None:
            words = []
            for w in range(n_free_words):
                words.append((result >> (w * bits)) & mask)
            trial_msg = words + msg[n_free_words:]
            if sha_func(trial_msg, n_rounds) == target_hash:
                successes += 1

    avg_solve = total_solve / n_trials
    print(f"  Verification: {successes}/{n_trials} correct at degree {best_degree}")
    print(f"  Avg solve time: {avg_solve:.4f}s")

    return best_degree


def main():
    print("═" * 72)
    print("  SHA-256 Polynomial Inversion — SCALING TEST")
    print("  Does degree-3 linearization hold at larger word sizes?")
    print("═" * 72)

    results = []

    # Scale 1: vary word size, 1 free word, 16 rounds
    print(f"\n{'═' * 72}")
    print(f"  SERIES A: 1 free word, 16 rounds, increasing word size")
    print(f"{'═' * 72}")

    for bits in [4, 5, 6, 7, 8]:
        deg = test_scale(bits, n_free_words=1, n_rounds=16, n_trials=10)
        results.append(('A', bits, 1, 16, deg))

    # Scale 2: vary word size, 2 free words, 16 rounds
    print(f"\n{'═' * 72}")
    print(f"  SERIES B: 2 free words, 16 rounds, increasing word size")
    print(f"{'═' * 72}")

    for bits in [4, 5, 6, 7, 8]:
        n_input = 2 * bits
        if (1 << n_input) > 2**20:
            print(f"\n  {bits}-bit words, 2 free = {n_input} bits — "
                  f"truth table 2^{n_input} too large, skipping")
            results.append(('B', bits, 2, 16, None))
            continue
        deg = test_scale(bits, n_free_words=2, n_rounds=16, n_trials=10)
        results.append(('B', bits, 2, 16, deg))

    # Scale 3: vary rounds, 4-bit, 2 free words
    print(f"\n{'═' * 72}")
    print(f"  SERIES C: 4-bit words, 2 free words, increasing rounds")
    print(f"{'═' * 72}")

    for n_rounds in [4, 8, 12, 16]:
        deg = test_scale(4, n_free_words=2, n_rounds=n_rounds, n_trials=10)
        results.append(('C', 4, 2, n_rounds, deg))

    # Scale 4: 1 free word, vary rounds at different word sizes
    print(f"\n{'═' * 72}")
    print(f"  SERIES D: 1 free word, 4 rounds, increasing word size")
    print(f"{'═' * 72}")

    for bits in [4, 5, 6, 7, 8, 9, 10]:
        n_input = bits
        if (1 << n_input) > 2**20:
            print(f"\n  {bits}-bit — truth table 2^{n_input} too large, skipping")
            results.append(('D', bits, 1, 4, None))
            continue
        deg = test_scale(bits, n_free_words=1, n_rounds=4, n_trials=10)
        results.append(('D', bits, 1, 4, deg))

    # Summary
    print(f"\n{'═' * 72}")
    print(f"  SUMMARY: Minimum Degree for Polynomial Inversion")
    print(f"{'═' * 72}")

    print(f"\n  {'Series':>6s} │ {'Bits':>4s} │ {'Free':>4s} │ {'Rounds':>6s} │ {'Degree':>6s} │ {'Monomials':>10s} │ Status")
    print(f"  {'─'*6}─┼─{'─'*4}─┼─{'─'*4}─┼─{'─'*6}─┼─{'─'*6}─┼─{'─'*10}─┼─{'─'*20}")

    for series, bits, free, rounds, deg in results:
        if deg is not None:
            n_input = free * bits
            from math import comb
            monos = sum(comb(n_input, d) for d in range(deg + 1))
            status = f"SOLVED ★" if deg <= n_input // 2 else "solved"
            print(f"  {series:>6s} │ {bits:>4d} │ {free:>4d} │ {rounds:>6d} │ {deg:>6d} │ {monos:>10d} │ {status}")
        else:
            print(f"  {series:>6s} │ {bits:>4d} │ {free:>4d} │ {rounds:>6d} │ {'—':>6s} │ {'—':>10s} │ skipped")

    # Extrapolation
    print(f"\n{'═' * 72}")
    print(f"  EXTRAPOLATION TO REAL SHA-256")
    print(f"{'═' * 72}")

    solved_results = [(b, d) for s, b, f, r, d in results if d is not None and s == 'A']
    if len(solved_results) >= 2:
        bits_list = [b for b, d in solved_results]
        deg_list = [d for b, d in solved_results]

        print(f"\n  Observed: word_size → min_degree")
        for b, d in solved_results:
            print(f"    {b}-bit → degree {d}")

        # Trend
        if len(set(deg_list)) == 1:
            print(f"\n  ★ DEGREE IS CONSTANT AT {deg_list[0]}!")
            print(f"    Does NOT grow with word size.")
            from math import comb
            d = deg_list[0]
            n_input_32 = 32  # 1 free word × 32 bits
            monos_32 = sum(comb(n_input_32, k) for k in range(d + 1))
            print(f"\n    For real SHA-256 (1 free 32-bit word):")
            print(f"      Input bits: {n_input_32}")
            print(f"      Degree: {d}")
            print(f"      Monomials: C({n_input_32},≤{d}) = {monos_32}")
            print(f"      Matrix size: {8*32} × {monos_32}")
            print(f"      Gaussian elimination: O({monos_32}³) ≈ {monos_32**3:.0e}")
            print(f"      {'FEASIBLE ★' if monos_32 < 10**8 else 'Large but structured'}")

            n_input_full = 512  # 16 free words × 32 bits
            monos_full = sum(comb(n_input_full, k) for k in range(d + 1))
            print(f"\n    For full SHA-256 (all 16 words free):")
            print(f"      Input bits: {n_input_full}")
            print(f"      Degree: {d}")
            print(f"      Monomials: C({n_input_full},≤{d}) ≈ {monos_full:.2e}")
            print(f"      {'FEASIBLE on supercomputer' if monos_full < 10**12 else 'Challenging'}")
        else:
            # Fit a trend
            print(f"\n  Degree increases with word size.")
            print(f"  Trend: {list(zip(bits_list, deg_list))}")


if __name__ == "__main__":
    main()
