#!/usr/bin/env python3
"""
SHA-256 Reverse Round Visualization — image output.
Shows the diagonal infection pattern when unwinding from both ends.
"""

import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.colors as mcolors
import numpy as np

def main():
    fig = plt.figure(figsize=(16, 22), facecolor='#0d1117')

    # ──────────────────────────────────────────────────────────
    # PANEL 1: Backward rollback heatmap (top)
    # ──────────────────────────────────────────────────────────
    ax1 = fig.add_axes([0.08, 0.58, 0.84, 0.38])
    ax1.set_facecolor('#0d1117')

    labels = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h']
    rounds_back = list(range(64, 53, -1))  # 64 down to 54
    n_rounds = len(rounds_back)

    # Build the grid: 1 = known, 0 = unknown, 0.5 = transition (just infected)
    grid = np.zeros((n_rounds, 8))

    for ri, r in enumerate(rounds_back):
        steps_back = 64 - r
        mask = [True] * 8

        if steps_back >= 1: mask[7] = False
        if steps_back >= 2: mask[6] = False
        if steps_back >= 3: mask[5] = False
        if steps_back >= 4: mask[4] = False
        if steps_back >= 5: mask[3] = False
        if steps_back >= 6: mask[2] = False
        if steps_back >= 7: mask[1] = False
        if steps_back >= 8: mask[0] = False

        for ci in range(8):
            grid[ri, ci] = 1.0 if mask[ci] else 0.0

    # Mark transition cells (just went from known to unknown)
    transition = np.zeros_like(grid)
    for ri in range(1, n_rounds):
        for ci in range(8):
            if grid[ri-1, ci] == 1.0 and grid[ri, ci] == 0.0:
                transition[ri, ci] = 1.0

    # Custom colormap
    cmap = mcolors.ListedColormap(['#da3633', '#238636'])  # red=unknown, green=known

    ax1.imshow(grid, cmap=cmap, aspect='auto', interpolation='nearest',
               extent=[-0.5, 7.5, n_rounds - 0.5, -0.5])

    # Draw transition markers (yellow borders for just-infected cells)
    for ri in range(n_rounds):
        for ci in range(8):
            if transition[ri, ci] == 1.0:
                rect = mpatches.FancyBboxPatch(
                    (ci - 0.45, ri - 0.45), 0.9, 0.9,
                    boxstyle="round,pad=0.05",
                    linewidth=2.5, edgecolor='#f0883e', facecolor='none'
                )
                ax1.add_patch(rect)

    # Grid lines
    for i in range(9):
        ax1.axvline(i - 0.5, color='#30363d', linewidth=0.5)
    for i in range(n_rounds + 1):
        ax1.axhline(i - 0.5, color='#30363d', linewidth=0.5)

    # Separator between d and e
    ax1.axvline(3.5, color='#8b949e', linewidth=2, linestyle='--')

    # Labels
    ax1.set_xticks(range(8))
    ax1.set_xticklabels(labels, fontsize=14, fontweight='bold', color='#e6edf3')
    ax1.set_yticks(range(n_rounds))
    ax1.set_yticklabels([str(r) for r in rounds_back], fontsize=12, color='#e6edf3')
    ax1.set_ylabel('Round', fontsize=14, color='#e6edf3', fontweight='bold')
    ax1.tick_params(colors='#e6edf3', top=True, labeltop=True, bottom=False, labelbottom=False)

    # Annotations on the right side
    annotations = {
        0: ('HASH OUTPUT — all known', '#58a6ff'),
        1: ('h = f(W₆₃)', '#e6edf3'),
        2: ('g ← h shifts in', '#e6edf3'),
        3: ('f ← g shifts in', '#e6edf3'),
        4: ('★ e → Σ1, Ch INFECTED', '#f0883e'),
        5: ('★ d = e-T1 infected', '#f0883e'),
        6: ('★ c → Maj INFECTED', '#f0883e'),
        7: ('b ← c shifts in', '#e6edf3'),
        8: ('ALL DARK', '#da3633'),
    }

    for ri, (text, color) in annotations.items():
        if ri < n_rounds:
            ax1.annotate(text, xy=(7.7, ri), fontsize=10, color=color,
                        va='center', fontweight='bold' if '★' in text or 'ALL' in text or 'HASH' in text else 'normal')

    # Title for panel 1
    ax1.set_title('SHA-256 Backward Rollback: Knowledge Infection Pattern',
                  fontsize=16, color='#e6edf3', fontweight='bold', pad=30)

    # Column group labels
    ax1.text(1.5, -1.4, 'Maj side', ha='center', fontsize=12, color='#8b949e', style='italic')
    ax1.text(5.5, -1.4, 'Ch side', ha='center', fontsize=12, color='#8b949e', style='italic')

    # ──────────────────────────────────────────────────────────
    # PANEL 2: Combined hourglass view (bottom)
    # ──────────────────────────────────────────────────────────
    ax2 = fig.add_axes([0.08, 0.08, 0.84, 0.44])
    ax2.set_facecolor('#0d1117')

    # Build full 65-row grid (round 0 to 64)
    full_grid = np.zeros((65, 8))

    for r in range(65):
        # Forward knowledge (from IV)
        fw = [True] * 8
        if r >= 1:
            fw[0] = False; fw[4] = False  # a, e
        if r >= 2:
            fw[1] = False; fw[5] = False  # b, f
        if r >= 3:
            fw[2] = False; fw[6] = False  # c, g
        if r >= 4:
            fw[3] = False; fw[7] = False  # d, h

        # Backward knowledge (from hash)
        bk = [True] * 8
        steps_back = 64 - r
        if steps_back >= 1: bk[7] = False
        if steps_back >= 2: bk[6] = False
        if steps_back >= 3: bk[5] = False
        if steps_back >= 4: bk[4] = False
        if steps_back >= 5: bk[3] = False
        if steps_back >= 6: bk[2] = False
        if steps_back >= 7: bk[1] = False
        if steps_back >= 8: bk[0] = False

        for ci in range(8):
            if fw[ci] or bk[ci]:
                full_grid[r, ci] = 1.0
            else:
                full_grid[r, ci] = 0.0

    ax2.imshow(full_grid, cmap=cmap, aspect='auto', interpolation='nearest',
               extent=[-0.5, 7.5, 64.5, -0.5])

    # Grid lines (sparse for readability)
    for i in range(9):
        ax2.axvline(i - 0.5, color='#30363d', linewidth=0.3)
    ax2.axvline(3.5, color='#8b949e', linewidth=1.5, linestyle='--')

    # Horizontal markers at key rounds
    for r in [0, 4, 56, 64]:
        ax2.axhline(r, color='#8b949e', linewidth=0.5, linestyle=':')

    # Labels
    ax2.set_xticks(range(8))
    ax2.set_xticklabels(labels, fontsize=14, fontweight='bold', color='#e6edf3')
    ax2.set_ylabel('Round', fontsize=14, color='#e6edf3', fontweight='bold')
    ax2.tick_params(colors='#e6edf3', top=True, labeltop=True, bottom=False, labelbottom=False)

    # Y-axis labels
    yticks = [0, 4, 8, 16, 32, 48, 56, 64]
    ax2.set_yticks(yticks)
    ax2.set_yticklabels([str(y) for y in yticks], fontsize=11, color='#e6edf3')

    # Bracket annotations
    ax2.annotate('IV\n(all known)', xy=(-1.8, 0), fontsize=11, color='#58a6ff',
                va='center', ha='center', fontweight='bold')
    ax2.annotate('Hash\n(all known)', xy=(-1.8, 64), fontsize=11, color='#58a6ff',
                va='center', ha='center', fontweight='bold')

    # Zone labels on the right
    ax2.annotate('← 4 rounds\n   forward\n   knowledge',
                xy=(8.3, 2), fontsize=10, color='#238636', va='center', fontweight='bold')

    ax2.annotate('48 ROUNDS\nOF DARKNESS\n\n512 bits of freedom\n256 bits of constraint\n= 256 bits net',
                xy=(8.3, 30), fontsize=11, color='#da3633', va='center',
                fontweight='bold', ha='left',
                bbox=dict(boxstyle='round,pad=0.5', facecolor='#1c1c1c', edgecolor='#da3633', alpha=0.9))

    ax2.annotate('← 8 rounds\n   backward\n   knowledge',
                xy=(8.3, 60), fontsize=10, color='#238636', va='center', fontweight='bold')

    ax2.set_title('Combined View: Knowledge from Both Ends',
                  fontsize=16, color='#e6edf3', fontweight='bold', pad=30)

    # ──────────────────────────────────────────────────────────
    # Legend
    # ──────────────────────────────────────────────────────────
    legend_elements = [
        mpatches.Patch(facecolor='#238636', label='Known (deterministic from hash or IV)'),
        mpatches.Patch(facecolor='#da3633', label='Unknown (depends on message words W₀…W₁₅)'),
        mpatches.Patch(facecolor='none', edgecolor='#f0883e', linewidth=2,
                      label='Transition (just infected — nonlinear wall)'),
    ]
    ax2.legend(handles=legend_elements, loc='lower center',
              bbox_to_anchor=(0.4, -0.08), ncol=3, fontsize=10,
              facecolor='#161b22', edgecolor='#30363d', labelcolor='#e6edf3')

    # ──────────────────────────────────────────────────────────
    # Save
    # ──────────────────────────────────────────────────────────
    out = 'sha256_reverse_rollback.png'
    plt.savefig(out, dpi=150, bbox_inches='tight', facecolor='#0d1117')
    plt.close()
    print(f"Saved: {out}")

if __name__ == "__main__":
    main()
