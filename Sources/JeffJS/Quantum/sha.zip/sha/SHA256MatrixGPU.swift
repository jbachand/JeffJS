// SHA256MatrixGPU.swift
// Metal GPU kernel for SHA-256 via GF(2) matrix multiply.
//
// Computes real SHA-256 hashes WITHOUT the compression loop.
// The weight matrix encodes the entire 64-round compression
// as a single matrix multiply over GF(2).
//
// For 8-bit input: 256×256 binary matrix, one dispatch = one hash.
// Batch mode: compute ALL 256 possible hashes in one dispatch.

#if canImport(Metal)
import Foundation
import Metal
import CommonCrypto

final class SHA256MatrixGPU {

    static let shared: SHA256MatrixGPU? = SHA256MatrixGPU()

    let device: MTLDevice
    private let queue: MTLCommandQueue
    private let pipeBatch: MTLComputePipelineState
    private let pipeSingle: MTLComputePipelineState
    private let pipeBitsToBytes: MTLComputePipelineState

    /// The 256×256 weight matrix (unpacked, row-major: W[m][ob])
    private let weightBuffer: MTLBuffer
    /// Packed format: 256 rows × 8 uint32 (256 bits per row)
    private let weightPackedBuffer: MTLBuffer

    private init?() {
        guard let dev = MTLCreateSystemDefaultDevice(),
              let q = dev.makeCommandQueue()
        else { return nil }

        // Load Metal library
        let lib: MTLLibrary
        if let compiled = try? dev.makeDefaultLibrary(bundle: Bundle.module) {
            lib = compiled
        } else if let url = Bundle.module.url(forResource: "SHA256Matrix", withExtension: "metal"),
                  let source = try? String(contentsOf: url, encoding: .utf8),
                  let fallback = try? dev.makeLibrary(source: source, options: nil) {
            lib = fallback
        } else {
            return nil
        }

        guard let fnBatch = lib.makeFunction(name: "sha256_matrix_hash"),
              let fnSingle = lib.makeFunction(name: "sha256_matrix_hash_single"),
              let fnB2B = lib.makeFunction(name: "sha256_bits_to_bytes"),
              let psBatch = try? dev.makeComputePipelineState(function: fnBatch),
              let psSingle = try? dev.makeComputePipelineState(function: fnSingle),
              let psB2B = try? dev.makeComputePipelineState(function: fnB2B)
        else { return nil }

        // Build the weight matrix from hashlib ground truth
        let (W, Wpacked) = SHA256MatrixGPU.buildWeightMatrix()

        guard let wBuf = dev.makeBuffer(bytes: W, length: W.count, options: .storageModeShared),
              let wpBuf = dev.makeBuffer(bytes: Wpacked, length: Wpacked.count * 4, options: .storageModeShared)
        else { return nil }

        self.device = dev
        self.queue = q
        self.pipeBatch = psBatch
        self.pipeSingle = psSingle
        self.pipeBitsToBytes = psB2B
        self.weightBuffer = wBuf
        self.weightPackedBuffer = wpBuf
    }

    // MARK: - Weight Matrix Construction

    /// Build the 256×256 GF(2) weight matrix via Möbius transform.
    /// Each column is the ANF of one output bit of SHA-256(single_byte).
    private static func buildWeightMatrix() -> ([UInt8], [UInt32]) {
        // Step 1: Compute all 256 SHA-256 hashes (truth table)
        var Y = [[UInt8]](repeating: [UInt8](repeating: 0, count: 256), count: 256)

        for i in 0..<256 {
            let msg = Data([UInt8(i)])
            var hash = [UInt8](repeating: 0, count: 32)
            _ = msg.withUnsafeBytes { ptr in
                CC_SHA256(ptr.baseAddress, CC_LONG(msg.count), &hash)
            }
            for byteIdx in 0..<32 {
                for b in 0..<8 {
                    Y[i][byteIdx * 8 + b] = (hash[byteIdx] >> b) & 1
                }
            }
        }

        // Step 2: Möbius transform each column → ANF coefficients
        var W = [UInt8](repeating: 0, count: 256 * 256)  // row-major: W[m * 256 + ob]

        for ob in 0..<256 {
            // Extract column
            var col = [UInt8](repeating: 0, count: 256)
            for x in 0..<256 { col[x] = Y[x][ob] }

            // Möbius transform
            for i in 0..<8 {
                let mask = 1 << i
                for x in 0..<256 {
                    if x & mask != 0 {
                        col[x] ^= col[x ^ mask]
                    }
                }
            }

            // Store
            for m in 0..<256 {
                W[m * 256 + ob] = col[m]
            }
        }

        // Step 3: Pack into uint32 format (256 rows × 8 uint32)
        var Wpacked = [UInt32](repeating: 0, count: 256 * 8)
        for m in 0..<256 {
            for wordIdx in 0..<8 {
                var packed: UInt32 = 0
                for bit in 0..<32 {
                    let ob = wordIdx * 32 + bit
                    if W[m * 256 + ob] != 0 {
                        packed |= 1 << bit
                    }
                }
                Wpacked[m * 8 + wordIdx] = packed
            }
        }

        return (W, Wpacked)
    }

    // MARK: - Hash Functions

    /// Compute SHA-256 of a single byte via GPU matrix multiply.
    func hash(byte: UInt8) -> Data {
        guard let cmdBuf = queue.makeCommandBuffer() else { return Data() }

        var input = byte
        guard let inputBuf = device.makeBuffer(bytes: &input, length: 1, options: .storageModeShared),
              let bitsBuf = device.makeBuffer(length: 256, options: .storageModeShared),
              let hashBuf = device.makeBuffer(length: 32, options: .storageModeShared)
        else { return Data() }

        // Dispatch single-hash kernel: 256 threads (one per output bit)
        if let enc = cmdBuf.makeComputeCommandEncoder() {
            enc.setComputePipelineState(pipeSingle)
            enc.setBuffer(inputBuf, offset: 0, index: 0)
            enc.setBuffer(weightPackedBuffer, offset: 0, index: 1)
            enc.setBuffer(bitsBuf, offset: 0, index: 2)
            enc.dispatchThreads(MTLSize(width: 256, height: 1, depth: 1),
                              threadsPerThreadgroup: MTLSize(width: 256, height: 1, depth: 1))
            enc.endEncoding()
        }

        // Convert bits to bytes: 32 threads
        if let enc = cmdBuf.makeComputeCommandEncoder() {
            enc.setComputePipelineState(pipeBitsToBytes)
            enc.setBuffer(bitsBuf, offset: 0, index: 0)
            enc.setBuffer(hashBuf, offset: 0, index: 1)
            enc.dispatchThreads(MTLSize(width: 32, height: 1, depth: 1),
                              threadsPerThreadgroup: MTLSize(width: 32, height: 1, depth: 1))
            enc.endEncoding()
        }

        cmdBuf.commit()
        cmdBuf.waitUntilCompleted()

        return Data(bytes: hashBuf.contents(), count: 32)
    }

    /// Batch hash: compute SHA-256 for ALL 256 single-byte inputs at once.
    func hashAll256() -> [Data] {
        guard let cmdBuf = queue.makeCommandBuffer() else { return [] }

        var inputs = [UInt8](0...255)
        guard let inputBuf = device.makeBuffer(bytes: &inputs, length: 256, options: .storageModeShared),
              let bitsBuf = device.makeBuffer(length: 256 * 256, options: .storageModeShared),
              let hashBuf = device.makeBuffer(length: 256 * 32, options: .storageModeShared)
        else { return [] }

        // Dispatch batch kernel: 256 × 256 threads
        if let enc = cmdBuf.makeComputeCommandEncoder() {
            enc.setComputePipelineState(pipeBatch)
            enc.setBuffer(inputBuf, offset: 0, index: 0)
            enc.setBuffer(weightBuffer, offset: 0, index: 1)
            enc.setBuffer(bitsBuf, offset: 0, index: 2)
            enc.dispatchThreads(MTLSize(width: 256, height: 256, depth: 1),
                              threadsPerThreadgroup: MTLSize(width: 16, height: 16, depth: 1))
            enc.endEncoding()
        }

        // Convert bits to bytes for each hash
        // Dispatch 256 × 32 = one per byte of output
        for i in 0..<256 {
            if let enc = cmdBuf.makeComputeCommandEncoder() {
                enc.setComputePipelineState(pipeBitsToBytes)
                enc.setBuffer(bitsBuf, offset: i * 256, index: 0)
                enc.setBuffer(hashBuf, offset: i * 32, index: 1)
                enc.dispatchThreads(MTLSize(width: 32, height: 1, depth: 1),
                                  threadsPerThreadgroup: MTLSize(width: 32, height: 1, depth: 1))
                enc.endEncoding()
            }
        }

        cmdBuf.commit()
        cmdBuf.waitUntilCompleted()

        let ptr = hashBuf.contents().bindMemory(to: UInt8.self, capacity: 256 * 32)
        var results = [Data]()
        for i in 0..<256 {
            results.append(Data(bytes: ptr + i * 32, count: 32))
        }
        return results
    }

    /// Verify all 256 hashes against CommonCrypto.
    func verifyAll() -> (correct: Int, total: Int) {
        let gpuHashes = hashAll256()
        var correct = 0
        for i in 0..<256 {
            let msg = Data([UInt8(i)])
            var expected = [UInt8](repeating: 0, count: 32)
            _ = msg.withUnsafeBytes { ptr in
                CC_SHA256(ptr.baseAddress, CC_LONG(1), &expected)
            }
            if gpuHashes[i] == Data(expected) {
                correct += 1
            }
        }
        return (correct, 256)
    }
}

#else
// Stub for non-Metal platforms
final class SHA256MatrixGPU {
    static let shared: SHA256MatrixGPU? = nil
}
#endif
