// SHA256MatrixTest.swift
// Quick test: run from command line or call from JS.

#if canImport(Metal)
import Foundation
import CommonCrypto

enum SHA256MatrixTest {

    static func run() {
        print("=== SHA256 Matrix GPU Test ===")

        guard let gpu = SHA256MatrixGPU.shared else {
            print("Metal not available")
            return
        }
        print("Metal device: \(gpu.device.name)")

        // --- Single hash test ---
        let testByte: UInt8 = 65  // 'A'
        let gpuHash = gpu.hash(byte: testByte)
        var expected = [UInt8](repeating: 0, count: 32)
        let msg = Data([testByte])
        _ = msg.withUnsafeBytes { ptr in
            CC_SHA256(ptr.baseAddress, CC_LONG(1), &expected)
        }

        let gpuHex = gpuHash.map { String(format: "%02x", $0) }.joined()
        let expHex = expected.map { String(format: "%02x", $0) }.joined()

        print("\nSingle hash SHA-256('A'):")
        print("  GPU:      \(gpuHex)")
        print("  Expected: \(expHex)")
        print("  Match: \(gpuHex == expHex)")

        // --- Verify all 256 ---
        let start = CFAbsoluteTimeGetCurrent()
        let (correct, total) = gpu.verifyAll()
        let elapsed = CFAbsoluteTimeGetCurrent() - start

        print("\nAll 256 single-byte hashes:")
        print("  Correct: \(correct)/\(total)")
        print("  Time: \(String(format: "%.2f", elapsed * 1000))ms")

        if correct == total {
            print("\n*** ALL 256 REAL SHA-256 HASHES COMPUTED ON GPU ***")
            print("*** Via GF(2) matrix multiply — no compression loop ***")
        }

        // --- Benchmark: GPU batch vs CommonCrypto ---
        let iterations = 1000
        let batchStart = CFAbsoluteTimeGetCurrent()
        for _ in 0..<iterations {
            _ = gpu.hashAll256()
        }
        let batchTime = CFAbsoluteTimeGetCurrent() - batchStart

        let ccStart = CFAbsoluteTimeGetCurrent()
        for _ in 0..<iterations {
            for i in 0..<256 {
                var h = [UInt8](repeating: 0, count: 32)
                let m = Data([UInt8(i)])
                _ = m.withUnsafeBytes { CC_SHA256($0.baseAddress, CC_LONG(1), &h) }
            }
        }
        let ccTime = CFAbsoluteTimeGetCurrent() - ccStart

        let totalHashes = iterations * 256
        print("\nBenchmark (\(totalHashes) hashes):")
        print("  GPU matrix:   \(String(format: "%.1f", batchTime * 1000))ms (\(Int(Double(totalHashes) / batchTime))/sec)")
        print("  CommonCrypto: \(String(format: "%.1f", ccTime * 1000))ms (\(Int(Double(totalHashes) / ccTime))/sec)")
        print("  Ratio: \(String(format: "%.2f", ccTime / batchTime))x")
    }
}
#endif
