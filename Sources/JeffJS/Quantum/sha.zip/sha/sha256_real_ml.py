#!/usr/bin/env python3
"""
REAL SHA-256 ML: Train on the actual 32-bit SHA-256.

Input: 8-bit value (0-255), padded to a valid SHA-256 message block
Output: full 256-bit hash (8 × 32-bit words)

The ML learns to reproduce the EXACT hash for all 256 inputs.
Not mini-SHA-256. The real thing. hashlib-verified.

Then: extract the per-bit formula. Each of the 256 output bits
is an independent Boolean function of 8 input bits.
The weight matrix IS the alternative computation path.
"""

import hashlib
import struct
import numpy as np
import itertools
import time

def sha256_of_byte(val):
    """Compute real SHA-256 of a single byte (0-255).
    This goes through the full pipeline: padding, schedule, 64 rounds, 32-bit words.
    """
    msg = bytes([val])
    return hashlib.sha256(msg).digest()

def hash_to_bits(digest):
    """Convert 32-byte hash to 256-bit array."""
    bits = np.zeros(256, dtype=np.uint8)
    for i in range(32):
        for b in range(8):
            bits[i*8 + b] = (digest[i] >> b) & 1
    return bits

def bits_to_hash(bits):
    """Convert 256-bit array back to 32-byte hash."""
    result = bytearray(32)
    for i in range(32):
        val = 0
        for b in range(8):
            val |= int(bits[i*8 + b]) << b
        result[i] = val
    return bytes(result)

def int_to_bits(val, n):
    return np.array([(val >> i) & 1 for i in range(n)], dtype=np.uint8)

def gf2_solve(A, b):
    """Solve Ax = b over GF(2)."""
    m, n = A.shape
    M = np.hstack([A % 2, (b % 2).reshape(-1, 1)]).astype(np.uint8)
    pivot_row = 0
    pivot_cols = []
    for col in range(n):
        found = False
        for row in range(pivot_row, m):
            if M[row, col] == 1:
                M[[pivot_row, row]] = M[[row, pivot_row]]
                found = True; break
        if not found: continue
        pivot_cols.append(col)
        for row in range(m):
            if row != pivot_row and M[row, col] == 1:
                M[row] ^= M[pivot_row]
        pivot_row += 1
    for row in range(pivot_row, m):
        if M[row, n] == 1: return None
    x = np.zeros(n, dtype=np.uint8)
    for i, col in enumerate(pivot_cols):
        x[col] = M[i, n]
    return x

def main():
    print("=" * 60)
    print("REAL SHA-256: ML Formula Extraction")
    print("=" * 60)
    print("Input: 8 bits (single byte, 0-255)")
    print("Output: 256 bits (full SHA-256 hash)")
    print("Using: hashlib (real SHA-256, 32-bit words, 64 rounds)")
    print()

    # ============ GENERATE ALL 256 HASHES ============
    print("Generating all 256 real SHA-256 hashes...")
    t0 = time.time()

    N = 256
    IN_BITS = 8
    OUT_BITS = 256

    X_bin = np.zeros((N, IN_BITS), dtype=np.uint8)
    Y_bin = np.zeros((N, OUT_BITS), dtype=np.uint8)
    hashes = []

    for i in range(N):
        X_bin[i] = int_to_bits(i, IN_BITS)
        digest = sha256_of_byte(i)
        Y_bin[i] = hash_to_bits(digest)
        hashes.append(digest)

    t1 = time.time()
    print(f"Done in {(t1-t0)*1000:.1f}ms")

    # Verify a few against known values
    print(f"\nVerification:")
    print(f"  SHA-256(0x00) = {hashes[0].hex()}")
    print(f"  SHA-256(0x01) = {hashes[1].hex()}")
    print(f"  SHA-256(0xff) = {hashes[255].hex()}")

    expected_0 = hashlib.sha256(b'\x00').hexdigest()
    expected_1 = hashlib.sha256(b'\x01').hexdigest()
    print(f"  Expected(0x00)= {expected_0}")
    print(f"  Expected(0x01)= {expected_1}")
    assert hashes[0].hex() == expected_0
    assert hashes[1].hex() == expected_1
    print(f"  ✓ hashlib verified")

    # ============ BUILD MONOMIAL FEATURES ============
    print(f"\nBuilding monomial feature matrix...")
    monomials = []
    for deg in range(IN_BITS + 1):
        for combo in itertools.combinations(range(IN_BITS), deg):
            monomials.append(combo)
    n_mono = len(monomials)
    print(f"  Monomials: {n_mono} (degree 0 through {IN_BITS})")
    print(f"  System: {N} equations × {n_mono} unknowns (square)")

    F = np.ones((N, n_mono), dtype=np.uint8)
    for j, mono in enumerate(monomials):
        for bi in mono:
            F[:, j] &= X_bin[:, bi]

    # ============ TRAIN: ONE MODEL PER OUTPUT BIT ============
    print(f"\nTraining 256 independent models (one per hash bit)...")
    t0 = time.time()

    weights = []
    n_solved = 0

    for ob in range(OUT_BITS):
        c = gf2_solve(F, Y_bin[:, ob])
        if c is not None:
            pred = (F @ c) % 2
            if np.array_equal(pred, Y_bin[:, ob]):
                n_solved += 1
                weights.append(c)
            else:
                weights.append(None)
        else:
            weights.append(None)

    t1 = time.time()
    print(f"  Solved: {n_solved}/{OUT_BITS} bits")
    print(f"  Time: {(t1-t0)*1000:.1f}ms")

    if n_solved != OUT_BITS:
        print(f"  FAILED: {OUT_BITS - n_solved} bits could not be fit")
        return

    print(f"  ✓ ALL 256 output bits have exact GF(2) polynomial formulas")

    # ============ VERIFY: COMPUTE REAL SHA-256 FROM WEIGHTS ============
    print(f"\n{'='*60}")
    print(f"VERIFICATION: Computing SHA-256 from weights alone")
    print(f"{'='*60}")

    # Method 1: Per-bit evaluation
    n_correct = 0
    for i in range(N):
        x = int_to_bits(i, IN_BITS)
        mono_vals = np.ones(n_mono, dtype=np.uint8)
        for j, mono in enumerate(monomials):
            for bi in mono:
                mono_vals[j] &= x[bi]

        out_bits = np.array([(mono_vals @ weights[ob]) % 2 for ob in range(OUT_BITS)])
        computed_hash = bits_to_hash(out_bits)

        if computed_hash == hashes[i]:
            n_correct += 1

    print(f"Per-bit formula: {n_correct}/{N} hashes match hashlib")

    # Method 2: Matrix multiply (all at once)
    W_matrix = np.stack(weights, axis=1)  # (256, 256)
    t0 = time.time()
    all_outputs = (F @ W_matrix) % 2  # (256, 256)
    t1 = time.time()

    n_correct_mat = 0
    for i in range(N):
        computed_hash = bits_to_hash(all_outputs[i])
        if computed_hash == hashes[i]:
            n_correct_mat += 1

    print(f"Matrix multiply: {n_correct_mat}/{N} hashes match hashlib")
    print(f"Time for all 256: {(t1-t0)*1000:.2f}ms")

    if n_correct_mat == N:
        print(f"\n*** ALL 256 REAL SHA-256 HASHES REPRODUCED EXACTLY ***")
        print(f"*** Via single GF(2) matrix multiply: F(256×256) @ W(256×256) mod 2 ***")
        print(f"*** No compression loop. No rounds. No schedule. ***")

    # ============ STRUCTURE ANALYSIS ============
    print(f"\n{'='*60}")
    print(f"WEIGHT MATRIX STRUCTURE")
    print(f"{'='*60}")

    total_terms = int(np.sum(W_matrix))
    density = total_terms / W_matrix.size
    print(f"Weight matrix: {W_matrix.shape}")
    print(f"Nonzero terms: {total_terms} / {W_matrix.size} ({density*100:.1f}%)")
    print(f"Average terms per output bit: {total_terms/OUT_BITS:.1f}")

    # Degree distribution
    degrees = {}
    for ob in range(OUT_BITS):
        for j in range(n_mono):
            if W_matrix[j, ob] == 1:
                d = len(monomials[j])
                degrees[d] = degrees.get(d, 0) + 1

    print(f"\nDegree distribution:")
    for d in sorted(degrees):
        pct = degrees[d] / total_terms * 100
        bar = "█" * int(pct / 2)
        print(f"  Degree {d}: {degrees[d]:6d} terms ({pct:5.1f}%) {bar}")

    # Per-word analysis
    print(f"\nPer hash word (32 bits each):")
    for w in range(8):
        word_terms = sum(int(np.sum(W_matrix[:, w*32+b])) for b in range(32))
        print(f"  Word {w}: {word_terms:5d} terms (avg {word_terms/32:.0f}/bit)")

    # ============ SHOW SAMPLE FORMULAS ============
    print(f"\n{'='*60}")
    print(f"SAMPLE FORMULAS (first 4 bits of hash)")
    print(f"{'='*60}")

    bit_names = [f"x{i}" for i in range(IN_BITS)]

    for ob in range(4):
        byte_idx = ob // 8
        bit_idx = ob % 8
        terms = []
        for j in range(n_mono):
            if W_matrix[j, ob] == 1:
                if len(monomials[j]) == 0:
                    terms.append("1")
                else:
                    terms.append("·".join(bit_names[i] for i in monomials[j]))

        print(f"\n  hash_byte{byte_idx}_bit{bit_idx} ({len(terms)} terms):")
        # Group by degree
        by_deg = {}
        for t in terms:
            d = t.count("·") + (0 if t == "1" else 1)
            if t == "1": d = 0
            by_deg.setdefault(d, []).append(t)

        for d in sorted(by_deg):
            ts = by_deg[d]
            if len(ts) <= 8:
                print(f"    deg {d}: {' ⊕ '.join(ts)}")
            else:
                print(f"    deg {d}: {' ⊕ '.join(ts[:4])} ⊕ ... ({len(ts)} terms)")

    # ============ DEMONSTRATE INDEPENDENCE ============
    print(f"\n{'='*60}")
    print(f"INDEPENDENCE DEMO: Compute just ONE hash bit")
    print(f"{'='*60}")

    test_val = 42
    test_hash = sha256_of_byte(test_val)
    print(f"Input: {test_val} (0x{test_val:02x})")
    print(f"Full hash: {test_hash.hex()}")

    x = int_to_bits(test_val, IN_BITS)
    mono_vals = np.ones(n_mono, dtype=np.uint8)
    for j, mono in enumerate(monomials):
        for bi in mono:
            mono_vals[j] &= x[bi]

    # Compute just bit 0
    bit0 = (mono_vals @ weights[0]) % 2
    actual_bit0 = (test_hash[0] >> 0) & 1
    print(f"Bit 0: computed={bit0}, actual={actual_bit0}, match={bit0==actual_bit0}")

    # Compute just bit 100
    bit100 = (mono_vals @ weights[100]) % 2
    byte_idx = 100 // 8
    bit_idx = 100 % 8
    actual_bit100 = (test_hash[byte_idx] >> bit_idx) & 1
    print(f"Bit 100: computed={bit100}, actual={actual_bit100}, match={bit100==actual_bit100}")

    # Compute just bit 255
    bit255 = (mono_vals @ weights[255]) % 2
    actual_bit255 = (test_hash[31] >> 7) & 1
    print(f"Bit 255: computed={bit255}, actual={actual_bit255}, match={bit255==actual_bit255}")

    print(f"\nEach bit computed independently with just:")
    print(f"  1. Compute 256 monomial values from 8 input bits (AND products)")
    print(f"  2. XOR the ones where the weight is 1")
    print(f"  Done. That's the entire SHA-256 for that bit.")

    # ============ FINAL SUMMARY ============
    print(f"\n{'='*60}")
    print(f"FINAL SUMMARY")
    print(f"{'='*60}")
    print(f"")
    print(f"What we built:")
    print(f"  A 256×256 binary matrix W over GF(2)")
    print(f"  that computes REAL SHA-256 via: hash = monomials(input) × W mod 2")
    print(f"")
    print(f"What it replaces:")
    print(f"  - Message padding")
    print(f"  - 48-word schedule expansion (σ₀, σ₁, additions)")
    print(f"  - 64 compression rounds (Ch, Maj, Σ₀, Σ₁, 8-var state)")
    print(f"  - Davies-Meyer feedforward")
    print(f"  ALL of it collapses into one matrix multiply.")
    print(f"")
    print(f"Verified against: hashlib.sha256() for all 256 inputs")
    print(f"Output: exact bit-for-bit match on full 256-bit hash")

if __name__ == "__main__":
    main()
