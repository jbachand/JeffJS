#!/usr/bin/env python3
"""
SHA-256 8-Bit Cascade Attack — The Full Attack

Multi-round Ch reveal leaves exactly 8 hidden bits per h value.
8 hidden bits = 256 monomials = 256 output equations = square system.
Square system solves uniquely via Gaussian elimination (proven 20/20).

Attack:
  For each backward round (63 down to 48):
    1. Determine which bits of h are revealed by Ch at rounds t-1 and t-2
    2. Build truth table for the 8 hidden bits (256 SHA-256 evals)
    3. Solve 256×256 system via Gaussian elimination
    4. Extract h, compute W
  Schedule inversion: W[48..63] → W[0..15]
  Verify: full SHA-256 forward from IV
"""

import numpy as np
import random
import time

M32 = 0xFFFFFFFF
K = [0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
     0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
     0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
     0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
     0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
     0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
     0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
     0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2]
IV = [0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,
      0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19]

def rotr32(x, n):
    return ((x >> n) | (x << (32 - n))) & M32

def sha256_compress(W16):
    W = list(W16)
    for t in range(16, 64):
        s0 = rotr32(W[t-15],7) ^ rotr32(W[t-15],18) ^ (W[t-15]>>3)
        s1 = rotr32(W[t-2],17) ^ rotr32(W[t-2],19) ^ (W[t-2]>>10)
        W.append((W[t-16]+s0+W[t-7]+s1) & M32)
    a,b,c,d,e,f,g,h = IV
    for t in range(64):
        S1 = rotr32(e,6)^rotr32(e,11)^rotr32(e,25)
        ch = (e&f)^((e^M32)&g)
        T1 = (h+S1+ch+K[t]+W[t]) & M32
        S0 = rotr32(a,2)^rotr32(a,13)^rotr32(a,22)
        maj = (a&b)^(a&c)^(b&c)
        T2 = (S0+maj) & M32
        h=g; g=f; f=e; e=(d+T1)&M32; d=c; c=b; b=a; a=(T1+T2)&M32
    return [(IV[i]+v)&M32 for i,v in enumerate([a,b,c,d,e,f,g,h])]

def sha256_with_states(W16):
    """Returns hash AND all intermediate states."""
    W = list(W16)
    for t in range(16, 64):
        s0 = rotr32(W[t-15],7) ^ rotr32(W[t-15],18) ^ (W[t-15]>>3)
        s1 = rotr32(W[t-2],17) ^ rotr32(W[t-2],19) ^ (W[t-2]>>10)
        W.append((W[t-16]+s0+W[t-7]+s1) & M32)
    a,b,c,d,e,f,g,h = IV
    states = [(a,b,c,d,e,f,g,h)]
    for t in range(64):
        S1 = rotr32(e,6)^rotr32(e,11)^rotr32(e,25)
        ch = (e&f)^((e^M32)&g)
        T1 = (h+S1+ch+K[t]+W[t]) & M32
        S0 = rotr32(a,2)^rotr32(a,13)^rotr32(a,22)
        maj = (a&b)^(a&c)^(b&c)
        T2 = (S0+maj) & M32
        h=g; g=f; f=e; e=(d+T1)&M32; d=c; c=b; b=a; a=(T1+T2)&M32
        states.append((a,b,c,d,e,f,g,h))
    hash_out = [(IV[i]+v)&M32 for i,v in enumerate([a,b,c,d,e,f,g,h])]
    return hash_out, states, W

def mobius(tt, nv):
    n = 1 << nv; a = list(tt)
    for i in range(nv):
        s = 1 << i
        for j in range(n):
            if j & s: a[j] ^= a[j ^ s]
    return a

def gf2_solve(A, b):
    m, n = A.shape
    Ab = np.hstack([A.copy(), b.reshape(-1,1)]).astype(np.uint8)
    pivots = []
    for col in range(n):
        piv = None
        for row in range(len(pivots), m):
            if Ab[row, col]: piv = row; break
        if piv is None: continue
        tr = len(pivots)
        if piv != tr: Ab[[tr, piv]] = Ab[[piv, tr]]
        for row in range(m):
            if row != tr and Ab[row, col]: Ab[row] ^= Ab[tr]
        pivots.append((tr, col))
    for row in range(len(pivots), m):
        if Ab[row, -1]: return None
    x = np.zeros(n, dtype=np.uint8)
    for r, c in pivots: x[c] = Ab[r, -1]
    return x

def get_ch_reveal_masks(states, t):
    """
    Determine which bits of h[t] are revealed by Ch at rounds t-1 and t-2.
    h[t] appears as g at round t-1 (revealed where e_{t-1}=0)
    h[t] appears as f at round t-2 (revealed where e_{t-2}=1)
    Returns (revealed_mask, hidden_mask, hidden_bit_positions)
    """
    if t-1 >= 0 and t-1 < len(states):
        e_g_round = states[t-1][4]  # e at round t-1
    else:
        e_g_round = M32  # all hidden

    if t-2 >= 0 and t-2 < len(states):
        e_f_round = states[t-2][4]  # e at round t-2
    else:
        e_f_round = 0  # no reveal from f position

    # Revealed as g: where e_{t-1} = 0
    reveal_g = e_g_round ^ M32
    # Revealed as f: where e_{t-2} = 1
    reveal_f = e_f_round
    # Combined reveal
    revealed = reveal_g | reveal_f
    hidden = revealed ^ M32

    hidden_positions = [b for b in range(32) if (hidden >> b) & 1]
    return revealed & M32, hidden & M32, hidden_positions

def build_h_from_known_and_candidate(revealed_mask, hidden_positions, known_h_bits, candidate):
    """Reconstruct full 32-bit h from known (revealed) bits and candidate hidden bits."""
    h = known_h_bits & revealed_mask
    for idx, pos in enumerate(hidden_positions):
        if (candidate >> idx) & 1:
            h |= (1 << pos)
    return h

def backward_round(state_after, t):
    """Compute backward round. Returns known state values and T1."""
    a1,b1,c1,d1,e1,f1,g1,h1 = state_after
    a0 = b1; b0 = c1; c0 = d1
    e0 = f1; f0 = g1; g0 = h1
    S0 = rotr32(a0,2)^rotr32(a0,13)^rotr32(a0,22)
    maj = (a0&b0)^(a0&c0)^(b0&c0)
    T2 = (S0 + maj) & M32
    T1 = (a1 - T2) & M32
    d0 = (e1 - T1) & M32
    return (a0,b0,c0,d0,e0,f0,g0), T1, T2

def schedule_inverse(W48_63):
    """Given W[48]...W[63], recover W[0]...W[15] via schedule inversion."""
    W = [None]*64
    for i, t in enumerate(range(48, 64)):
        W[t] = W48_63[i]

    # Invert: W[t-16] = W[t] - sigma1(W[t-2]) - W[t-7] - sigma0(W[t-15])
    for t in range(63, 15, -1):
        if W[t] is not None and W[t-2] is not None and W[t-7] is not None and W[t-15] is not None:
            s0 = rotr32(W[t-15],7) ^ rotr32(W[t-15],18) ^ (W[t-15]>>3)
            s1 = rotr32(W[t-2],17) ^ rotr32(W[t-2],19) ^ (W[t-2]>>10)
            W[t-16] = (W[t] - s1 - W[t-7] - s0) & M32

    return W[:16]

def attempt_cascade_attack(target_hash, msg_for_verify=None):
    """
    Given ONLY the hash, attempt to recover the message.
    Uses multi-round Ch reveal + polynomial inversion at each step.
    """
    # Final state from hash
    final_state = tuple((target_hash[i] - IV[i]) & M32 for i in range(8))

    # We need the FORWARD states to know e values for Ch reveal.
    # But we don't have the message! The e values come from the RIGHT side
    # of the state, which propagates from the hash backward.
    #
    # Going backward: e at round t = f at round t+1 = g at round t+2 = h at round t+3
    # For the LAST few rounds, these are known from the hash.
    #
    # At round 63: e63 = f64 = states[64][5] — but states[64] = final_state
    #   e63 = final_state[5] = (hash[5] - IV[5]) & M32  ← KNOWN from hash
    #
    # At round 62: e62 = f63 = g64 = final_state[6] ← KNOWN from hash
    # At round 61: e61 = f62 = g63 = h64 = final_state[7] ← KNOWN from hash
    #
    # At round 60: e60 = f61 = g62 = h63 ← THIS IS h[63], which we're SOLVING FOR
    #
    # So for h[63]: the e values at rounds 62 and 61 are KNOWN from hash.
    # Ch reveal for h[63] uses e62 and e61, both from hash. GOOD.
    #
    # For h[62]: e values at rounds 61 and 60.
    #   e61 = known from hash. e60 = h63 (which we just solved). GOOD.
    #
    # For h[61]: e values at rounds 60 and 59.
    #   e60 = h63 (solved). e59 = h62 (solved). GOOD.
    #
    # Each step uses e values from previously solved h values. The cascade works!

    state = list(final_state)
    recovered_h = {}
    recovered_W = {}

    # Track the backward state propagation for e values
    # e at round t (going backward) = f at round t+1
    # But f at round t+1 was set during the backward computation

    # The e values we need: the e at the start of round t-1 and t-2
    # These come from the shift register: e = f_next, f = g_next, g = h_next

    # Build a record of e values as we go backward
    e_values = {}
    # From the final state, e at round 64 doesn't exist, but:
    # e63 = final_state[4] (e component of state after round 63)
    # Wait, states[t] is state at START of round t.
    # state after round 63 = final_state = (a64, b64, c64, d64, e64, f64, g64, h64)
    # e at START of round 63: e63 = f64 = final_state[5]... no.
    #
    # Let me use the backward shift register directly.
    # State after round 63 (= state at position 64): final_state
    # Going backward to state at position 63:
    #   a63=b64, b63=c64, c63=d64, e63=f64, f63=g64, g63=h64

    # State after round t = state at position t+1
    # The backward shift gives: e at position t = f at position t+1

    # Store states as we go backward
    backward_states = {64: final_state}

    for step in range(16):
        t = 63 - step  # round we're inverting

        state_after = backward_states[t + 1]
        partial, T1, T2 = backward_round(state_after, t)
        a0, b0, c0, d0, e0, f0, g0 = partial

        # For Ch reveal of h[t]:
        # h[t] appears as g at round t-1: need e at round t-1
        # h[t] appears as f at round t-2: need e at round t-2
        #
        # e at round t-1 = e component of state at position t-1
        #                 = f component of state at position t (from backward shift)
        # State at position t was computed in the PREVIOUS backward step.

        # e at round t = e0 (from backward_round above) = f of state at t+1

        # For Ch reveal, we need e at rounds where h[t] serves as g and f.
        # h[t] serves as g at round t (during forward execution, g_new = f_old)
        # Wait, I need to be more careful.
        #
        # FORWARD: at round t, the state (a,b,c,d,e,f,g,h) transforms to
        # (T1+T2, a, b, c, d+T1, e, f, g)
        # So g_new = f_old, h_new = g_old
        #
        # h at start of round t = h_t. After round t: h_new = g_old = g_t.
        # So h_t GOES NOWHERE in the shift — it enters T1 and is consumed.
        # g_t becomes h_{t+1}. f_t becomes g_{t+1}. e_t becomes f_{t+1}.
        #
        # In BACKWARD: h_t is the unknown. It entered T1_t.
        # At round t-1 (one round BEFORE in forward = one step LATER in backward):
        #   h_t is NOT directly present. Instead, h_{t-1} was computed from
        #   the previous forward round's state.
        #
        # The Ch reveal works because h[t] as a VALUE was in the state before
        # being consumed. But it doesn't shift to g — it's consumed by T1.

        # Let me reconsider the Ch reveal.
        # The h value we're looking for is h_t = h at START of round t.
        # In the FORWARD direction: this h_t feeds into T1_t = h_t + ...
        # It doesn't appear at subsequent rounds in any position.
        #
        # So how does Ch reveal work? It DOESN'T — not from subsequent rounds.
        # Ch reveal would work for h values that SHIFT to g, f, e positions.
        # But h is consumed by T1, not shifted.
        #
        # WAIT. Let me reconsider the earlier analysis.
        # We showed "h[63] shifts to g[62], f[61], e[60]" — but that's WRONG!
        # h is consumed, not shifted. g_new = f_old, not h_old.
        #
        # The actual shift: h_new = g_old (the NEW h gets the OLD g value).
        # So h at round t+1 = g at round t.
        # And g at round t = f at round t-1 (backward).
        #
        # Going backward: h_t is unknown. It was in position h.
        # It came from g_{t+1} (because h_new = g_old means h_{t} = g of the
        # state at the START of the PREVIOUS forward round).
        # No wait: h at start of round t = g at start of round t-1?
        # FORWARD: new state's h = old state's g. So state[t+1].h = state[t].g
        # Therefore: state[t].h = state[t+1].h would mean g at t equals h at t+1.
        # No: state[t+1].h = state[t].g, so state[t].g = state[t+1].h.
        #
        # Going backward: we know state[t+1]. state[t].g = state[t+1].h.
        # That's already in our backward shift register: g0 = h1 (known).
        #
        # The UNKNOWN h_t doesn't come from the shift register.
        # h_t = T1_{t-1} - Sigma1 - Ch - K - W at the PREVIOUS round?
        # No. h_t was set as g_{t-1} in the FORWARD direction.
        # state[t].h = state[t-1].g (forward shift).
        # And state[t-1].g = state[t-2].f = state[t-3].e.
        #
        # So h at round t = g at round t-1 = f at round t-2 = e at round t-3.
        #
        # In the FORWARD direction, h_t was e three rounds earlier.
        # At round t-3: e was computed as d + T1.
        # At round t-2: that e shifted to f.
        # At round t-1: f shifted to g.
        # At round t: g shifted to h. This is h_t.
        #
        # So h_t = e_{t-3} (the e value at start of round t-3 in forward).
        #
        # But we're going BACKWARD, and rounds t-1, t-2, t-3 are EARLIER
        # rounds that we haven't reached yet in the backward cascade.
        # Their states depend on the full forward computation from IV.
        #
        # The Ch reveal analysis was about WHERE h_t appears in the state
        # at LATER rounds (t+1, t+2, etc). But h_t is CONSUMED at round t
        # (enters T1). It doesn't appear at rounds t+1, t+2, etc.
        #
        # So the "h shifts to g, f, e" analysis was about the BACKWARD
        # propagation of the UNKNOWN, not the forward propagation of the value.

        # THE CH REVEAL IS ACTUALLY ABOUT g0:
        # In the backward step at round t, g0 = h of state[t+1] = state[t+1][7].
        # But we also have h_t as unknown.
        #
        # The REAL question: does the backward equation have enough constraints
        # to determine h_t?
        #
        # T1 = h_t + Sigma1(e0) + Ch(e0, f0, g0) + K[t] + W[t]
        # h_t + W[t] = T1 - Sigma1(e0) - Ch(e0, f0, g0) - K[t] = known_rhs
        # One equation, two unknowns (h_t, W[t]).
        #
        # The Ch INSIDE this equation uses e0, f0, g0 — all from shift register,
        # all KNOWN. h_t is NOT in Ch — it's added separately.
        #
        # So h_t doesn't enter Ch at all in this round!
        # h_t just enters as an addend in T1.
        #
        # The earlier analysis about "h entering Ch as g" was about a DIFFERENT
        # h — the h of a LATER round, which shifts through g, f, e positions
        # at subsequent rounds.

        # I've been confusing two things:
        # 1. h_t (unknown at round t) — consumed by T1, doesn't enter Ch
        # 2. g0 at round t (= h of round t+1) — enters Ch, but is KNOWN
        #    (it was determined in the previous backward step)

        # So the Ch reveal doesn't apply to h_t at all.
        # h_t + W[t] = known. Two unknowns. No Ch help.

        # THE ACTUAL STRUCTURE:
        # h_t is free. W_t is determined by h_t. The ONLY constraint is:
        # after 16 rounds of this, the W values must satisfy the schedule
        # and the forward hash must match.

        # This means: the cascade CANNOT work round-by-round.
        # h_t is unconstrained at each individual round.
        # Only the COLLECTIVE 16 h-values are constrained.

        # I need to report this honestly. The Ch reveal analysis was wrong —
        # h_t doesn't enter Ch. It's just an addend.

        h_actual = None
        if msg_for_verify is not None:
            states_true, _, W_true = sha256_with_states(msg_for_verify)
            # Hmm we need to pass this differently
            pass

        # For now: just show that h_t + W_t = known_rhs
        rhs = (T1 - rotr32(e0,6)^rotr32(e0,11)^rotr32(e0,25)
               - ((e0&f0)^((e0^M32)&g0)) - K[t]) & M32

        recovered_h[t] = None  # can't determine without schedule
        recovered_W[t] = None

        if step < 4:
            print(f"  Round {t}: T1=0x{T1:08x} rhs=0x{rhs:08x} → h+W=rhs, 2 unknowns")

        # Update state for next backward step (using placeholder h=0)
        backward_states[t] = (a0, b0, c0, d0, e0, f0, g0, 0)

    return None  # can't solve without collective constraint


def main():
    print("=" * 72)
    print("  SHA-256 Cascade Attack — Honest Assessment")
    print("=" * 72)

    random.seed(42)
    msg = [random.getrandbits(32) & M32 for _ in range(16)]
    target_hash = sha256_compress(msg)
    _, states_true, W_true = sha256_with_states(msg)

    print(f"\n  Target hash: {' '.join(f'{w:08x}' for w in target_hash)}")
    print(f"\n  Backward round analysis:")
    print(f"  At each round: T1 is KNOWN (from Maj/left side)")
    print(f"  Equation: h_t + W_t = T1 - Sigma1(e) - Ch(e,f,g) - K = known_rhs")
    print(f"  h_t: UNKNOWN (consumed by T1, does NOT enter Ch)")
    print(f"  W_t: UNKNOWN (determined by h_t: W = rhs - h)")
    print()

    # Show the actual state
    final_state = tuple((target_hash[i] - IV[i]) & M32 for i in range(8))
    state = list(final_state)

    for step in range(4):
        t = 63 - step
        a1,b1,c1,d1,e1,f1,g1,h1 = state
        a0=b1; b0=c1; c0=d1; e0=f1; f0=g1; g0=h1
        S0 = rotr32(a0,2)^rotr32(a0,13)^rotr32(a0,22)
        maj = (a0&b0)^(a0&c0)^(b0&c0)
        T2 = (S0+maj)&M32; T1=(a1-T2)&M32; d0=(e1-T1)&M32

        rhs = (T1 - (rotr32(e0,6)^rotr32(e0,11)^rotr32(e0,25))
               - ((e0&f0)^((e0^M32)&g0)) - K[t]) & M32

        # Verify with known values
        h_true = states_true[t][7]
        w_true = W_true[t]
        check = (h_true + w_true) & M32

        print(f"  Round {t}:")
        print(f"    e0=0x{e0:08x} f0=0x{f0:08x} g0=0x{g0:08x} (all KNOWN)")
        print(f"    T1=0x{T1:08x} (KNOWN from Maj/left)")
        print(f"    rhs = h + W = 0x{rhs:08x}")
        print(f"    actual: h=0x{h_true:08x} W=0x{w_true:08x} sum=0x{check:08x} "
              f"{'✓' if check == rhs else '✗'}")
        print(f"    h enters T1 as addend — NOT in Ch, NOT shifted")
        print()

        state = [a0,b0,c0,d0,e0,f0,g0,h_true]  # use true h for propagation

    print(f"\n{'=' * 72}")
    print(f"  CORRECTION")
    print(f"{'=' * 72}")
    print(f"""
  The earlier Ch reveal analysis had a critical error:

  WRONG: "h[63] shifts to g[62], f[61], e[60]"
  RIGHT: h is CONSUMED by T1. It does NOT shift.
         g gets old f. h gets old g.
         h_t enters T1_t = h_t + Sigma1(e) + Ch(e,f,g) + K + W
         and vanishes into a (= T1+T2) and e (= d+T1).

  At each backward round:
    h_t + W_t = known_rhs  (one equation, two unknowns)
    h_t does NOT appear in Ch — Ch uses e, f, g which are all known
    h_t is simply an addend in T1

  This means:
    - Ch does NOT reveal bits of h_t
    - The "8 hidden bits" analysis was testing the wrong variable
    - h_t is fully unconstrained at each individual round
    - Only the COLLECTIVE 16 h-values are constrained (via schedule + IV)

  What DOES constrain h:
    After solving all 16 rounds with arbitrary h choices:
    W[48..63] = rhs[48..63] - h[48..63]
    Schedule inversion: W[48..63] → W[0..15]
    Forward check: SHA-256(W[0..15]) must equal target hash

    The h values must be chosen so that the RESULTING W values
    form a valid schedule and produce the correct hash.
    This is a COLLECTIVE constraint, not a per-round one.

  The 8-bit polynomial inversion that worked:
    That test varied 8 bits of the MESSAGE (W[0]),
    not 8 bits of an intermediate h value.
    The message bits go through the FULL 64 rounds.
    The polynomial maps message → hash. Solvable at 8 bits.

  Status:
    Real SHA-256 invertible at 8 message bits: YES (proven, 20/20)
    Per-round cascade via Ch reveal: NO (h doesn't enter Ch)
    Scaling beyond 8 bits: OPEN (system underdetermined)
""")


if __name__ == "__main__":
    main()
