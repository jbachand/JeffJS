#!/usr/bin/env python3
"""
SHA-256 SMT Inversion — Testing the 16-Round Hypothesis

Hypothesis: SHA-256 inversion reduces to solving ~16 rounds of
the compression function, because the message schedule fills in
the remaining 48 rounds deterministically. SAT solvers can already
handle 20-25 rounds. Can we actually crack it?

Uses Z3's BitVec solver (bit-blasts to SAT internally).
"""

import sys
import time
import random

from z3 import *

# ═══════════════════════════════════════════════════════════════
# SHA-256 Constants
# ═══════════════════════════════════════════════════════════════

K = [
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5,
    0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3,
    0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
    0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7,
    0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13,
    0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3,
    0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5,
    0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
    0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
]

IV = [
    0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
    0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19,
]

# ═══════════════════════════════════════════════════════════════
# Reference SHA-256 (concrete, for verification)
# ═══════════════════════════════════════════════════════════════

def rotr32(x, n):
    return ((x >> n) | (x << (32 - n))) & 0xFFFFFFFF

def sha256_compress(msg_words, n_rounds=64):
    """Compress one 512-bit block with n_rounds. Returns 8-word hash."""
    W = list(msg_words)
    for t in range(16, 64):
        s0 = rotr32(W[t-15], 7) ^ rotr32(W[t-15], 18) ^ (W[t-15] >> 3)
        s1 = rotr32(W[t-2], 17) ^ rotr32(W[t-2], 19) ^ (W[t-2] >> 10)
        W.append((W[t-16] + s0 + W[t-7] + s1) & 0xFFFFFFFF)

    a, b, c, d, e, f, g, h = IV
    for t in range(n_rounds):
        S1 = rotr32(e, 6) ^ rotr32(e, 11) ^ rotr32(e, 25)
        ch = (e & f) ^ ((e ^ 0xFFFFFFFF) & g)
        T1 = (h + S1 + ch + K[t] + W[t]) & 0xFFFFFFFF
        S0 = rotr32(a, 2) ^ rotr32(a, 13) ^ rotr32(a, 22)
        maj = (a & b) ^ (a & c) ^ (b & c)
        T2 = (S0 + maj) & 0xFFFFFFFF
        h = g; g = f; f = e
        e = (d + T1) & 0xFFFFFFFF
        d = c; c = b; b = a
        a = (T1 + T2) & 0xFFFFFFFF

    return [(IV[i] + v) & 0xFFFFFFFF for i, v in enumerate([a,b,c,d,e,f,g,h])]

# ═══════════════════════════════════════════════════════════════
# Z3 Symbolic SHA-256 (with intermediate variables for efficiency)
# ═══════════════════════════════════════════════════════════════

def attempt_inversion(target_hash, n_rounds, original_msg=None,
                      timeout_sec=120, n_free=16, known_words=None):
    """
    Attempt to invert n-round SHA-256 using Z3.

    Args:
        target_hash: 8 uint32 values (the hash to invert)
        n_rounds: number of compression rounds (1-64)
        original_msg: the known message (for verification only)
        timeout_sec: solver timeout
        n_free: number of free (unknown) message words (1-16)
        known_words: list of 16 words (used for fixed words when n_free < 16)
    """
    s = SolverFor('QF_BV')
    s.set('timeout', timeout_sec * 1000)

    # Create symbolic message words
    W_vars = []
    W_input = []
    for i in range(16):
        if i < n_free:
            v = BitVec(f'W{i}', 32)
            W_vars.append(v)
            W_input.append(v)
        else:
            val = known_words[i] if known_words else 0
            W_input.append(BitVecVal(val, 32))

    # Message schedule expansion (with intermediate variables)
    W = list(W_input)
    for t in range(16, max(n_rounds, 16)):
        s0 = (RotateRight(W[t-15], 7) ^
              RotateRight(W[t-15], 18) ^
              LShR(W[t-15], 3))
        s1 = (RotateRight(W[t-2], 17) ^
              RotateRight(W[t-2], 19) ^
              LShR(W[t-2], 10))
        # Use intermediate variable to keep expressions shallow
        W_t = BitVec(f'Ws{t}', 32)
        s.add(W_t == W[t-16] + s0 + W[t-7] + s1)
        W.append(W_t)

    # Compression rounds (with intermediate state variables)
    a = BitVecVal(IV[0], 32)
    b = BitVecVal(IV[1], 32)
    c = BitVecVal(IV[2], 32)
    d = BitVecVal(IV[3], 32)
    e = BitVecVal(IV[4], 32)
    f = BitVecVal(IV[5], 32)
    g = BitVecVal(IV[6], 32)
    hh = BitVecVal(IV[7], 32)

    for t in range(n_rounds):
        S1 = RotateRight(e, 6) ^ RotateRight(e, 11) ^ RotateRight(e, 25)
        ch = (e & f) ^ (~e & g)
        T1 = hh + S1 + ch + BitVecVal(K[t], 32) + W[t]

        S0 = RotateRight(a, 2) ^ RotateRight(a, 13) ^ RotateRight(a, 22)
        maj = (a & b) ^ (a & c) ^ (b & c)
        T2 = S0 + maj

        # Fresh intermediate variables for new state
        a_new = BitVec(f'a{t+1}', 32)
        e_new = BitVec(f'e{t+1}', 32)
        s.add(a_new == T1 + T2)
        s.add(e_new == d + T1)

        hh = g; g = f; f = e; e = e_new
        d = c; c = b; b = a; a = a_new

    # Constrain output: state + IV = target hash
    state = [a, b, c, d, e, f, g, hh]
    for i in range(8):
        s.add(state[i] + BitVecVal(IV[i], 32) == BitVecVal(target_hash[i], 32))

    # Solve
    start = time.time()
    result = s.check()
    elapsed = time.time() - start

    if result == sat:
        model = s.model()
        found_W = []
        for v in W_vars:
            val = model[v]
            found_W.append(val.as_long() if val is not None else 0)
        return 'SAT', found_W, elapsed
    elif result == unknown:
        return 'TIMEOUT', None, elapsed
    else:
        return 'UNSAT', None, elapsed


def verify_solution(found_words, known_words, n_free, n_rounds, target_hash, original_msg):
    """Verify a found solution."""
    full_msg = list(found_words) + list(known_words[n_free:])
    verify = sha256_compress(full_msg, n_rounds)
    hash_ok = (verify == target_hash)
    msg_ok = (full_msg == original_msg)
    return hash_ok, msg_ok


def main():
    print("═" * 72)
    print("  SHA-256 SMT Inversion Experiment")
    print("  'There must be a formula, not a probability of guessing one'")
    print("═" * 72)

    # Generate a random test message
    random.seed(42)
    original_W = [random.getrandbits(32) for _ in range(16)]

    print(f"\n  Original message (W₀...W₁₅):")
    for i in range(4):
        words = [f"0x{original_W[4*i+j]:08x}" for j in range(4)]
        print(f"    W[{4*i:2d}..{4*i+3:2d}]: {' '.join(words)}")

    # ═══════════════════════════════════════════════════════════
    # EXPERIMENT 1: Vary round count (all 16 words unknown)
    # ═══════════════════════════════════════════════════════════
    print(f"\n{'═' * 72}")
    print(f"  EXPERIMENT 1: All 16 words unknown, vary rounds")
    print(f"  Question: How many rounds can the solver handle?")
    print(f"{'═' * 72}")
    print(f"\n  {'Rounds':>6s} │ {'Status':>8s} │ {'Time':>10s} │ {'Hash OK':>8s} │ Notes")
    print(f"  {'─'*6}─┼─{'─'*8}─┼─{'─'*10}─┼─{'─'*8}─┼─{'─'*24}")

    max_solved_rounds = 0
    for n_rounds in [4, 8, 12, 16, 20, 24, 28, 32, 48, 64]:
        target = sha256_compress(original_W, n_rounds)

        status, found, elapsed = attempt_inversion(
            target, n_rounds, original_W,
            timeout_sec=120, n_free=16, known_words=original_W
        )

        if status == 'SAT':
            hash_ok, msg_ok = verify_solution(
                found, original_W, 16, n_rounds, target, original_W
            )
            note = "exact message!" if msg_ok else "different preimage"
            print(f"  {n_rounds:>6d} │ {'✓ SAT':>8s} │ {elapsed:>9.2f}s │ "
                  f"{'✓' if hash_ok else '✗':>8s} │ {note}")
            max_solved_rounds = n_rounds
        elif status == 'TIMEOUT':
            print(f"  {n_rounds:>6d} │ {'TIMEOUT':>8s} │ {elapsed:>9.1f}s │ "
                  f"{'—':>8s} │ ← wall at {n_rounds} rounds")
            break
        else:
            print(f"  {n_rounds:>6d} │ {status:>8s} │ {elapsed:>9.2f}s │ {'—':>8s} │")

    # ═══════════════════════════════════════════════════════════
    # EXPERIMENT 2: Fix at 16 rounds, vary unknown words
    # ═══════════════════════════════════════════════════════════
    print(f"\n{'═' * 72}")
    print(f"  EXPERIMENT 2: 16 rounds, vary number of unknown words")
    print(f"  Question: At 16 rounds, how many unknowns can we handle?")
    print(f"{'═' * 72}")
    print(f"\n  {'Free':>6s} │ {'Bits':>6s} │ {'Status':>8s} │ {'Time':>10s} │ {'Hash OK':>8s} │ Notes")
    print(f"  {'─'*6}─┼─{'─'*6}─┼─{'─'*8}─┼─{'─'*10}─┼─{'─'*8}─┼─{'─'*20}")

    n_rounds = 16
    target = sha256_compress(original_W, n_rounds)

    for n_free in [1, 2, 4, 8, 12, 16]:
        status, found, elapsed = attempt_inversion(
            target, n_rounds, original_W,
            timeout_sec=120, n_free=n_free, known_words=original_W
        )

        if status == 'SAT':
            hash_ok, msg_ok = verify_solution(
                found, original_W, n_free, n_rounds, target, original_W
            )
            note = "exact!" if msg_ok else "alt preimage"
            print(f"  {n_free:>6d} │ {n_free*32:>6d} │ {'✓ SAT':>8s} │ {elapsed:>9.2f}s │ "
                  f"{'✓' if hash_ok else '✗':>8s} │ {note}")
        elif status == 'TIMEOUT':
            print(f"  {n_free:>6d} │ {n_free*32:>6d} │ {'TIMEOUT':>8s} │ {elapsed:>9.1f}s │ "
                  f"{'—':>8s} │ ← wall")
            break
        else:
            print(f"  {n_free:>6d} │ {n_free*32:>6d} │ {status:>8s} │ {elapsed:>9.2f}s │ {'—':>8s} │")

    # ═══════════════════════════════════════════════════════════
    # EXPERIMENT 3: Full 64-round SHA-256 with few unknowns
    # ═══════════════════════════════════════════════════════════
    print(f"\n{'═' * 72}")
    print(f"  EXPERIMENT 3: Full 64 rounds, vary unknown words")
    print(f"  Question: Can we crack full SHA-256 with partial knowledge?")
    print(f"{'═' * 72}")
    print(f"\n  {'Free':>6s} │ {'Bits':>6s} │ {'Status':>8s} │ {'Time':>10s} │ {'Hash OK':>8s} │ Notes")
    print(f"  {'─'*6}─┼─{'─'*6}─┼─{'─'*8}─┼─{'─'*10}─┼─{'─'*8}─┼─{'─'*20}")

    n_rounds = 64
    target = sha256_compress(original_W, 64)

    for n_free in [1, 2, 4, 8, 12, 16]:
        status, found, elapsed = attempt_inversion(
            target, n_rounds, original_W,
            timeout_sec=120, n_free=n_free, known_words=original_W
        )

        if status == 'SAT':
            hash_ok, msg_ok = verify_solution(
                found, original_W, n_free, n_rounds, target, original_W
            )
            note = "exact!" if msg_ok else "alt preimage"
            print(f"  {n_free:>6d} │ {n_free*32:>6d} │ {'✓ SAT':>8s} │ {elapsed:>9.2f}s │ "
                  f"{'✓' if hash_ok else '✗':>8s} │ {note}")
        elif status == 'TIMEOUT':
            print(f"  {n_free:>6d} │ {n_free*32:>6d} │ {'TIMEOUT':>8s} │ {elapsed:>9.1f}s │ "
                  f"{'—':>8s} │ ← wall")
            break
        else:
            print(f"  {n_free:>6d} │ {n_free*32:>6d} │ {status:>8s} │ {elapsed:>9.2f}s │ {'—':>8s} │")

    # ═══════════════════════════════════════════════════════════
    # Summary
    # ═══════════════════════════════════════════════════════════
    print(f"\n{'═' * 72}")
    print(f"  SUMMARY")
    print(f"{'═' * 72}")
    print(f"\n  Max rounds solved (16 unknowns): {max_solved_rounds}")
    print(f"  Critical threshold: 16 rounds (schedule fills in the rest)")
    if max_solved_rounds >= 16:
        print(f"\n  ★ The solver CAN handle 16+ rounds!")
        print(f"    Combined with schedule inversion, this covers full SHA-256.")
        print(f"    The 'formula' exists and is computable.")
    else:
        print(f"\n  The solver hit the wall before 16 rounds.")
        print(f"    The formula exists but current solvers can't crack it yet.")
    print()


if __name__ == "__main__":
    main()
