#!/usr/bin/env python3
"""
Decompose the entropy at each SHA-256 round.

Round 1: T1 = IV[7] + Σ₁(IV[4]) + Ch(IV[4],IV[5],IV[6]) + K[0] + W[0]
       = CONSTANT + W[0]
       = CONSTANT + (input_byte << 24 | 0x800000)

The entropy is JUST the input. And for ASCII, that's only 95 values.
Trace how this tiny seed of entropy grows through the rounds.
"""

import numpy as np
from math import comb
import struct
import itertools

M32 = 0xFFFFFFFF

def rotr(x, n): return ((x >> n) | (x << (32 - n))) & M32
def shr(x, n): return x >> n
def Sigma1(x): return rotr(x, 6) ^ rotr(x, 11) ^ rotr(x, 25)
def Sigma0(x): return rotr(x, 2) ^ rotr(x, 13) ^ rotr(x, 22)
def sigma1(x): return rotr(x, 17) ^ rotr(x, 19) ^ shr(x, 10)
def sigma0(x): return rotr(x, 7) ^ rotr(x, 18) ^ shr(x, 3)
def Ch(e, f, g): return (e & f) ^ ((~e) & g) & M32
def Maj(a, b, c): return (a & b) ^ (a & c) ^ (b & c)

K = [0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
     0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
     0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
     0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
     0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
     0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
     0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
     0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2]
IV = [0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,
      0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19]

def mobius(Y, n_bits):
    a = Y.copy()
    for i in range(n_bits):
        mask = 1 << i
        for x in range(len(a)):
            if x & mask:
                a[x] ^= a[x ^ mask]
    return a

def main():
    print("=" * 70)
    print("SHA-256 ENTROPY DECOMPOSITION")
    print("=" * 70)

    # ============ ROUND 0 EXACT DECOMPOSITION ============
    print("\n--- Round 0 (first round) ---")
    print(f"T1 = h + Σ₁(e) + Ch(e,f,g) + K[0] + W[0]")
    print(f"   = IV[7] + Σ₁(IV[4]) + Ch(IV[4],IV[5],IV[6]) + K[0] + W[0]")

    h0 = IV[7]
    e0 = IV[4]
    f0 = IV[5]
    g0 = IV[6]
    const_part = (h0 + Sigma1(e0) + Ch(e0, f0, g0) + K[0]) & M32
    print(f"   = {hex(const_part)} + W[0]")
    print(f"   = {hex(const_part)} + (byte << 24 | 0x800000)")

    print(f"\nT2 = Σ₀(IV[0]) + Maj(IV[0],IV[1],IV[2])")
    t2_0 = (Sigma0(IV[0]) + Maj(IV[0], IV[1], IV[2])) & M32
    print(f"   = {hex(t2_0)}  (PURE CONSTANT — no input dependency)")

    print(f"\nAfter round 0:")
    print(f"  a = T1 + T2 = ({hex(const_part)} + W[0]) + {hex(t2_0)}")
    print(f"    = {hex((const_part + t2_0) & M32)} + W[0]")
    print(f"  e = IV[3] + T1 = {hex(IV[3])} + {hex(const_part)} + W[0]")
    print(f"    = {hex((IV[3] + const_part) & M32)} + W[0]")
    print(f"  b = IV[0] = {hex(IV[0])}  (constant)")
    print(f"  c = IV[1] = {hex(IV[1])}  (constant)")
    print(f"  d = IV[2] = {hex(IV[2])}  (constant)")
    print(f"  f = IV[4] = {hex(IV[4])}  (constant)")
    print(f"  g = IV[5] = {hex(IV[5])}  (constant)")
    print(f"  h = IV[6] = {hex(IV[6])}  (constant)")
    print(f"\n  → 2 of 8 words depend on input (a and e)")
    print(f"  → Both are LINEAR: constant + W[0]")

    # ============ W[0] STRUCTURE ============
    print(f"\n{'='*70}")
    print("W[0] STRUCTURE FOR DIFFERENT INPUTS")
    print("=" * 70)

    # For a single byte message: padding is
    # [byte, 0x80, 0x00*54, 0x00000008]
    # W[0] = (byte << 24) | (0x80 << 16) = byte * 0x01000000 + 0x00800000
    print(f"\nSingle byte: W[0] = byte * 0x01000000 + 0x00800000")
    print(f"  byte=0x00: W[0] = {hex(0x00800000)}")
    print(f"  byte=0x41: W[0] = {hex(0x41800000)} ('A')")
    print(f"  byte=0x7A: W[0] = {hex(0x7A800000)} ('z')")
    print(f"  byte=0xFF: W[0] = {hex(0xFF800000)}")

    print(f"\n  Only bits 24-31 vary (8 bits of 32)")
    print(f"  Bit 23 is always 1 (padding)")
    print(f"  Bits 0-22 are always 0")

    # ASCII printable: 0x20-0x7E (95 values)
    print(f"\n  ASCII printable (0x20-0x7E): 95 values")
    print(f"  Only bits 24-30 vary (7 bits), bit 31=0 always")
    w0_ascii = [(b << 24) | 0x800000 for b in range(0x20, 0x7F)]
    print(f"  W[0] range: {hex(min(w0_ascii))} - {hex(max(w0_ascii))}")

    # ============ DEGREE GROWTH: ROUND BY ROUND ============
    print(f"\n{'='*70}")
    print("DEGREE GROWTH: How input bits propagate through rounds")
    print("=" * 70)

    N = 256
    n_bits = 8

    # Get all states
    all_states = []
    all_t1 = []
    for val in range(N):
        msg = bytes([val])
        padded = msg + b'\x80' + b'\x00' * 54 + struct.pack('>Q', 8)
        W = list(struct.unpack('>16I', padded))
        for t in range(16, 64):
            W.append((sigma1(W[t-2]) + W[t-7] + sigma0(W[t-15]) + W[t-16]) & M32)
        a,b,c,d,e,f,g,h = IV
        states = [(a,b,c,d,e,f,g,h)]
        t1v = []
        for t in range(64):
            T1 = (h + Sigma1(e) + Ch(e,f,g) + K[t] + W[t]) & M32
            T2 = (Sigma0(a) + Maj(a,b,c)) & M32
            t1v.append(T1)
            h=g;g=f;f=e;e=(d+T1)&M32;d=c;c=b;b=a;a=(T1+T2)&M32
            states.append((a,b,c,d,e,f,g,h))
        all_states.append(states)
        all_t1.append(t1v)

    # For each state variable at each round, compute ANF degree
    var_names = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h']

    print(f"\nEffective degree of each state variable (as function of 8 input bits):")
    print(f"{'Round':>5} |" + "".join(f" {v:>4}" for v in var_names) + " | T1 deg")
    print("-" * 60)

    for rnd in list(range(9)) + [12, 16, 32, 48, 63, 64]:
        degs = []
        for var_idx in range(8):
            # Get this variable for all inputs
            vals = np.array([all_states[val][rnd][var_idx] for val in range(N)], dtype=np.uint32)
            # Check if it's constant
            if np.all(vals == vals[0]):
                degs.append(0)
                continue
            # Find max degree across all 32 bits
            max_deg = 0
            for b in range(32):
                bits = np.array([(int(vals[v]) >> b) & 1 for v in range(N)], dtype=np.uint8)
                if np.all(bits == bits[0]):
                    continue
                anf = mobius(bits, n_bits)
                for m in range(N-1, -1, -1):
                    if anf[m] == 1:
                        max_deg = max(max_deg, bin(m).count('1'))
                        break
            degs.append(max_deg)

        # T1 degree
        if rnd < 64:
            t1_vals = np.array([all_t1[val][rnd] for val in range(N)], dtype=np.uint32)
            t1_deg = 0
            for b in range(32):
                bits = np.array([(int(t1_vals[v]) >> b) & 1 for v in range(N)], dtype=np.uint8)
                if np.all(bits == bits[0]): continue
                anf = mobius(bits, n_bits)
                for m in range(N-1, -1, -1):
                    if anf[m] == 1:
                        t1_deg = max(t1_deg, bin(m).count('1'))
                        break
        else:
            t1_deg = -1

        deg_str = "".join(f" {d:>4}" for d in degs)
        t1_str = f"{t1_deg}" if t1_deg >= 0 else "  -"
        print(f"  R={rnd:2d}  |{deg_str} | {t1_str}")

    # ============ THE KEY: WHAT HAPPENS TO a AND e ============
    print(f"\n{'='*70}")
    print("THE ENTROPY CARRIERS: a and e round by round")
    print("=" * 70)
    print("a = T1 + T2 (new entropy enters)")
    print("e = d + T1 (old d gets infected)")
    print("Everything else is just shifting.\n")

    for rnd in range(9):
        # a and e values for all inputs
        a_vals = np.array([all_states[val][rnd+1][0] for val in range(N)])
        e_vals = np.array([all_states[val][rnd+1][4] for val in range(N)])

        # How many unique values?
        a_unique = len(set(int(x) for x in a_vals))
        e_unique = len(set(int(x) for x in e_vals))

        # How many bits of a and e actually change?
        a_varying_bits = sum(1 for b in range(32) if len(set((int(a_vals[v])>>b)&1 for v in range(N))) > 1)
        e_varying_bits = sum(1 for b in range(32) if len(set((int(e_vals[v])>>b)&1 for v in range(N))) > 1)

        print(f"  After R={rnd}: a has {a_unique:3d} unique values ({a_varying_bits:2d}/32 bits vary) "
              f"| e has {e_unique:3d} unique values ({e_varying_bits:2d}/32 bits vary)")

    # ============ ASCII-ONLY ANALYSIS ============
    print(f"\n{'='*70}")
    print("ASCII-ONLY: Restrict inputs to printable ASCII (0x20-0x7E)")
    print("=" * 70)

    ascii_vals = list(range(0x20, 0x7F))  # 95 values
    N_ascii = len(ascii_vals)

    print(f"\n{N_ascii} ASCII inputs (vs {N} full byte range)")

    # Compare hash distribution
    import hashlib

    hash_bits_full = np.zeros((N, 256), dtype=np.uint8)
    for i, val in enumerate(range(N)):
        d = hashlib.sha256(bytes([val])).digest()
        for byte_idx in range(32):
            for b in range(8):
                hash_bits_full[i, byte_idx*8+b] = (d[byte_idx]>>b)&1

    hash_bits_ascii = np.zeros((N_ascii, 256), dtype=np.uint8)
    for i, val in enumerate(ascii_vals):
        d = hashlib.sha256(bytes([val])).digest()
        for byte_idx in range(32):
            for b in range(8):
                hash_bits_ascii[i, byte_idx*8+b] = (d[byte_idx]>>b)&1

    # Bit bias for ASCII-only
    print(f"\nHash bit bias (should be 50% for random):")
    biases_full = np.mean(hash_bits_full, axis=0)
    biases_ascii = np.mean(hash_bits_ascii, axis=0)
    print(f"  Full (256 inputs):  mean={np.mean(biases_full):.4f} "
          f"std={np.std(biases_full):.4f} "
          f"min={np.min(biases_full):.4f} max={np.max(biases_full):.4f}")
    print(f"  ASCII (95 inputs):  mean={np.mean(biases_ascii):.4f} "
          f"std={np.std(biases_ascii):.4f} "
          f"min={np.min(biases_ascii):.4f} max={np.max(biases_ascii):.4f}")

    # ============ BACKWARD FROM HASH: WHAT'S KNOWN ============
    print(f"\n{'='*70}")
    print("BACKWARD: Reconstructing the entropy ramp from the hash")
    print("=" * 70)

    # Pick a specific input
    test_byte = ord('A')  # 0x41
    msg = bytes([test_byte])
    padded = msg + b'\x80' + b'\x00' * 54 + struct.pack('>Q', 8)
    W = list(struct.unpack('>16I', padded))
    for t in range(16, 64):
        W.append((sigma1(W[t-2]) + W[t-7] + sigma0(W[t-15]) + W[t-16]) & M32)

    a,b,c,d,e,f,g,h = IV
    states = [(a,b,c,d,e,f,g,h)]
    t1v, t2v = [], []
    for t in range(64):
        T1 = (h + Sigma1(e) + Ch(e,f,g) + K[t] + W[t]) & M32
        T2 = (Sigma0(a) + Maj(a,b,c)) & M32
        t1v.append(T1); t2v.append(T2)
        h=g;g=f;f=e;e=(d+T1)&M32;d=c;c=b;b=a;a=(T1+T2)&M32
        states.append((a,b,c,d,e,f,g,h))

    hash_out = [(states[64][i]+IV[i])&M32 for i in range(8)]
    print(f"\nInput: 'A' (0x41)")
    print(f"Hash: {hashlib.sha256(b'A').hexdigest()}")

    # Backward walk from hash
    st = [(hash_out[i]-IV[i])&M32 for i in range(8)]
    a_f,b_f,c_f,d_f,e_f,f_f,g_f,h_f = st

    # Round 63
    T2_63 = (Sigma0(b_f) + Maj(b_f,c_f,d_f)) & M32
    T1_63 = (a_f - T2_63) & M32
    e_bef = (e_f - T1_63) & M32
    print(f"\nBackward recovery:")
    print(f"  T1[63] = {hex(T1_63)} (actual: {hex(t1v[63])})")
    print(f"  T2[63] = {hex(T2_63)} (actual: {hex(t2v[63])})")

    # The addend equation: T1[63] = h[63] + Σ₁(e[63]) + Ch(e[63],f[63],g[63]) + K[63] + W[63]
    # We know: T1[63], e[63]=f_f, f[63]=g_f, g[63]=h_f, K[63]
    # Unknown: h[63], W[63]
    # h[63] + W[63] = T1[63] - Σ₁(f_f) - Ch(f_f,g_f,h_f) - K[63]

    rhs = (T1_63 - Sigma1(f_f) - Ch(f_f,g_f,h_f) - K[63]) & M32
    print(f"\n  Addend equation R63: h[63] + W[63] = {hex(rhs)}")
    print(f"  Actual h[63] = {hex(states[63][7])}")
    print(f"  Actual W[63] = {hex(W[63])}")
    print(f"  Sum check: {hex((states[63][7]+W[63])&M32)} = {hex(rhs)}: {(states[63][7]+W[63])&M32 == rhs}")

    # W[63] depends on the message through the schedule
    # But the schedule starts simple: W[0] is the only variable word
    # W[1..14] = 0, W[15] = 8
    # Schedule propagation builds complexity

    print(f"\n{'='*70}")
    print("SCHEDULE ENTROPY: How W[0] propagates to W[63]")
    print("=" * 70)
    print(f"\nW[0] = input_byte << 24 | 0x800000 (only word with input)")
    print(f"W[1..14] = 0x00000000 (zero padding)")
    print(f"W[15] = 0x00000008 (message length)")
    print()
    print(f"Schedule propagation: W[t] = σ₁(W[t-2]) + W[t-7] + σ₀(W[t-15]) + W[t-16]")
    print()

    # Show which W values depend on the input
    for t in range(20):
        vals = set()
        for byte_val in range(256):
            msg2 = bytes([byte_val])
            pad2 = msg2 + b'\x80' + b'\x00' * 54 + struct.pack('>Q', 8)
            Wt = list(struct.unpack('>16I', pad2))
            for tt in range(16, max(t+1, 17)):
                if tt >= len(Wt):
                    Wt.append((sigma1(Wt[tt-2]) + Wt[tt-7] + sigma0(Wt[tt-15]) + Wt[tt-16]) & M32)
            if t < len(Wt):
                vals.add(Wt[t])

        n_unique = len(vals)
        depends = "VARIES" if n_unique > 1 else "CONST"
        print(f"  W[{t:2d}]: {n_unique:3d} unique values → {depends}")

    # When does W[t] first depend on input?
    print(f"\nFirst input-dependent schedule word after W[0]:")
    for t in range(1, 64):
        vals = set()
        for byte_val in range(256):
            msg2 = bytes([byte_val])
            pad2 = msg2 + b'\x80' + b'\x00' * 54 + struct.pack('>Q', 8)
            Wt = list(struct.unpack('>16I', pad2))
            for tt in range(16, t+1):
                Wt.append((sigma1(Wt[tt-2]) + Wt[tt-7] + sigma0(Wt[tt-15]) + Wt[tt-16]) & M32)
            vals.add(Wt[t])
        if len(vals) > 1:
            print(f"  W[{t}]: {len(vals)} unique values")
            print(f"    W[{t}] = σ₁(W[{t-2}]) + W[{t-7}] + σ₀(W[{t-15}]) + W[{t-16}]")
            deps = []
            if t-2 == 0: deps.append(f"σ₁(W[0])")
            if t-7 == 0: deps.append(f"W[0]")
            if t-15 == 0: deps.append(f"σ₀(W[0])")
            if t-16 == 0: deps.append(f"W[0]")
            if deps:
                print(f"    Input enters via: {', '.join(deps)}")
            break

    # ============ THE DUAL VIEW ============
    print(f"\n{'='*70}")
    print("THE DUAL VIEW: Forward ramp meets backward ramp")
    print("=" * 70)
    print(f"""
  FORWARD (from message):
    R=0: T1 = CONST + W[0]           → LINEAR in input (degree 1)
         Only a,e change. 6 of 8 state vars = IV (constant).
         The input byte occupies bits 24-31 of W[0].

    R=1: T1 = f(W[0])                → DEGREE 2 (Ch squares it)
         Now a,b,e,f have input. c,d,g,h still = shifted IV.

    R=2: T1 = f(W[0])                → DEGREE 4
         Six vars have input dependency.

    R=3: T1 = f(W[0])                → DEGREE 8 (SATURATED)
         All 8 vars infected. 50% density reached.

  BACKWARD (from hash):
    R=63: T1,T2 known from hash      → VALUES known, but as
          functions of input, they're at 50% density (random).

    R=62: T1,T2 known                → Same.
    R=61: T1,T2 known, h=known (your observation!)
    R=60: T1,T2 known
    R=59: T1,T2 known

  THE STRUCTURE:
    Forward: degree DOUBLES each round (1→2→4→8→saturated)
    This means round 0 is LINEAR, round 1 is QUADRATIC.

    For ASCII inputs (95 values out of 256):
    - The linear round (R=0) has only 95 possible T1 values
    - The quadratic round (R=1) has 95 possible T1 values
    - The degree-4 round (R=2) STILL has only 95 possible values
      (because we only have 95 inputs regardless of degree)

    So the entropy is CAPPED at log2(95) ≈ 6.6 bits per byte,
    no matter how high the polynomial degree grows.
    The degree just determines the SHAPE of the mapping,
    not the number of distinct outputs.
""")

if __name__ == "__main__":
    main()
