#!/usr/bin/env python3
"""
SHA-256 backward walk with U (= a_before_63) as the single brute-force target.

Key insight: If we guess U (one uint32), the entire backward walk CASCADES:
- Round 63: W[63] = C63 - U
- Round 62: needs V and W[62] — but we also need a second guess
- Actually, let's trace EXACTLY how far a single U guess takes us.

The real question: does guessing U give us enough to unwind the FULL 8-round
backward walk? If so, we only need 2^32 attempts on Metal.
"""

import hashlib, struct, random

M32 = 0xFFFFFFFF

def rotr(x, n): return ((x >> n) | (x << (32 - n))) & M32
def shr(x, n): return x >> n
def Sigma1(x): return rotr(x, 6) ^ rotr(x, 11) ^ rotr(x, 25)
def Sigma0(x): return rotr(x, 2) ^ rotr(x, 13) ^ rotr(x, 22)
def sigma1(x): return rotr(x, 17) ^ rotr(x, 19) ^ shr(x, 10)
def sigma0(x): return rotr(x, 7) ^ rotr(x, 18) ^ shr(x, 3)
def Ch(e, f, g): return (e & f) ^ ((~e) & g) & M32
def Maj(a, b, c): return (a & b) ^ (a & c) ^ (b & c)
def add(*args):
    s = 0
    for a in args: s = (s + a) & M32
    return s

K = [
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5,
    0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3,
    0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
    0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7,
    0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13,
    0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3,
    0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5,
    0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
    0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
]
IV = [0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
      0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19]

def sha256_compress(msg_words):
    """Full SHA-256 compression, returns final state and all intermediates."""
    W = list(msg_words) + [0]*48
    for t in range(16, 64):
        W[t] = add(sigma1(W[t-2]), W[t-7], sigma0(W[t-15]), W[t-16])
    a, b, c, d, e, f, g, h = IV
    states = [(a, b, c, d, e, f, g, h)]
    for t in range(64):
        T1 = add(h, Sigma1(e), Ch(e, f, g), K[t], W[t])
        T2 = add(Sigma0(a), Maj(a, b, c))
        h=g; g=f; f=e; e=add(d,T1); d=c; c=b; b=a; a=add(T1,T2)
        states.append((a, b, c, d, e, f, g, h))
    hash_out = [add(states[-1][i], IV[i]) for i in range(8)]
    return hash_out, states, W

def backward_walk_with_U(hash_out, U_guess):
    """Given hash output and a guess for U (= a_before_63 in unrolled form),
    try to walk backward as far as possible.

    In unrolled form:
    - a_before_63 = U_guess
    - Round 63 (r=7): T2 = Σ₀(b) + Maj(b,c,d), T1 = a - T2
    - T1[63] = a_old + Σ₁(f) + Ch(f,g,h) + K[63] + W[63]
    - So W[63] = T1[63] - U_guess - Σ₁(f) - Ch(f,g,h) - K[63]
    """
    # Recover unrolled final state
    st = [(hash_out[i] - IV[i]) & M32 for i in range(8)]
    a_f, b_f, c_f, d_f, e_f, f_f, g_f, h_f = st

    # === Step 1: Undo round 63 (r=7, modifies e and a) ===
    T2_63 = add(Sigma0(b_f), Maj(b_f, c_f, d_f))
    T1_63 = (a_f - T2_63) & M32
    e_bef = (e_f - T1_63) & M32  # e before round 63
    # a before round 63 = U_guess (our guess)

    # From addend: T1[63] = U + Σ₁(f) + Ch(f,g,h) + K[63] + W[63]
    W63 = (T1_63 - U_guess - Sigma1(f_f) - Ch(f_f, g_f, h_f) - K[63]) & M32

    # === Step 2: Undo round 62 (r=6, modifies f and b) ===
    # T2[62] = Σ₀(c) + Maj(c, d, e_bef)
    T2_62 = add(Sigma0(c_f), Maj(c_f, d_f, e_bef))
    T1_62 = (b_f - T2_62) & M32
    f_bef = (f_f - T1_62) & M32  # f before round 62
    # b before round 62 = V (unknown)

    # From addend: T1[62] = V + Σ₁(g) + Ch(g, h, U) + K[62] + W[62]
    # Ch(g, h, U) — g and h known, U is our guess → known!
    ch62 = Ch(g_f, h_f, U_guess)
    # V + W[62] = T1_62 - Σ₁(g) - ch62 - K[62]
    VpW62 = (T1_62 - Sigma1(g_f) - ch62 - K[62]) & M32
    # One equation, two unknowns (V and W[62]). Still stuck.
    # BUT WAIT — V is b_before_62.

    # === Step 3: Undo round 61 (r=5, modifies g and c) ===
    T2_61 = add(Sigma0(d_f), Maj(d_f, e_bef, f_bef))
    T1_61 = (c_f - T2_61) & M32
    g_bef = (g_f - T1_61) & M32  # g before round 61

    # From addend: T1[61] = X + Σ₁(h) + Ch(h, U, V) + K[61] + W[61]
    # h known, U known (guessed), V unknown
    # X + Ch(h, U, V) + W[61] = T1_61 - Σ₁(h) - K[61]
    # Still have V, X, W[61] as unknowns.

    # === Step 4: Undo round 60 (r=4, modifies h and d) ===
    T2_60 = add(Sigma0(e_bef), Maj(e_bef, f_bef, g_bef))
    T1_60 = (d_f - T2_60) & M32
    h_bef = (h_f - T1_60) & M32  # h before round 60

    # Now Σ₁(a_old) is in the T1 equation. a_old at round 60 = U_guess (same variable!)
    # T1[60] = d_old + Σ₁(U) + Ch(U, V, X) + K[60] + W[60]
    # d_old is unknown, U known, V unknown, X unknown

    # === Step 5: Undo round 59 (r=3, modifies a and e) ===
    T2_59 = add(Sigma0(f_bef), Maj(f_bef, g_bef, h_bef))
    T1_59 = (e_bef - T2_59) & M32
    # a_before_59 = U - T1_59... wait.
    # Round 59 sets a += T1. So a after 59 = a_before_59 + T1_59.
    # And a after 59 = a_before_60 = a_before_61 = a_before_62 = a_before_63 = U.
    # So: U = a_before_59 + T1_59
    # → a_before_59 = U - T1_59
    a_bef59 = (U_guess - T1_59) & M32

    # Round 59 also sets e = T1_59 + T2_59. So e after 59 = T1_59 + T2_59.
    # And e after 59 = e_bef (= e before round 63).
    # Check: e_bef should equal T1_59 + T2_59
    e_check = add(T1_59, T2_59)
    # This is a CONSTRAINT! If U is wrong, this check fails!

    # Wait — this check is always true by construction:
    # T1_59 = e_bef - T2_59, so T1_59 + T2_59 = e_bef. Tautology.

    # === Step 6: Undo round 58 (r=2, modifies b and f) ===
    # T2[58] = Σ₀(g_bef) + Maj(g_bef, h_bef, a_bef59)
    # g_bef: KNOWN, h_bef: KNOWN, a_bef59: KNOWN (computed above)!
    T2_58 = add(Sigma0(g_bef), Maj(g_bef, h_bef, a_bef59))
    # Round 58 sets f += T1 and b = T1+T2. After 58: f=f_bef, b=V(unknown)
    # Wait — f_bef is f before round 62. f is modified at round 58 and round 62.
    # At start of round 58, f has its value from round 54 or earlier.
    # After round 58: f = f_before_58 + T1_58
    # After round 62: f = f_after_58 + T1_62 = f_bef (which we know)...
    # No wait, round 62 sets f += T1_62 AND b = T1_62 + T2_62.
    # f_final = f_after_58 + T1_62 ... wait, is that right?
    #
    # Let me trace f's modifications:
    # f is modified at r=2 (rounds 2,10,18,26,34,42,50,58) and r=6 (rounds 6,14,22,30,38,46,54,62)
    # At r=2: f = T1+T2
    # At r=6: f += T1
    # Wait, I had it as: r=2: b += T1, f = T1+T2. r=6: f += T1, b = T1+T2.
    # So at round 58 (r=2): f = T1_58 + T2_58
    # At round 62 (r=6): f = f + T1_62 = (T1_58+T2_58) + T1_62

    # But f_bef = f before round 62 = f after round 58 = T1_58 + T2_58 (if no other mod between 58 and 62)
    # Round 59 (r=3): modifies a, e — NOT f. ✓
    # Round 60 (r=4): modifies h, d — NOT f. ✓
    # Round 61 (r=5): modifies g, c — NOT f. ✓
    # So yes, f_bef = f after round 58 = T1_58 + T2_58. But we don't know T1_58 yet!

    # Actually: f_bef was computed earlier as f_bef = f_final - T1_62. KNOWN.
    # And f_bef = T1_58 + T2_58 (from round 58 forward).
    # So T1_58 = f_bef - T2_58.

    T1_58 = (f_bef - T2_58) & M32
    # ^^^ This is a NEW free T1/T2 recovery! Because T2_58 uses g_bef, h_bef, a_bef59 — ALL KNOWN!

    # Now: b after round 58 = T1_58 + T2_58 = f_bef (same as the f_bef definition? No...)
    # Wait: b at round 58 is: b = T1_58 + T2_58... no.
    # r=2: b += T1, f = T1+T2.
    # b_after_58 = b_before_58 + T1_58
    # And b_after_58 = b value at start of round 59 = ... = b before round 62 = V (unknown)

    # So V = b_before_58 + T1_58 → b_before_58 = V - T1_58

    # The addend equation: T1_58 = f_old + Σ₁(c_old) + Ch(c_old, d_old, e_old) + K[58] + W[58]
    # What are c_old, d_old, e_old at start of round 58?
    # c is modified at r=1 (rounds 57) and r=5 (rounds 61)
    # At start of 58: c = c after round 57.
    # d is modified at r=0 (round 56) and r=4 (round 60)
    # At start of 58: d = d after round 56.
    # e is modified at r=3 (round 59) and r=7 (round 63)
    # At start of 58: e = e before round 59. That's e_old_59 which we haven't computed.
    #
    # e at start of 58 = e at start of 59 (since e not modified at round 58, r=2)
    # = e_before_59 = ???
    # Round 59 sets e = T1_59 + T2_59 = e_bef (known). But e_before_59 is DIFFERENT.
    # e_before_59 is the value BEFORE round 59 modifies it.
    # Hmm, when was e last set before round 59? At round 55 (r=7): e += T1.
    # So e at start of 58 = e after round 55. Unknown.

    print(f"=== Backward Walk with U Guess ===")
    print(f"U = a_before_63 = {hex(U_guess)}")
    print()

    # Report what we got for free
    results = {
        'T1_63': T1_63, 'T2_63': T2_63, 'W63': W63,
        'T1_62': T1_62, 'T2_62': T2_62, 'VpW62': VpW62,
        'T1_61': T1_61, 'T2_61': T2_61,
        'T1_60': T1_60, 'T2_60': T2_60,
        'T1_59': T1_59, 'T2_59': T2_59,
        'T1_58': T1_58, 'T2_58': T2_58,
        'e_bef': e_bef, 'f_bef': f_bef, 'g_bef': g_bef,
        'h_bef': h_bef, 'a_bef59': a_bef59,
    }

    print(f"Known T1/T2 values:")
    for t in [63, 62, 61, 60, 59, 58]:
        print(f"  Round {t}: T1={hex(results[f'T1_{t}'])}, T2={hex(results[f'T2_{t}'])}")

    print(f"\nRecovered W values:")
    print(f"  W[63] = {hex(W63)}")

    print(f"\nRecovered state values:")
    print(f"  e_before_63 = {hex(e_bef)}")
    print(f"  f_before_62 = {hex(f_bef)}")
    print(f"  g_before_61 = {hex(g_bef)}")
    print(f"  h_before_60 = {hex(h_bef)}")
    print(f"  a_before_59 = {hex(a_bef59)}")

    print(f"\n  TOTAL: 6 T1/T2 pairs (was 5) + W[63] + 5 state values")
    print(f"  The U guess bought us: +1 T1/T2 (round 58) + W[63] + a_before_59")

    return results

def test_backward_walk():
    """Test with known message — verify U guess produces correct cascade."""
    random.seed(42)
    msg = [random.randint(0, M32) for _ in range(16)]
    hash_out, states, W = sha256_compress(msg)

    print("=== Forward Computation (ground truth) ===")

    # The correct U value: a_before_63 in unrolled form
    # In unrolled form at round 63 (r=7), a is set to T1+T2.
    # a_before_63 is a's value from after round 59 (last time a was modified before 63).
    # Round 59 (r=3) sets a += T1. So after round 59, a has a specific value.
    # Since rounds 60, 61, 62 don't modify a, a_before_63 = a_after_59.

    # In the standard form, we need to figure out which state variable
    # corresponds to unrolled 'a' at round 63.
    # In round 63 (r=7): T1 = a + Σ₁(f) + Ch(f,g,h) + K + W
    # Standard form: T1 = h_63 + Σ₁(e_63) + Ch(e_63,f_63,g_63) + K + W
    # So unrolled a at round 63 = standard h_63.

    # h_63 = g_62 (from standard shift)
    h_63 = states[63][7]  # state at time 63, h variable
    print(f"h_63 (= correct U) = {hex(h_63)}")

    # Now let's verify our backward walk gives correct results
    results = backward_walk_with_U(hash_out, h_63)

    # Check W[63]
    print(f"\n=== Verification ===")
    print(f"W[63]: computed={hex(results['W63'])}, actual={hex(W[63])}, match: {results['W63']==W[63]}")

    # Check T1/T2 against forward computation
    # Need to compute T1/T2 from forward pass
    a, b, c, d, e, f, g, h = IV
    t1v = []
    t2v = []
    for t in range(64):
        T1 = add(h, Sigma1(e), Ch(e, f, g), K[t], W[t])
        T2 = add(Sigma0(a), Maj(a, b, c))
        t1v.append(T1)
        t2v.append(T2)
        h=g; g=f; f=e; e=add(d,T1); d=c; c=b; b=a; a=add(T1,T2)

    for t in [63, 62, 61, 60, 59, 58]:
        t1_ok = results[f'T1_{t}'] == t1v[t]
        t2_ok = results[f'T2_{t}'] == t2v[t]
        print(f"Round {t}: T1 {'✓' if t1_ok else '✗'}, T2 {'✓' if t2_ok else '✗'}")

    # Now try with a WRONG U guess
    print(f"\n=== Wrong U Guess (random) ===")
    wrong_U = random.randint(0, M32)
    results_wrong = backward_walk_with_U(hash_out, wrong_U)
    print(f"\nW[63] with wrong U: {hex(results_wrong['W63'])} (should be {hex(W[63])})")
    print(f"Match: {results_wrong['W63'] == W[63]}")

    # How do we DETECT a wrong guess?
    print(f"\n=== Detection Strategy ===")
    print(f"With correct U, W[63] must be consistent with W[0..15]:")
    print(f"  W[63] = σ₁(W[61]) + W[56] + σ₀(W[48]) + W[47]")
    print(f"  All W[16+] are linear combos of W[0..15]")
    print(f"  If we had even ONE more W[t] value, we could cross-check.")

    # Can we get W[62]?
    # V + W[62] = VpW62 (known for correct U)
    # V = b_before_62. b is modified at round 58 (r=2) and round 62 (r=6).
    # b_before_62 = b after round 58 = b_before_58 + T1_58 (from round 58's b += T1)
    # Wait, r=2 is: b += T1, f = T1+T2. So b after 58 = b_before_58 + T1_58.
    # We know T1_58 (from the extended backward walk with U guess).
    # But b_before_58 is unknown...

    # b was last set before round 58 at round 54 (r=6): b = T1_54 + T2_54.
    # That's too far back.

    # Can we get another constraint?
    # The addend equation for round 59:
    # T1[59] = e_old_59 + Σ₁(b_old_59) + Ch(b_old_59, c_old_59, d_old_59) + K[59] + W[59]
    # e_old_59: e at start of round 59. e was set at round 55 (r=7): e += T1_55. Unknown.
    # b_old_59: b at start of 59 = b after 58 = V. Unknown.
    # So this equation has V, W[59], and several other unknowns. Can't isolate.

    print(f"\n=== What One U Guess Gets Us ===")
    print(f"✓ 6 T1/T2 pairs (rounds 58-63) — was 5 without guess")
    print(f"✓ W[63] directly")
    print(f"✓ 5 state values recovered")
    print(f"✓ From eq 63: U+W[63]=C → W[63] determined by U alone")
    print(f"✗ Still can't determine V (= b_before_62) independently")
    print(f"✗ Need a SECOND guess for V to get W[62]")
    print(f"")
    print(f"Two guesses (U + V) = 2^64 attempts → still too many")
    print(f"One guess (U) = 2^32 → feasible on Metal, but need a validation check")
    print(f"")
    print(f"Validation: For each U candidate, W[63] is determined.")
    print(f"W[63] must be a valid output of the message schedule.")
    print(f"That means W[63] = σ₁(W[61]) + W[56] + σ₀(W[48]) + W[47]")
    print(f"But we don't know W[61], W[56], W[48], W[47] independently.")
    print(f"")
    print(f"HOWEVER: if we combine with the 3 addend equations")
    print(f"(rounds 63, 62, 61) which are all LINEAR in unknowns")
    print(f"when U is fixed — we get constraints on V, X, W[61..63].")
    print(f"Since W[61..63] are linear in W[0..15], and V,X are")
    print(f"determined by W[0..15], these are 3 equations in 16 unknowns.")

if __name__ == "__main__":
    test_backward_walk()
