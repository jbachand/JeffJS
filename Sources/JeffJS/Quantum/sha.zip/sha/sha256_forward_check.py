#!/usr/bin/env python3
"""
SHA-256 forward validation of U guess.

Key insight from user: "we can roll it forward to the hash."

The backward walk with U gives us state values. If we can determine the
COMPLETE state at some round < 63, we can run forward and check against
the hash. The forward check at that round ISN'T tautological because the
W values weren't constructed to satisfy it.

Question: at which round do we have the most complete state? Can we get
all 8 variables at ANY round before 63?
"""

import hashlib, struct, random

M32 = 0xFFFFFFFF

def rotr(x, n): return ((x >> n) | (x << (32 - n))) & M32
def shr(x, n): return x >> n
def Sigma1(x): return rotr(x, 6) ^ rotr(x, 11) ^ rotr(x, 25)
def Sigma0(x): return rotr(x, 2) ^ rotr(x, 13) ^ rotr(x, 22)
def sigma1(x): return rotr(x, 17) ^ rotr(x, 19) ^ shr(x, 10)
def sigma0(x): return rotr(x, 7) ^ rotr(x, 18) ^ shr(x, 3)
def Ch(e, f, g): return (e & f) ^ ((~e) & g) & M32
def Maj(a, b, c): return (a & b) ^ (a & c) ^ (b & c)
def add(*args):
    s = 0
    for a in args: s = (s + a) & M32
    return s

K = [
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5,
    0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3,
    0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
    0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7,
    0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13,
    0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3,
    0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5,
    0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
    0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
]
IV = [0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
      0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19]

def sha256_compress(msg_words):
    W = list(msg_words) + [0]*48
    for t in range(16, 64):
        W[t] = add(sigma1(W[t-2]), W[t-7], sigma0(W[t-15]), W[t-16])
    a, b, c, d, e, f, g, h = IV
    states = [(a, b, c, d, e, f, g, h)]
    t1_vals, t2_vals = [], []
    for t in range(64):
        T1 = add(h, Sigma1(e), Ch(e, f, g), K[t], W[t])
        T2 = add(Sigma0(a), Maj(a, b, c))
        t1_vals.append(T1); t2_vals.append(T2)
        h=g; g=f; f=e; e=add(d,T1); d=c; c=b; b=a; a=add(T1,T2)
        states.append((a, b, c, d, e, f, g, h))
    hash_out = [add(states[-1][i], IV[i]) for i in range(8)]
    return hash_out, states, t1_vals, t2_vals, W

def sha256_unrolled_forward(state, W_slice, round_start, n_rounds):
    """Run n_rounds of unrolled SHA-256 forward from given state."""
    a, b, c, d, e, f, g, h = state
    for i in range(n_rounds):
        t = round_start + i
        r = t % 8
        w = W_slice[i]
        if r == 0:
            T1 = add(h, Sigma1(e), Ch(e, f, g), K[t], w)
            T2 = add(Sigma0(a), Maj(a, b, c))
            d = add(d, T1); h = add(T1, T2)
        elif r == 1:
            T1 = add(g, Sigma1(d), Ch(d, e, f), K[t], w)
            T2 = add(Sigma0(h), Maj(h, a, b))
            c = add(c, T1); g = add(T1, T2)
        elif r == 2:
            T1 = add(f, Sigma1(c), Ch(c, d, e), K[t], w)
            T2 = add(Sigma0(g), Maj(g, h, a))
            b = add(b, T1); f = add(T1, T2)
        elif r == 3:
            T1 = add(e, Sigma1(b), Ch(b, c, d), K[t], w)
            T2 = add(Sigma0(f), Maj(f, g, h))
            a = add(a, T1); e = add(T1, T2)
        elif r == 4:
            T1 = add(d, Sigma1(a), Ch(a, b, c), K[t], w)
            T2 = add(Sigma0(e), Maj(e, f, g))
            h = add(h, T1); d = add(T1, T2)
        elif r == 5:
            T1 = add(c, Sigma1(h), Ch(h, a, b), K[t], w)
            T2 = add(Sigma0(d), Maj(d, e, f))
            g = add(g, T1); c = add(T1, T2)
        elif r == 6:
            T1 = add(b, Sigma1(g), Ch(g, h, a), K[t], w)
            T2 = add(Sigma0(c), Maj(c, d, e))
            f = add(f, T1); b = add(T1, T2)
        elif r == 7:
            T1 = add(a, Sigma1(f), Ch(f, g, h), K[t], w)
            T2 = add(Sigma0(b), Maj(b, c, d))
            e = add(e, T1); a = add(T1, T2)
    return (a, b, c, d, e, f, g, h)

def full_backward_walk(hash_out, U_guess):
    """Walk backward from hash with U guess. Return all recovered values."""
    st = [(hash_out[i] - IV[i]) & M32 for i in range(8)]
    a_f, b_f, c_f, d_f, e_f, f_f, g_f, h_f = st

    # Undo round 63 (r=7, mods e,a)
    T2_63 = add(Sigma0(b_f), Maj(b_f, c_f, d_f))
    T1_63 = (a_f - T2_63) & M32
    e_bef = (e_f - T1_63) & M32

    W63 = (T1_63 - U_guess - Sigma1(f_f) - Ch(f_f, g_f, h_f) - K[63]) & M32

    # Undo round 62 (r=6, mods f,b)
    T2_62 = add(Sigma0(c_f), Maj(c_f, d_f, e_bef))
    T1_62 = (b_f - T2_62) & M32
    f_bef = (f_f - T1_62) & M32

    # Undo round 61 (r=5, mods g,c)
    T2_61 = add(Sigma0(d_f), Maj(d_f, e_bef, f_bef))
    T1_61 = (c_f - T2_61) & M32
    g_bef = (g_f - T1_61) & M32

    # Undo round 60 (r=4, mods h,d)
    T2_60 = add(Sigma0(e_bef), Maj(e_bef, f_bef, g_bef))
    T1_60 = (d_f - T2_60) & M32
    h_bef = (h_f - T1_60) & M32

    # Undo round 59 (r=3, mods a,e)
    T2_59 = add(Sigma0(f_bef), Maj(f_bef, g_bef, h_bef))
    T1_59 = (e_bef - T2_59) & M32
    a_bef59 = (U_guess - T1_59) & M32

    # Undo round 58 (r=2, mods b,f)
    T2_58 = add(Sigma0(g_bef), Maj(g_bef, h_bef, a_bef59))
    T1_58 = (f_bef - T2_58) & M32

    # Now: at the START of round 58, which vars do we know?
    # a = a_bef59 (known with U guess — a not modified by round 58)
    # b = ? (b is modified by round 58: b += T1)
    # c = ? (c was set at round 57)
    # d = ? (d was set at round 56)
    # e = ? (e was set at round 55)
    # f = f_bef = T1_58 + T2_58? No, f is SET by round 58 to T1+T2.
    #     f before round 58 = f_before_58 (unknown).
    #     f after round 58 = T1_58 + T2_58 ... wait.
    # r=2: b += T1, f = T1+T2. So f_after_58 = T1_58 + T2_58.
    # And f_after_58 = f_bef (the value before round 62).
    # So f_bef = T1_58 + T2_58 (which is how we computed T1_58).

    # Undo round 57 (r=1, mods c,g)
    # T2_57 = Σ₀(h_bef) + Maj(h_bef, a_bef59, b_bef58)
    # But b_bef58 = b at start of round 58 = b_before_58.
    # b was modified at round 58 (b += T1_58) and round 62 (b = T1_62+T2_62).
    # b_after_58 = b_before_58 + T1_58
    # b_after_58 = b at start of round 59 = ... = b at start of round 62 = b_before_62
    # b_final = T1_62 + T2_62 (from round 62's b = T1+T2)
    # Wait, that's wrong. r=6: f += T1, b = T1+T2. So b_final = T1_62 + T2_62.
    # And b_before_62 = b_after_58 + ... no, b is not modified between rounds 58 and 62.
    # b is modified at r=2 (round 58) and r=6 (round 62). So b_after_58 = b_before_62 = V.
    # And V = b_before_58 + T1_58.
    # We don't know b_before_58.

    # So we can't undo round 57 because T2 needs b_before_58 (= V - T1_58),
    # and V is unknown.

    # HOWEVER: what if we guess V too? Then 2^64 total guesses.
    # Or: what if we can extract V from somewhere else?

    return {
        'T1': {63:T1_63, 62:T1_62, 61:T1_61, 60:T1_60, 59:T1_59, 58:T1_58},
        'T2': {63:T2_63, 62:T2_62, 61:T2_61, 60:T2_60, 59:T2_59, 58:T2_58},
        'W63': W63,
        'state': {
            'a_before_63': U_guess,
            'e_before_63': e_bef,
            'f_before_62': f_bef,
            'g_before_61': g_bef,
            'h_before_60': h_bef,
            'a_before_59': a_bef59,
        },
        'final': st,
    }

def test_forward_check():
    """Test: can we validate U by running forward and checking the hash?"""
    random.seed(42)
    msg = [random.randint(0, M32) for _ in range(16)]
    hash_out, states, t1v, t2v, W = sha256_compress(msg)

    # Correct U
    correct_U = states[63][7]  # h at state 63 = unrolled a_before_63
    # Wait — need to verify this mapping
    # In standard form at time 63: state = (a_63, b_63, c_63, d_63, e_63, f_63, g_63, h_63)
    # In unrolled form, round 63 (r=7): T1 = a + Σ₁(f) + Ch(f,g,h) + K + W
    # Standard: T1 = h_63 + Σ₁(e_63) + Ch(e_63,f_63,g_63) + K + W
    # So unrolled 'a' at round 63 = standard h_63. Which is states[63][7].
    # BUT in the unrolled form, 'a' has been cycling through assignments.
    # Let me verify using the unrolled simulation.

    # Actually, let me just compute it directly from the backward walk.
    # From the backward walk: a_before_63 is what satisfies:
    # T1_63 = a_before_63 + Σ₁(f_final) + Ch(f_final, g_final, h_final) + K[63] + W[63]
    # In standard form: T1_63 = h_63 + Σ₁(e_63) + Ch(e_63,f_63,g_63) + K[63] + W[63]
    # Standard: h_63 = states[63][7], e_63 = states[63][4], f_63 = states[63][5], g_63 = states[63][6]
    # Unrolled final: f = states[64][5], g = states[64][6], h = states[64][7]
    # In unrolled form, Σ₁(f_final) and Ch(f_final,g_final,h_final) use the FINAL unrolled vars.
    # Standard e_63 = f_64 (from shift). So:
    # Final unrolled f = standard f_64 = standard e_63. ✓
    # Final unrolled g = standard g_64 = standard f_63. ✓
    # Final unrolled h = standard h_64 = standard g_63. ✓
    # So unrolled a_before_63 = standard h_63. ✓

    correct_U = states[63][7]  # standard h_63

    print("=== Forward Validation Test ===")
    print(f"Correct U = {hex(correct_U)}")
    print(f"Hash = {' '.join(hex(x) for x in hash_out)}")

    # Run backward walk with correct U
    bw = full_backward_walk(hash_out, correct_U)
    print(f"\nW[63] recovered: {hex(bw['W63'])}, actual: {hex(W[63])}, match: {bw['W63']==W[63]}")

    # === THE KEY TEST ===
    # What state do we have at each round?
    # At start of round 63 in unrolled form, we need all 8 vars.
    # Let me map unrolled to standard at each step.

    # Unrolled state at start of round 63:
    # a = U (guessed), b = b_final, c = c_final, d = d_final
    # e = e_bef, f = f_final, g = g_final, h = h_final
    state_63_unrolled = (
        correct_U,       # a
        bw['final'][1],  # b (= b_final)
        bw['final'][2],  # c
        bw['final'][3],  # d
        bw['state']['e_before_63'],  # e
        bw['final'][5],  # f
        bw['final'][6],  # g
        bw['final'][7],  # h
    )
    print(f"\nComplete state at start of round 63: ✓ (all 8 known)")

    # Run round 63 forward
    result_63 = sha256_unrolled_forward(state_63_unrolled, [W[63]], 63, 1)
    final_from_hash = tuple(bw['final'])
    print(f"Forward round 63: match={result_63 == final_from_hash}")
    print(f"  (This is TAUTOLOGICAL — W[63] was defined to make it work)")

    # State at start of round 62:
    # a = U (not modified by round 62)
    # b = V (UNKNOWN — modified by round 62)
    # c = c_final (not modified by 62 or 63)
    # d = d_final
    # e = e_bef (not modified by round 62)
    # f = f_bef (COMPUTED, not unknown)
    # g = g_final
    # h = h_final
    V = states[62][7]  # standard h_62 = unrolled b_before_62
    print(f"\nState at round 62: 7/8 known, missing b (= V)")
    print(f"  If V guessed: state complete → forward through 2 rounds → check")

    state_62_unrolled = (
        correct_U,
        V,  # guessed
        bw['final'][2],
        bw['final'][3],
        bw['state']['e_before_63'],
        bw['state']['f_before_62'],
        bw['final'][6],
        bw['final'][7],
    )
    result_62 = sha256_unrolled_forward(state_62_unrolled, [W[62], W[63]], 62, 2)
    print(f"Forward rounds 62-63: match={result_62 == final_from_hash}")

    # Now the REAL question: is the forward check at round 62 still tautological?
    # W[62] was NOT derived from V. V is a NEW guess.
    # The check: run forward with (state_62, W[62], W[63]) → should get hash.
    # If V is wrong, the forward result will NOT match the hash.

    # TEST WITH WRONG V
    wrong_V = (V + 1) & M32
    state_62_wrong = (
        correct_U,
        wrong_V,
        bw['final'][2],
        bw['final'][3],
        bw['state']['e_before_63'],
        bw['state']['f_before_62'],
        bw['final'][6],
        bw['final'][7],
    )
    result_62_wrong = sha256_unrolled_forward(state_62_wrong, [W[62], W[63]], 62, 2)
    print(f"Forward with wrong V: match={result_62_wrong == final_from_hash}")
    print(f"  → Wrong V is DETECTABLE by forward check! ✓")

    # But we need W[62] from the message to run forward...
    # UNLESS: W[62] can be derived from the backward walk once we know V.
    # From round 62 addend: V + W[62] + (known terms) = T1_62
    # → W[62] = T1_62 - V - Σ₁(g) - Ch(g,h,U) - K[62]

    W62_derived = (bw['T1'][62] - V - Sigma1(bw['final'][6]) -
                   Ch(bw['final'][6], bw['final'][7], correct_U) - K[62]) & M32
    print(f"\nW[62] from V: {hex(W62_derived)}, actual: {hex(W[62])}, match: {W62_derived==W[62]}")

    # So with U+V guessed:
    # - W[63] from U (backward eq 63)
    # - W[62] from V (backward eq 62)
    # - All 8 state vars at round 62: known
    # - Forward from round 62 through 63: uses W[62], W[63]
    # - Check against hash

    # The forward check IS real at round 62 because V determines W[62],
    # and the check is whether this W[62] + V + state produces the hash.
    # If V is wrong, W[62] is wrong, and the hash won't match.

    # BUT: with U determining W[63], and V determining W[62],
    # and both W values being linear functions of W[0..15],
    # the forward check is really: does there exist W[0..15] such that
    # schedule(W[0..15]) produces these W[62], W[63], AND the forward
    # computation from state_62 through W[62], W[63] gives the hash?

    # The forward computation from state_62 IS the tautology
    # if W values are derived from the backward walk.
    # Let me verify:

    result_62_bw = sha256_unrolled_forward(state_62_unrolled, [W62_derived, bw['W63']], 62, 2)
    print(f"\nForward with backward-derived W values: match={result_62_bw == final_from_hash}")
    print(f"  → STILL tautological? Checking with wrong V...")

    wrong_V2 = (V + 12345) & M32
    W62_wrong = (bw['T1'][62] - wrong_V2 - Sigma1(bw['final'][6]) -
                 Ch(bw['final'][6], bw['final'][7], correct_U) - K[62]) & M32
    state_62_wrong2 = (
        correct_U,
        wrong_V2,
        bw['final'][2],
        bw['final'][3],
        bw['state']['e_before_63'],
        bw['state']['f_before_62'],
        bw['final'][6],
        bw['final'][7],
    )
    result_wrong2 = sha256_unrolled_forward(state_62_wrong2, [W62_wrong, bw['W63']], 62, 2)
    print(f"Forward with wrong V + its derived W[62]: match={result_wrong2 == final_from_hash}")

    if result_wrong2 == final_from_hash:
        print("  → TAUTOLOGICAL at round 62 too! V cancels in the forward path.")
    else:
        print("  → NOT tautological! Wrong V is detectable!")

    # Let's check MORE carefully. Round 62 (r=6):
    # T1 = b + Σ₁(g) + Ch(g,h,a) + K + W[62]
    # With b=V, W[62] derived from V:
    # T1 = V + Σ₁(g) + Ch(g,h,U) + K + (T1_62 - V - Σ₁(g) - Ch(g,h,U) - K)
    #     = T1_62
    # So T1 = T1_62 regardless of V. TAUTOLOGICAL for round 62.
    # Then T2 = Σ₀(c) + Maj(c,d,e) — doesn't use V at all.
    # Updates: f += T1, b = T1+T2. Both determined by T1_62 and T2_62.
    # After round 62: same as backward walk values. Tautological.

    # Round 63 (r=7):
    # T1 = a + Σ₁(f) + Ch(f,g,h) + K + W[63]
    # With a = new_a_after_62 = T1_62 + T2_62 = b_final (same as backward walk)
    # And W[63] from U. So T1 = T1_63. Tautological.

    print(f"\n=== CONCLUSION ===")
    print(f"When W values are derived from the backward walk,")
    print(f"the forward check is ALWAYS tautological.")
    print(f"V cancels: T1 = V + ... + (T1_known - V - ...) = T1_known.")
    print()
    print(f"The check is only REAL if W values come from the MESSAGE SCHEDULE,")
    print(f"not from the backward walk equations.")
    print()
    print(f"To make the check real, we need to:")
    print(f"1. Use backward walk to get W[63] (from U)")
    print(f"2. INVERT the schedule to get W[0..15] candidates")
    print(f"3. Compute W[0..63] from the schedule")
    print(f"4. Run SHA-256 forward with W[0..63]")
    print(f"5. Check if the hash matches")
    print()
    print(f"But step 2 needs 16 W values, and we only have 1 (W[63]).")
    print(f"15 degrees of freedom remain.")

    # === SCHEDULE INVERSION ===
    # W[63] is a specific linear function of W[0..15].
    # Can we express it?
    print(f"\n=== Schedule Dependency of W[63] ===")

    # Build the schedule expansion matrix
    # W[t] for t >= 16 is a linear combination of W[0..15]
    # (over Z/2^32, with σ₀ and σ₁ mixing)
    # Actually σ₀ and σ₁ are LINEAR over Z/2^32? No — they use XOR and shift.
    # σ₀(x) = RotR(x,7) ⊕ RotR(x,18) ⊕ ShR(x,3)
    # This is a LINEAR operation over GF(2)^32 (bitwise), but NOT over Z/2^32.
    # The schedule uses mod-2^32 ADDITION: W[t] = σ₁(W[t-2]) + W[t-7] + σ₀(W[t-15]) + W[t-16]
    # So it's MIXED: σ operations are GF(2)-linear, + is integer-linear.
    # The schedule IS linear over Z/2^32 if we view σ as a matrix multiplication
    # over Z/2^32... but σ uses XOR, not mod-add.

    # Actually: σ₀ and σ₁ are linear over GF(2)^32 (bitwise).
    # The addition is over Z/2^32 (with carry).
    # So the schedule is NOT linear over any single algebraic structure.

    # But we can still track: given W[0..15], compute W[63] deterministically.
    # And given a target W[63], there are ~2^(512-32) = 2^480 valid W[0..15].

    # So knowing W[63] barely constrains the message.
    print(f"W[63] constrains ~32 of 512 message bits.")
    print(f"2^480 possible messages remain for any given W[63].")

    # === THE REAL FORWARD CHECK ===
    # For each (U, message) pair:
    #   1. Compute SHA-256(message)
    #   2. Check if it equals the target hash
    # The backward walk with U predicts W[63].
    # If the message's W[63] doesn't match, skip it.
    # This filters ~(1 - 2^-32) ≈ 99.99999998% of messages.
    # But there are 2^480 messages per W[63] value.
    # So 2^32 U values × 2^480 messages each = 2^512 total. Worse than brute force!

    print(f"\n=== BUT WAIT: What if the message is PARTIALLY KNOWN? ===")

    # In Bitcoin mining: message is mostly fixed, only nonce (32 bits) varies.
    # W[0..15] is determined by the block header.
    # Only ONE word changes (the nonce).
    # So W[63] is an AFFINE function of the nonce (one uint32).
    # Given W[63] from U, nonce = (W[63] - offset) via schedule inversion.
    # ONE nonce per U value. Total: 2^32 SHA-256 checks.

    # Let's demonstrate:
    print(f"\nBitcoin-like scenario: only W[3] varies (simulated nonce)")
    # Fix W[0,1,2,4..15], let W[3] be the nonce.

    # Schedule: W[63] depends on all of W[0..15].
    # Specifically: W[63] = f(W[0..15]) where f involves σ₁, σ₀, and additions.
    # If only W[3] varies, W[63] = f(W[3]) + constant.

    # But f is NOT linear in W[3] because σ₀ and σ₁ are XOR-based.
    # f(W[3]) involves σ₀(W[3]) at round 18 (W[3] = W[t-15] when t=18).
    # σ₀ is bitwise linear, not integer linear. So W[63] is NOT an integer-linear
    # function of W[3].

    # However, for each W[63] candidate, we can try all 2^32 nonce values
    # and check which one produces this W[63]. That's 2^32 schedule evaluations
    # per U value = 2^64 total. Still too many.

    # OR: precompute a lookup table: nonce → W[63]. Size = 2^32 entries.
    # Then for each U, look up which nonce gives W[63]. O(1) per U.
    # Total: 2^32 table build + 2^32 lookups = 2^33 work.
    # Then for each matching (U, nonce), hash forward and check.
    # Expected matches: 2^32 (since W[63] has 2^32 values and there are 2^32 nonces,
    # roughly 1 nonce per W[63] value).
    # So: 2^32 forward hash checks.

    # TOTAL: 2^33 work vs 2^32 for brute force. No speedup.
    # The backward walk doesn't help for Bitcoin mining.

    print(f"Result: 2^32 work for backward = 2^32 for brute force. No speedup.")
    print(f"The backward walk gives INFORMATION but not COMPUTATION savings.")
    print(f"\nFor a GENERAL preimage attack:")
    print(f"  Need to determine 512 message bits")
    print(f"  Backward walk gives ~160 bits of constraints")
    print(f"  Still ~352 bits of freedom → 2^352 search space")
    print(f"  (vs 2^256 for birthday attack)")

if __name__ == "__main__":
    test_forward_check()
