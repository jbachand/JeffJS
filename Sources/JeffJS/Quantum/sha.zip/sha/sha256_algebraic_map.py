#!/usr/bin/env python3
"""
SHA-256 Algebraic Map — Strip it to the bones.

We KNOW every operation: Ch, Maj, Σ0, Σ1, rotations, additions.
The round function repeats 16 times.
Map each output bit as a GF(2) polynomial in the input bits.

Two versions:
  A) XOR-only (replace mod-add with XOR): pure GF(2), clean algebra
  B) Full (with carry chains): real SHA-256

If the additions are "masking" structure, version A will show the
underlying pattern that version B hides.

For mini-SHA (4-bit words, 2 input words = 8 bits):
  Each output bit is a polynomial in 8 variables.
  Max 256 terms. Fully tractable.
"""

import numpy as np
from itertools import product

BITS = 4
MASK = (1 << BITS) - 1
N = 1 << BITS

def rotr(x, n):
    n = n % BITS
    return ((x >> n) | (x << (BITS - n))) & MASK

def Ch(e, f, g):  return ((e & f) ^ ((e ^ MASK) & g)) & MASK
def Maj(a, b, c): return ((a & b) ^ (a & c) ^ (b & c)) & MASK
def Sigma0(a):    return (rotr(a, 1) ^ rotr(a, 2) ^ rotr(a, 3)) & MASK
def Sigma1(e):    return (rotr(e, 1) ^ rotr(e, 2) ^ rotr(e, 3)) & MASK
def sigma0(x):    return (rotr(x, 1) ^ rotr(x, 2) ^ (x >> 1)) & MASK
def sigma1(x):    return (rotr(x, 2) ^ rotr(x, 3) ^ (x >> 1)) & MASK

REAL_K = [k & MASK for k in [
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5,
    0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3,
    0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
]]
MINI_IV = [v & MASK for v in [
    0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
    0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19,
]]


def mini_sha_real(w0, w1, fixed_W, n_rounds=16):
    """Full mini-SHA with real mod-addition."""
    msg = [w0, w1] + list(fixed_W[2:])
    W = list(msg[:16])
    while len(W) < 16: W.append(0)
    for t in range(16, max(n_rounds, 16)):
        W.append((sigma1(W[t-2]) + W[t-7] + sigma0(W[t-15]) + W[t-16]) & MASK)
    a, b, c, d, e, f, g, h = MINI_IV
    for t in range(n_rounds):
        T1 = (h + Sigma1(e) + Ch(e, f, g) + REAL_K[t % len(REAL_K)] + W[t]) & MASK
        T2 = (Sigma0(a) + Maj(a, b, c)) & MASK
        h = g; g = f; f = e; e = (d + T1) & MASK
        d = c; c = b; b = a; a = (T1 + T2) & MASK
    return [(MINI_IV[i] + v) & MASK for i, v in enumerate([a,b,c,d,e,f,g,h])]


def mini_sha_xor(w0, w1, fixed_W, n_rounds=16):
    """Mini-SHA with ALL additions replaced by XOR. Pure GF(2)."""
    msg = [w0, w1] + list(fixed_W[2:])
    W = list(msg[:16])
    while len(W) < 16: W.append(0)
    for t in range(16, max(n_rounds, 16)):
        W.append(sigma1(W[t-2]) ^ W[t-7] ^ sigma0(W[t-15]) ^ W[t-16])
    a, b, c, d, e, f, g, h = MINI_IV
    for t in range(n_rounds):
        T1 = h ^ Sigma1(e) ^ Ch(e, f, g) ^ REAL_K[t % len(REAL_K)] ^ W[t]
        T2 = Sigma0(a) ^ Maj(a, b, c)
        h = g; g = f; f = e; e = d ^ T1
        d = c; c = b; b = a; a = T1 ^ T2
    return [MINI_IV[i] ^ v for i, v in enumerate([a,b,c,d,e,f,g,h])]


def compute_anf(truth_table, n_vars):
    """
    Compute Algebraic Normal Form via Möbius transform.
    truth_table[x] = output bit for input x.
    Returns list of monomial indices with coefficient 1.
    """
    n = 1 << n_vars
    anf = list(truth_table)
    for i in range(n_vars):
        step = 1 << i
        for j in range(n):
            if j & step:
                anf[j] ^= anf[j ^ step]
    # Return monomials with coefficient 1
    monomials = [j for j in range(n) if anf[j]]
    return monomials


def monomial_to_str(mono, var_names):
    """Convert monomial bitmask to string like 'x0·x2·x5'."""
    if mono == 0:
        return "1"
    bits = []
    for i, name in enumerate(var_names):
        if mono & (1 << i):
            bits.append(name)
    return "·".join(bits)


def main():
    import random
    random.seed(42)
    fixed_W = [random.getrandbits(BITS) for _ in range(16)]

    n_input = 2 * BITS  # 8 bits: W0 (4 bits) + W1 (4 bits)
    n_total = 1 << n_input  # 256

    var_names = [f"w0.{i}" for i in range(BITS)] + [f"w1.{i}" for i in range(BITS)]

    # ═══════════════════════════════════════════════════════════
    # Compute truth tables for both versions
    # ═══════════════════════════════════════════════════════════

    print("═" * 72)
    print("  SHA-256 Algebraic Map")
    print("  Each output bit as a polynomial in input bits")
    print("═" * 72)

    for version_name, sha_func in [("XOR-only (pure GF(2))", mini_sha_xor),
                                     ("Full (with carries)", mini_sha_real)]:
        print(f"\n{'═' * 72}")
        print(f"  VERSION: {version_name}")
        print(f"{'═' * 72}")

        # Build truth table: input → hash
        truth_tables = {}  # (word_idx, bit_idx) → truth_table

        for word_idx in range(8):
            for bit_idx in range(BITS):
                tt = []
                for x in range(n_total):
                    w0 = x & MASK
                    w1 = (x >> BITS) & MASK
                    h = sha_func(w0, w1, fixed_W)
                    tt.append((h[word_idx] >> bit_idx) & 1)
                truth_tables[(word_idx, bit_idx)] = tt

        # Compute ANF for each output bit
        print(f"\n  Output bit │ Degree │ Terms │ Polynomial (abbreviated)")
        print(f"  {'─'*10}─┼─{'─'*6}─┼─{'─'*5}─┼─{'─'*40}")

        total_terms = 0
        total_degree = 0
        degrees = []
        term_counts = []

        for word_idx in range(8):  # 8 hash words
            for bit_idx in range(BITS):  # 4 bits each
                tt = truth_tables[(word_idx, bit_idx)]
                monomials = compute_anf(tt, n_input)

                degree = max((bin(m).count('1') for m in monomials), default=0)
                n_terms = len(monomials)
                total_terms += n_terms
                total_degree += degree
                degrees.append(degree)
                term_counts.append(n_terms)

                # Show abbreviated polynomial
                if n_terms <= 6:
                    poly_str = " ⊕ ".join(monomial_to_str(m, var_names) for m in monomials)
                else:
                    first3 = " ⊕ ".join(monomial_to_str(m, var_names) for m in monomials[:3])
                    last1 = monomial_to_str(monomials[-1], var_names)
                    poly_str = f"{first3} ⊕ ... ⊕ {last1} ({n_terms} terms)"

                label = f"h[{word_idx}].{bit_idx}"
                print(f"  {label:<10s} │ {degree:>6d} │ {n_terms:>5d} │ {poly_str}")

        avg_degree = np.mean(degrees)
        avg_terms = np.mean(term_counts)
        max_degree = max(degrees)
        max_terms = max(term_counts)

        print(f"\n  Summary:")
        print(f"    Average degree:    {avg_degree:.1f} (max possible: {n_input})")
        print(f"    Max degree:        {max_degree}")
        print(f"    Average terms:     {avg_terms:.1f} (max possible: {n_total})")
        print(f"    Max terms:         {max_terms}")
        print(f"    Total terms:       {total_terms}")

        # Degree distribution
        from collections import Counter
        deg_dist = Counter(degrees)
        print(f"    Degree distribution: {dict(sorted(deg_dist.items()))}")

    # ═══════════════════════════════════════════════════════════
    # Compare: how does degree grow with rounds?
    # ═══════════════════════════════════════════════════════════
    print(f"\n{'═' * 72}")
    print(f"  DEGREE GROWTH: How fast does algebraic degree increase with rounds?")
    print(f"  XOR-only vs Full — does the carry chain add complexity?")
    print(f"{'═' * 72}")

    print(f"\n  {'Rounds':>6s} │ {'XOR degree':>10s} │ {'XOR terms':>10s} │ {'Full degree':>11s} │ {'Full terms':>10s}")
    print(f"  {'─'*6}─┼─{'─'*10}─┼─{'─'*10}─┼─{'─'*11}─┼─{'─'*10}")

    for n_rounds in [1, 2, 3, 4, 6, 8, 12, 16]:
        for version_name, sha_func in [("xor", mini_sha_xor), ("full", mini_sha_real)]:
            max_deg = 0
            max_terms = 0
            for word_idx in [0]:  # just first hash word
                for bit_idx in range(BITS):
                    tt = []
                    for x in range(n_total):
                        w0 = x & MASK
                        w1 = (x >> BITS) & MASK
                        h = sha_func(w0, w1, fixed_W, n_rounds)
                        tt.append((h[word_idx] >> bit_idx) & 1)
                    monomials = compute_anf(tt, n_input)
                    deg = max((bin(m).count('1') for m in monomials), default=0)
                    max_deg = max(max_deg, deg)
                    max_terms = max(max_terms, len(monomials))

            if version_name == "xor":
                xor_deg, xor_terms = max_deg, max_terms
            else:
                full_deg, full_terms = max_deg, max_terms

        print(f"  {n_rounds:>6d} │ {xor_deg:>10d} │ {xor_terms:>10d} │ {full_deg:>11d} │ {full_terms:>10d}")

    # ═══════════════════════════════════════════════════════════
    # Shared monomials: do output bits share common terms?
    # If yes → the polynomial system has common factors → factorable
    # ═══════════════════════════════════════════════════════════
    print(f"\n{'═' * 72}")
    print(f"  SHARED STRUCTURE: Do output bits share monomials?")
    print(f"  Common factors = factorable = solvable")
    print(f"{'═' * 72}")

    # Recompute for XOR version (cleaner structure)
    all_monomials = {}
    for word_idx in range(8):
        for bit_idx in range(BITS):
            tt = []
            for x in range(n_total):
                w0 = x & MASK
                w1 = (x >> BITS) & MASK
                h = mini_sha_xor(w0, w1, fixed_W)
                tt.append((h[word_idx] >> bit_idx) & 1)
            monomials = set(compute_anf(tt, n_input))
            all_monomials[(word_idx, bit_idx)] = monomials

    # Count how many output bits each monomial appears in
    mono_freq = Counter()
    for mset in all_monomials.values():
        for m in mset:
            mono_freq[m] += 1

    # Most shared monomials
    most_shared = mono_freq.most_common(15)
    n_outputs = 8 * BITS

    print(f"\n  Most shared monomials (XOR version, {n_outputs} output bits):")
    print(f"  {'Monomial':<30s} │ {'Degree':>6s} │ {'Appears in':>10s}")
    print(f"  {'─'*30}─┼─{'─'*6}─┼─{'─'*10}")
    for mono, freq in most_shared:
        name = monomial_to_str(mono, var_names)
        deg = bin(mono).count('1')
        pct = freq * 100 / n_outputs
        print(f"  {name:<30s} │ {deg:>6d} │ {freq:>4d}/{n_outputs} ({pct:.0f}%)")

    # Uniqueness: how many monomials appear in only ONE output bit?
    unique_monos = sum(1 for m, f in mono_freq.items() if f == 1)
    shared_monos = sum(1 for m, f in mono_freq.items() if f > 1)
    print(f"\n  Unique monomials (1 output only): {unique_monos}")
    print(f"  Shared monomials (2+ outputs):    {shared_monos}")
    print(f"  Share ratio: {shared_monos/(unique_monos+shared_monos)*100:.1f}%")

    # ═══════════════════════════════════════════════════════════
    # The key test: same analysis with RANDOM K vs REAL K
    # ═══════════════════════════════════════════════════════════
    print(f"\n{'═' * 72}")
    print(f"  K-CONSTANT EFFECT: Real K vs Random K on algebraic structure")
    print(f"  If real K creates simpler polynomials → K IS the trapdoor")
    print(f"{'═' * 72}")

    random.seed(99)
    k_random = [random.getrandbits(BITS) for _ in range(16)]

    for k_name, k_vals in [("Real K", REAL_K), ("Random K", k_random), ("K=0", [0]*16)]:
        def sha_with_k(w0, w1, fixed, n_rounds=16):
            msg = [w0, w1] + list(fixed[2:])
            W = list(msg[:16])
            while len(W) < 16: W.append(0)
            for t in range(16, max(n_rounds, 16)):
                W.append(sigma1(W[t-2]) ^ W[t-7] ^ sigma0(W[t-15]) ^ W[t-16])
            a, b, c, d, e, f, g, h = MINI_IV
            for t in range(n_rounds):
                T1 = h ^ Sigma1(e) ^ Ch(e, f, g) ^ k_vals[t % len(k_vals)] ^ W[t]
                T2 = Sigma0(a) ^ Maj(a, b, c)
                h = g; g = f; f = e; e = d ^ T1
                d = c; c = b; b = a; a = T1 ^ T2
            return [MINI_IV[i] ^ v for i, v in enumerate([a,b,c,d,e,f,g,h])]

        max_deg = 0
        total_terms = 0
        for word_idx in range(2):  # first 2 hash words
            for bit_idx in range(BITS):
                tt = []
                for x in range(n_total):
                    w0 = x & MASK
                    w1 = (x >> BITS) & MASK
                    h = sha_with_k(w0, w1, fixed_W)
                    tt.append((h[word_idx] >> bit_idx) & 1)
                monomials = compute_anf(tt, n_input)
                deg = max((bin(m).count('1') for m in monomials), default=0)
                max_deg = max(max_deg, deg)
                total_terms += len(monomials)

        print(f"  {k_name:<12s}: max degree={max_deg}, total terms={total_terms}")

    # ═══════════════════════════════════════════════════════════
    print(f"\n{'═' * 72}")
    print(f"  WHAT THE MAP TELLS US")
    print(f"{'═' * 72}")
    print(f"""
  If XOR-only has LOWER degree than Full:
    → The carries ADD algebraic complexity
    → The "real" function is simpler than it appears
    → Stripping carries reveals the underlying structure

  If XOR-only and Full have SAME degree:
    → The carries don't add complexity
    → The structure is in Ch/Maj, not in the arithmetic

  If output bits SHARE monomials:
    → The polynomial system has common factors
    → Common factors = factorable
    → Factorable = solvable without brute force

  If Real K has FEWER terms than Random K:
    → The specific K values create algebraic cancellations
    → Those cancellations are the trapdoor
    → The "formula" is: exploit the cancellations
""")


if __name__ == "__main__":
    main()
