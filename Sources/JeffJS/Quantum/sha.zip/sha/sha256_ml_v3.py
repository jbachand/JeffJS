#!/usr/bin/env python3
"""
SHA-256 ML v3 — Clean experiment.

Proven: SHA-256-8 IS a GF(2) polynomial. 256/256 exact.
Question: Can we LEARN it from partial data (generalize)?

If the model trains on 80% and predicts the other 20% exactly,
it has learned the FUNCTION, not memorized a table.
"""

import numpy as np
import itertools

def make_mini_sha256(BITS):
    MASK = (1 << BITS) - 1
    def rotr(x, n):
        n = n % BITS
        return ((x >> n) | (x << (BITS - n))) & MASK
    def shr(x, n): return (x >> min(n, BITS)) & MASK
    def Sigma1(x):
        r = [max(1, r_*BITS//32) for r_ in [6, 11, 25]]
        return rotr(x, r[0]) ^ rotr(x, r[1]) ^ rotr(x, r[2])
    def Sigma0(x):
        r = [max(1, r_*BITS//32) for r_ in [2, 13, 22]]
        return rotr(x, r[0]) ^ rotr(x, r[1]) ^ rotr(x, r[2])
    def sigma1(x):
        return rotr(x, max(1,17*BITS//32)) ^ rotr(x, max(1,19*BITS//32)) ^ shr(x, max(1,10*BITS//32))
    def sigma0(x):
        return rotr(x, max(1,7*BITS//32)) ^ rotr(x, max(1,18*BITS//32)) ^ shr(x, max(1,3*BITS//32))
    def Ch(e, f, g): return (e & f) ^ ((~e) & g) & MASK
    def Maj(a, b, c): return (a & b) ^ (a & c) ^ (b & c)

    K32 = [0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
           0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
           0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
           0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
           0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
           0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
           0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
           0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2]
    IV32 = [0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19]
    K_v = [k >> (32-BITS) for k in K32]
    IV_v = [v >> (32-BITS) for v in IV32]

    def compress(msg_words):
        W = list(msg_words) + [0]*48
        for t in range(16, 64):
            W[t] = (sigma1(W[t-2]) + W[t-7] + sigma0(W[t-15]) + W[t-16]) & MASK
        a,b,c,d,e,f,g,h = IV_v
        for t in range(64):
            T1 = (h + Sigma1(e) + Ch(e,f,g) + K_v[t] + W[t]) & MASK
            T2 = (Sigma0(a) + Maj(a,b,c)) & MASK
            h=g;g=f;f=e;e=(d+T1)&MASK;d=c;c=b;b=a;a=(T1+T2)&MASK
        return tuple((s+iv)&MASK for s,iv in zip([a,b,c,d,e,f,g,h], IV_v))
    return compress, BITS, MASK

def int_to_bits(val, n): return np.array([(val>>i)&1 for i in range(n)], dtype=np.uint8)

def gf2_solve(A, b):
    m, n = A.shape
    M = np.hstack([A%2, (b%2).reshape(-1,1)]).astype(np.uint8)
    pivot_row = 0
    pivot_cols = []
    for col in range(n):
        found = False
        for row in range(pivot_row, m):
            if M[row, col] == 1:
                M[[pivot_row, row]] = M[[row, pivot_row]]
                found = True; break
        if not found: continue
        pivot_cols.append(col)
        for row in range(m):
            if row != pivot_row and M[row, col] == 1:
                M[row] ^= M[pivot_row]
        pivot_row += 1
    for row in range(pivot_row, m):
        if M[row, n] == 1: return None
    x = np.zeros(n, dtype=np.uint8)
    for i, col in enumerate(pivot_cols):
        x[col] = M[i, n]
    return x

def build_features(X_bin, max_deg):
    n, nb = X_bin.shape
    monos = []
    for d in range(max_deg+1):
        for c in itertools.combinations(range(nb), d):
            monos.append(c)
    F = np.ones((n, len(monos)), dtype=np.uint8)
    for j, m in enumerate(monos):
        for bi in m: F[:,j] &= X_bin[:,bi]
    return F, monos

# ============================================================

def run_experiments():
    for BITS in [4, 6, 8]:
        compress, _, MASK = make_mini_sha256(BITS)
        N = 1 << BITS
        in_bits = BITS
        out_bits = BITS * 8

        print(f"\n{'='*60}")
        print(f"SHA-256-{BITS}: {N} inputs, {in_bits}→{out_bits} bits")
        print(f"{'='*60}")

        X_bin = np.zeros((N, in_bits), dtype=np.uint8)
        Y_bin = np.zeros((N, out_bits), dtype=np.uint8)
        for i in range(N):
            X_bin[i] = int_to_bits(i, in_bits)
            h = compress([i]+[0]*15)
            for w in range(8):
                for b in range(BITS):
                    Y_bin[i, w*BITS+b] = (h[w]>>b)&1

        # ============ FULL FIT ============
        F_full, monos_full = build_features(X_bin, in_bits)
        n_solved = 0
        all_coeffs = []
        for ob in range(out_bits):
            c = gf2_solve(F_full, Y_bin[:, ob])
            all_coeffs.append(c)
            if c is not None:
                if np.array_equal((F_full @ c)%2, Y_bin[:, ob]):
                    n_solved += 1
        print(f"\nFull fit (all {N} samples, {len(monos_full)} monomials): {n_solved}/{out_bits} bits perfect")

        if n_solved == out_bits:
            # Verify as a formula
            n_correct = 0
            for v in range(N):
                xb = int_to_bits(v, in_bits)
                mv = np.ones(len(monos_full), dtype=np.uint8)
                for j, m in enumerate(monos_full):
                    for bi in m: mv[j] &= xb[bi]
                hbits = np.array([(mv @ all_coeffs[ob])%2 for ob in range(out_bits)])
                hw = []
                for w in range(8):
                    val = 0
                    for b in range(BITS): val |= int(hbits[w*BITS+b]) << b
                    hw.append(val)
                if tuple(hw) == compress([v]+[0]*15):
                    n_correct += 1
            print(f"Formula verification: {n_correct}/{N} ✓")

            total_terms = sum(int(np.sum(c)) for c in all_coeffs if c is not None)
            print(f"Total polynomial terms: {total_terms} (avg {total_terms/out_bits:.0f}/bit)")

        # ============ GENERALIZATION ============
        print(f"\nGeneralization (train on subset, test on rest):")
        np.random.seed(42)
        perm = np.random.permutation(N)

        for max_deg in range(1, in_bits+1):
            F, monos = build_features(X_bin, max_deg)
            n_mono = len(monos)

            for train_frac in [0.5, 0.8, 0.9]:
                n_train = max(n_mono, int(train_frac * N))  # need at least n_mono
                if n_train >= N: continue  # no test data

                ti = perm[:n_train]
                vi = perm[n_train:]
                if len(vi) == 0: continue

                Ft, Fv = F[ti], F[vi]
                Yt, Yv = Y_bin[ti], Y_bin[vi]

                solved = 0
                failed = 0
                bits_ok = 0
                exact = np.ones(len(vi), dtype=bool)

                for ob in range(out_bits):
                    c = gf2_solve(Ft, Yt[:, ob])
                    if c is not None:
                        solved += 1
                        p = (Fv @ c) % 2
                        bits_ok += (p == Yv[:, ob]).sum()
                        exact &= (p == Yv[:, ob])
                    else:
                        failed += 1
                        exact[:] = False  # FIX: mark as failed

                if solved == 0:
                    continue

                bit_acc = bits_ok / (len(vi) * solved) if solved > 0 else 0
                exact_acc = exact.mean()
                n_exact = int(exact_acc * len(vi))
                tag = " ✓ GENERALIZES!" if exact_acc == 1.0 else ""
                if solved < out_bits:
                    tag += f" ({failed} bits unsolvable)"
                print(f"  deg≤{max_deg:2d} ({n_mono:4d} mono) train={n_train:4d}/{N} "
                      f"test={len(vi):3d} | solved={solved}/{out_bits} "
                      f"bit={bit_acc:.4f} exact={n_exact}/{len(vi)}{tag}")

    # ============ NEURAL NET COMPARISON ============
    print(f"\n{'='*60}")
    print(f"NEURAL NETWORK COMPARISON (SHA-256-8)")
    print(f"{'='*60}")

    BITS = 8
    compress, _, MASK = make_mini_sha256(BITS)
    N = 256

    X_int = np.arange(N)
    Y_int = np.zeros((N, 8), dtype=np.int64)
    for i in range(N):
        Y_int[i] = compress([i]+[0]*15)

    # One-hot input (256-dim) — essentially a lookup table
    X_onehot = np.eye(N, dtype=np.float32)
    Y_norm = Y_int.astype(np.float32) / MASK

    np.random.seed(42)
    perm = np.random.permutation(N)
    n_train = 204
    ti, vi = perm[:n_train], perm[n_train:]

    # Simple linear regression: Y = X @ W + b
    # With one-hot input, this IS a lookup table.
    # Can't generalize.

    # Binary input → binary output with XOR network
    X_bin = np.zeros((N, 8), dtype=np.float32)
    Y_bin = np.zeros((N, 64), dtype=np.float32)
    for i in range(N):
        for b in range(8): X_bin[i,b] = (i>>b)&1
        h = compress([i]+[0]*15)
        for w in range(8):
            for b in range(BITS):
                Y_bin[i, w*8+b] = (h[w]>>b)&1

    # Train simple 2-layer net with numpy
    h_size = 512
    W1 = np.random.randn(8, h_size).astype(np.float32) * 0.5
    b1 = np.zeros(h_size, dtype=np.float32)
    W2 = np.random.randn(h_size, h_size).astype(np.float32) * 0.1
    b2 = np.zeros(h_size, dtype=np.float32)
    W3 = np.random.randn(h_size, 64).astype(np.float32) * 0.1
    b3 = np.zeros(64, dtype=np.float32)

    def sigmoid(x): return 1/(1+np.exp(-np.clip(x,-500,500)))
    def relu(x): return np.maximum(0, x)

    Xt, Xv = X_bin[ti], X_bin[vi]
    Yt, Yv = Y_bin[ti], Y_bin[vi]

    lr = 0.05
    best_exact = 0

    for epoch in range(20001):
        # Forward
        z1 = Xt @ W1 + b1; a1 = relu(z1)
        z2 = a1 @ W2 + b2; a2 = relu(z2)
        z3 = a2 @ W3 + b3; a3 = sigmoid(z3)

        # BCE loss
        eps = 1e-7
        loss = -np.mean(Yt*np.log(a3+eps) + (1-Yt)*np.log(1-a3+eps))

        # Backward
        dz3 = (a3 - Yt) / len(Xt)
        dW3 = a2.T @ dz3; db3 = dz3.sum(0)
        da2 = dz3 @ W3.T; dz2 = da2 * (z2 > 0); dW2 = a1.T @ dz2; db2 = dz2.sum(0)
        da1 = dz2 @ W2.T; dz1 = da1 * (z1 > 0); dW1 = Xt.T @ dz1; db1 = dz1.sum(0)

        W3 -= lr*dW3; b3 -= lr*db3
        W2 -= lr*dW2; b2 -= lr*db2
        W1 -= lr*dW1; b1 -= lr*db1

        if epoch % 2000 == 0 or epoch == 20000:
            # Test
            z1v = Xv@W1+b1; a1v = relu(z1v)
            z2v = a1v@W2+b2; a2v = relu(z2v)
            z3v = a2v@W3+b3; a3v = sigmoid(z3v)
            pred = (a3v > 0.5).astype(np.float32)
            bit_acc = (pred == Yv).mean()
            exact = (pred == Yv).all(axis=1).mean()
            best_exact = max(best_exact, exact)
            n_ex = int(exact * len(vi))
            print(f"  Epoch {epoch:5d}: loss={loss:.4f} bit={bit_acc:.4f} exact={n_ex}/{len(vi)}")

    print(f"\n  Best exact: {best_exact:.4f}")
    if best_exact < 1.0:
        print(f"  Neural net CANNOT perfectly generalize SHA-256-8")
        print(f"  (Not enough capacity or wrong architecture for degree-8 Boolean functions)")

    # ============ SUMMARY ============
    print(f"\n{'='*60}")
    print(f"SUMMARY")
    print(f"{'='*60}")
    print(f"✓ SHA-256 at 4, 6, 8 bits: EXACT polynomial formula exists")
    print(f"✓ Formula computes hash WITHOUT the 64-round compression loop")
    print(f"✓ Each output bit = XOR of AND-products of input bits")
    print(f"")
    print(f"Generalization (learning from partial data):")
    print(f"  The polynomial has degree = word_size (saturated)")
    print(f"  Needs ~all inputs to determine (degree = input dimension)")
    print(f"  BUT: at larger scales (16+ bits), degree saturates at ~16")
    print(f"  while inputs grow → polynomial becomes SPARSE relative to")
    print(f"  input space → generalization should improve at scale")

if __name__ == "__main__":
    run_experiments()
