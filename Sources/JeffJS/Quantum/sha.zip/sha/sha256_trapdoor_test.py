#!/usr/bin/env python3
"""
SHA-256 Trapdoor Hunt

If a trapdoor exists, it's in the constants. The K values (cube roots of
primes) and IV (square roots of primes) were chosen by the NSA.

Test: does SHA-256 with REAL K constants solve faster than with RANDOM K?
If yes, the constants carry structure the solver can exploit.

Also: decompose the round function into linear + correction terms and
measure how much of the output is explained by the linear part alone.
"""

import time
import random
from z3 import *

# ═══════════════════════════════════════════════════════════════
# Constants
# ═══════════════════════════════════════════════════════════════

K_REAL = [
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5,
    0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3,
    0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
    0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7,
    0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13,
    0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3,
    0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5,
    0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
    0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
]

IV = [
    0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
    0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19,
]

# ═══════════════════════════════════════════════════════════════
# Reference SHA-256 (parameterized by K)
# ═══════════════════════════════════════════════════════════════

def rotr32(x, n):
    return ((x >> n) | (x << (32 - n))) & 0xFFFFFFFF

def compress(msg, n_rounds, k_vals, iv=IV):
    W = list(msg)
    for t in range(16, 64):
        s0 = rotr32(W[t-15], 7) ^ rotr32(W[t-15], 18) ^ (W[t-15] >> 3)
        s1 = rotr32(W[t-2], 17) ^ rotr32(W[t-2], 19) ^ (W[t-2] >> 10)
        W.append((W[t-16] + s0 + W[t-7] + s1) & 0xFFFFFFFF)
    a, b, c, d, e, f, g, h = iv
    for t in range(n_rounds):
        S1 = rotr32(e, 6) ^ rotr32(e, 11) ^ rotr32(e, 25)
        ch = (e & f) ^ ((e ^ 0xFFFFFFFF) & g)
        T1 = (h + S1 + ch + k_vals[t] + W[t]) & 0xFFFFFFFF
        S0 = rotr32(a, 2) ^ rotr32(a, 13) ^ rotr32(a, 22)
        maj = (a & b) ^ (a & c) ^ (b & c)
        T2 = (S0 + maj) & 0xFFFFFFFF
        h = g; g = f; f = e
        e = (d + T1) & 0xFFFFFFFF
        d = c; c = b; b = a
        a = (T1 + T2) & 0xFFFFFFFF
    return [(iv[i] + v) & 0xFFFFFFFF for i, v in enumerate([a,b,c,d,e,f,g,h])]

# ═══════════════════════════════════════════════════════════════
# Z3 solver (parameterized by K)
# ═══════════════════════════════════════════════════════════════

def z3_invert(target, n_rounds, k_vals, timeout=60):
    s = SolverFor('QF_BV')
    s.set('timeout', timeout * 1000)
    W_vars = [BitVec(f'W{i}', 32) for i in range(16)]
    W = list(W_vars)
    for t in range(16, max(n_rounds, 16)):
        s0 = RotateRight(W[t-15], 7) ^ RotateRight(W[t-15], 18) ^ LShR(W[t-15], 3)
        s1 = RotateRight(W[t-2], 17) ^ RotateRight(W[t-2], 19) ^ LShR(W[t-2], 10)
        Wt = BitVec(f'Ws{t}', 32)
        s.add(Wt == W[t-16] + s0 + W[t-7] + s1)
        W.append(Wt)
    a, b, c, d = [BitVecVal(IV[i], 32) for i in range(4)]
    e, f, g, h = [BitVecVal(IV[i], 32) for i in range(4, 8)]
    for t in range(n_rounds):
        S1 = RotateRight(e, 6) ^ RotateRight(e, 11) ^ RotateRight(e, 25)
        ch = (e & f) ^ (~e & g)
        T1 = h + S1 + ch + BitVecVal(k_vals[t], 32) + W[t]
        S0 = RotateRight(a, 2) ^ RotateRight(a, 13) ^ RotateRight(a, 22)
        maj = (a & b) ^ (a & c) ^ (b & c)
        T2 = S0 + maj
        a_new = BitVec(f'a{t+1}', 32)
        e_new = BitVec(f'e{t+1}', 32)
        s.add(a_new == T1 + T2)
        s.add(e_new == d + T1)
        h = g; g = f; f = e; e = e_new
        d = c; c = b; b = a; a = a_new
    state = [a, b, c, d, e, f, g, h]
    for i in range(8):
        s.add(state[i] + BitVecVal(IV[i], 32) == BitVecVal(target[i], 32))
    start = time.time()
    result = s.check()
    elapsed = time.time() - start
    if result == sat:
        m = s.model()
        return 'SAT', [m[w].as_long() for w in W_vars], elapsed
    return str(result), None, elapsed

# ═══════════════════════════════════════════════════════════════
# EXPERIMENT 1: Real K vs Random K — solve time comparison
# ═══════════════════════════════════════════════════════════════

def test_k_constants():
    print("═" * 72)
    print("  TEST 1: Do the real K constants make SHA-256 easier to invert?")
    print("  If real K solves faster → the constants carry hidden structure")
    print("═" * 72)

    random.seed(42)
    msg = [random.getrandbits(32) for _ in range(16)]

    # Generate random K variants
    K_random1 = [random.getrandbits(32) for _ in range(64)]
    K_random2 = [random.getrandbits(32) for _ in range(64)]
    K_random3 = [random.getrandbits(32) for _ in range(64)]

    # K = all zeros
    K_zeros = [0] * 64

    # K = sequential
    K_seq = [i for i in range(64)]

    variants = [
        ("Real K (cube roots)", K_REAL),
        ("Random K #1",         K_random1),
        ("Random K #2",         K_random2),
        ("Random K #3",         K_random3),
        ("K = 0,0,0,...",       K_zeros),
        ("K = 0,1,2,...",       K_seq),
    ]

    for n_rounds in [16, 20, 24]:
        print(f"\n  --- {n_rounds} rounds ---")
        print(f"  {'Constants':<24s} │ {'Status':>8s} │ {'Time':>10s}")
        print(f"  {'─'*24}─┼─{'─'*8}─┼─{'─'*10}")

        for name, k_vals in variants:
            target = compress(msg, n_rounds, k_vals)
            status, _, elapsed = z3_invert(target, n_rounds, k_vals, timeout=30)
            if status == 'SAT':
                print(f"  {name:<24s} │ {'✓ SAT':>8s} │ {elapsed:>9.3f}s")
            elif 'unknown' in str(status):
                print(f"  {name:<24s} │ {'TIMEOUT':>8s} │ {elapsed:>9.1f}s")
            else:
                print(f"  {name:<24s} │ {status:>8s} │ {elapsed:>9.2f}s")

# ═══════════════════════════════════════════════════════════════
# EXPERIMENT 2: Linearity measurement
# How much of SHA-256 is explained by a linear approximation?
# ═══════════════════════════════════════════════════════════════

def test_linearity():
    print(f"\n{'═' * 72}")
    print("  TEST 2: How linear is SHA-256?")
    print("  Compare full hash vs 'linear-only' hash (Ch/Maj replaced with")
    print("  their linear components, carries ignored)")
    print("═" * 72)

    def compress_linear(msg, n_rounds, k_vals):
        """SHA-256 with only the linear parts of Ch and Maj.
        Ch(e,f,g) ≈ g (linear part, ignoring e·(f⊕g) correction)
        Maj(a,b,c) ≈ a⊕b⊕c (XOR, treating Maj as "approximately sum")
        Addition: XOR instead of mod-2^32 (no carries)
        """
        W = list(msg)
        for t in range(16, 64):
            s0 = rotr32(W[t-15], 7) ^ rotr32(W[t-15], 18) ^ (W[t-15] >> 3)
            s1 = rotr32(W[t-2], 17) ^ rotr32(W[t-2], 19) ^ (W[t-2] >> 10)
            W.append(W[t-16] ^ s0 ^ W[t-7] ^ s1)  # XOR instead of add

        a, b, c, d, e, f, g, h = IV
        for t in range(n_rounds):
            S1 = rotr32(e, 6) ^ rotr32(e, 11) ^ rotr32(e, 25)
            ch_linear = g  # Linear part of Ch only
            T1 = h ^ S1 ^ ch_linear ^ k_vals[t] ^ W[t]  # XOR
            S0 = rotr32(a, 2) ^ rotr32(a, 13) ^ rotr32(a, 22)
            maj_linear = a ^ b ^ c  # XOR approximation of Maj
            T2 = S0 ^ maj_linear
            h = g; g = f; f = e
            e = d ^ T1
            d = c; c = b; b = a
            a = T1 ^ T2
        return [IV[i] ^ v for i, v in enumerate([a,b,c,d,e,f,g,h])]

    random.seed(123)
    n_samples = 1000

    for n_rounds in [4, 8, 16, 32, 64]:
        total_bits = 0
        matching_bits = 0

        for _ in range(n_samples):
            msg = [random.getrandbits(32) for _ in range(16)]
            real = compress(msg, n_rounds, K_REAL)
            linear = compress_linear(msg, n_rounds, K_REAL)

            for i in range(8):
                xor = real[i] ^ linear[i]
                # Count matching bits
                diff_bits = bin(xor).count('1')
                matching_bits += (32 - diff_bits)
                total_bits += 32

        pct = matching_bits / total_bits * 100
        # Random would give 50% match
        bar_len = int(pct / 2)
        bar = '█' * bar_len + '░' * (50 - bar_len)
        marker = "← random baseline" if abs(pct - 50) < 2 else ""
        print(f"  {n_rounds:>3d} rounds: {pct:5.1f}% bits match linear  [{bar}] {marker}")

# ═══════════════════════════════════════════════════════════════
# EXPERIMENT 3: Nonlinear correction sparsity
# How often is the Ch correction term zero?
# ═══════════════════════════════════════════════════════════════

def test_correction_sparsity():
    print(f"\n{'═' * 72}")
    print("  TEST 3: Nonlinear correction sparsity")
    print("  Ch(e,f,g) = g ⊕ e·(f⊕g)")
    print("  The correction e·(f⊕g) is ZERO when f = g.")
    print("  How often does this happen during real SHA-256 execution?")
    print("═" * 72)

    random.seed(456)
    n_samples = 100

    for n_rounds in [16, 32, 64]:
        total_correction_bits = 0
        zero_correction_bits = 0
        total_ch_bits = 0
        total_maj_bits = 0
        zero_ch_bits = 0
        zero_maj_bits = 0

        for _ in range(n_samples):
            msg = [random.getrandbits(32) for _ in range(16)]
            W = list(msg)
            for t in range(16, 64):
                s0 = rotr32(W[t-15], 7) ^ rotr32(W[t-15], 18) ^ (W[t-15] >> 3)
                s1 = rotr32(W[t-2], 17) ^ rotr32(W[t-2], 19) ^ (W[t-2] >> 10)
                W.append((W[t-16] + s0 + W[t-7] + s1) & 0xFFFFFFFF)

            a, b, c, d, e, f, g, h = IV
            for t in range(n_rounds):
                # Ch correction: e · (f ⊕ g)
                ch_correction = e & (f ^ g)
                ch_zero = 32 - bin(ch_correction).count('1')
                zero_ch_bits += ch_zero
                total_ch_bits += 32

                # Maj correction: look at how many bit positions have a=b, a=c, or b=c
                # Maj(a,b,c) = a⊕b⊕c would be if all bits disagree
                # Actual Maj counts majority, so correction = Maj - (a⊕b⊕c)
                maj_actual = (a & b) ^ (a & c) ^ (b & c)
                maj_linear = a ^ b ^ c
                maj_correction = maj_actual ^ maj_linear
                maj_zero = 32 - bin(maj_correction).count('1')
                zero_maj_bits += maj_zero
                total_maj_bits += 32

                # Run the actual round
                S1 = rotr32(e, 6) ^ rotr32(e, 11) ^ rotr32(e, 25)
                ch = (e & f) ^ ((e ^ 0xFFFFFFFF) & g)
                T1 = (h + S1 + ch + K_REAL[t] + W[t]) & 0xFFFFFFFF
                S0 = rotr32(a, 2) ^ rotr32(a, 13) ^ rotr32(a, 22)
                maj = (a & b) ^ (a & c) ^ (b & c)
                T2 = (S0 + maj) & 0xFFFFFFFF
                h = g; g = f; f = e
                e = (d + T1) & 0xFFFFFFFF
                d = c; c = b; b = a
                a = (T1 + T2) & 0xFFFFFFFF

        ch_pct = zero_ch_bits / total_ch_bits * 100
        maj_pct = zero_maj_bits / total_maj_bits * 100
        print(f"\n  {n_rounds} rounds:")
        print(f"    Ch  correction zero: {ch_pct:.1f}% of bits  (expected ~50%)")
        print(f"    Maj correction zero: {maj_pct:.1f}% of bits  (expected ~50%)")

# ═══════════════════════════════════════════════════════════════
# EXPERIMENT 4: Recurrence form — express SHA-256 as two sequences
# ═══════════════════════════════════════════════════════════════

def test_recurrence():
    print(f"\n{'═' * 72}")
    print("  TEST 4: SHA-256 as two coupled recurrences")
    print("  The 8 state variables reduce to just A[t] and E[t].")
    print("  Verify: state = (A[t], A[t-1], A[t-2], A[t-3],")
    print("                   E[t], E[t-1], E[t-2], E[t-3])")
    print("═" * 72)

    random.seed(789)
    msg = [random.getrandbits(32) for _ in range(16)]

    W = list(msg)
    for t in range(16, 64):
        s0 = rotr32(W[t-15], 7) ^ rotr32(W[t-15], 18) ^ (W[t-15] >> 3)
        s1 = rotr32(W[t-2], 17) ^ rotr32(W[t-2], 19) ^ (W[t-2] >> 10)
        W.append((W[t-16] + s0 + W[t-7] + s1) & 0xFFFFFFFF)

    # Track A and E sequences
    A_seq = list(IV[:4])  # A[0]=IV[0], A[-1]=IV[1], A[-2]=IV[2], A[-3]=IV[3]
    E_seq = list(IV[4:])  # E[0]=IV[4], E[-1]=IV[5], E[-2]=IV[6], E[-3]=IV[7]

    # Also track full state for verification
    a, b, c, d, e, f, g, h = IV

    print(f"\n  Round │  A[t] from round  │  A[t] from state.a  │ Match")
    print(f"  ──────┼───────────────────┼─────────────────────┼──────")

    for t in range(64):
        S1 = rotr32(e, 6) ^ rotr32(e, 11) ^ rotr32(e, 25)
        ch = (e & f) ^ ((e ^ 0xFFFFFFFF) & g)
        T1 = (h + S1 + ch + K_REAL[t] + W[t]) & 0xFFFFFFFF
        S0 = rotr32(a, 2) ^ rotr32(a, 13) ^ rotr32(a, 22)
        maj = (a & b) ^ (a & c) ^ (b & c)
        T2 = (S0 + maj) & 0xFFFFFFFF
        h = g; g = f; f = e
        e = (d + T1) & 0xFFFFFFFF
        d = c; c = b; b = a
        a = (T1 + T2) & 0xFFFFFFFF

        A_seq.append(a)
        E_seq.append(e)

        # Verify the recurrence form
        # b should be A[t], c = A[t-1], d = A[t-2]
        # f should be E[t], g = E[t-1], h_old = E[t-2]
        idx = t + 1  # after round t, we have state t+1
        if t < 8 and idx >= 4:
            a_match = (a == A_seq[idx])
            b_match = (b == A_seq[idx - 1])
            e_match = (e == E_seq[idx])
            f_match = (f == E_seq[idx - 1])
            print(f"  {t:>5d} │ A[{idx}]=0x{A_seq[idx]:08x} │ "
                  f"a=0x{a:08x}       │ {'✓' if a_match else '✗'} "
                  f"b=A[{idx-1}]:{'✓' if b_match else '✗'} "
                  f"f=E[{idx-1}]:{'✓' if f_match else '✗'}")

    # Final verification
    final_state = (a, b, c, d, e, f, g, h)
    idx = 64
    checks = [
        a == A_seq[idx],
        b == A_seq[idx-1],
        c == A_seq[idx-2],
        d == A_seq[idx-3],
        e == E_seq[idx],
        f == E_seq[idx-1],
        g == E_seq[idx-2],
        h == E_seq[idx-3],
    ]
    print(f"\n  Final state verification (round 64):")
    labels = ['a=A[64]', 'b=A[63]', 'c=A[62]', 'd=A[61]',
              'e=E[64]', 'f=E[63]', 'g=E[62]', 'h=E[61]']
    for label, ok in zip(labels, checks):
        print(f"    {label}: {'✓' if ok else '✗'}")

    print(f"\n  ★ SHA-256 is fully described by sequences A[0..64] and E[0..64]")
    print(f"    with initial conditions A[-3..0] = IV[3..0], E[-3..0] = IV[7..4]")
    print(f"    Everything else is a shifted copy.")


# ═══════════════════════════════════════════════════════════════
# Main
# ═══════════════════════════════════════════════════════════════

if __name__ == "__main__":
    test_k_constants()
    test_linearity()
    test_correction_sparsity()
    test_recurrence()

    print(f"\n{'═' * 72}")
    print(f"  WHAT TO LOOK FOR")
    print(f"{'═' * 72}")
    print(f"""
  If the real K constants solve FASTER than random K:
    → The constants carry exploitable algebraic structure
    → That structure was put there by whoever chose those constants

  If the linear approximation stays correlated beyond ~8 rounds:
    → The nonlinear corrections are small/structured
    → A correction-based formula might work

  If the Ch/Maj corrections are zero more than 50% of the time:
    → The specific mixing pattern creates sparsity
    → Fewer nonlinear terms to solve

  The formula (if it exists) would be:
    Hash = Linear(Message) + Sparse_Correction(Message)
    where the correction is a low-degree polynomial whose
    specific structure depends on the K constants.
""")
