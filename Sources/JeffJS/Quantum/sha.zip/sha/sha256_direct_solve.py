#!/usr/bin/env python3
"""
SHA-256 Direct Algebraic Inversion

The polynomial IS the hash:  hash_j = Σ anf_j[m] · z_m
This is LINEAR in the z-variables. RHS = hash (known).
Solve: A · z = hash, where A is the ANF coefficient matrix.

For n input bits: 2^n monomial variables, 8*bits output equations.
If underdetermined → XL (multiply equations by variables).
Solution z must satisfy consistency: z_{a|b} = z_a AND z_b.

No iteration. No approximation. Direct linear algebra.
"""

import numpy as np
import random
import time
from math import comb

def make_sha(bits):
    mask = (1 << bits) - 1
    def rotr(x, n):
        n = n % bits; return ((x >> n) | (x << (bits - n))) & mask
    def ch(e, f, g): return ((e & f) ^ ((e ^ mask) & g)) & mask
    def maj(a, b, c): return ((a & b) ^ (a & c) ^ (b & c)) & mask
    r0 = [max(1, r * bits // 32) for r in [2, 13, 22]]
    r1 = [max(1, r * bits // 32) for r in [6, 11, 25]]
    def S0(a): return (rotr(a, r0[0]) ^ rotr(a, r0[1]) ^ rotr(a, r0[2])) & mask
    def S1(e): return (rotr(e, r1[0]) ^ rotr(e, r1[1]) ^ rotr(e, r1[2])) & mask
    sr0 = [max(1, r*bits//32) for r in [7,18]]; ss0 = max(1,3*bits//32)
    sr1 = [max(1, r*bits//32) for r in [17,19]]; ss1 = max(1,10*bits//32)
    def s0(x): return (rotr(x, sr0[0]) ^ rotr(x, sr0[1]) ^ (x >> ss0)) & mask
    def s1(x): return (rotr(x, sr1[0]) ^ rotr(x, sr1[1]) ^ (x >> ss1)) & mask
    K = [k & mask for k in [0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,
        0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,0xd807aa98,0x12835b01,
        0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174]]
    IV = [v & mask for v in [0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,
        0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19]]
    def compress(msg, nr=16):
        W = list(msg[:16])
        while len(W) < 16: W.append(0)
        for t in range(16, max(nr,16)):
            W.append((s1(W[t-2])+W[t-7]+s0(W[t-15])+W[t-16]) & mask)
        a,b,c,d,e,f,g,h = IV
        for t in range(nr):
            T1=(h+S1(e)+ch(e,f,g)+K[t%16]+W[t])&mask; T2=(S0(a)+maj(a,b,c))&mask
            h=g;g=f;f=e;e=(d+T1)&mask;d=c;c=b;b=a;a=(T1+T2)&mask
        return [(IV[i]+v)&mask for i,v in enumerate([a,b,c,d,e,f,g,h])]
    return compress, mask


def compute_anf(tt, nv):
    n = 1 << nv; a = list(tt)
    for i in range(nv):
        s = 1 << i
        for j in range(n):
            if j & s: a[j] ^= a[j ^ s]
    return a


def gf2_solve_full(A, b):
    """GF(2) solve with full solution extraction. Returns all solutions."""
    m, n = A.shape
    Ab = np.hstack([A.copy(), b.reshape(-1,1)]).astype(np.uint8)
    pivots = []
    for col in range(n):
        piv = None
        for row in range(len(pivots), m):
            if Ab[row, col]: piv = row; break
        if piv is None: continue
        tr = len(pivots)
        if piv != tr: Ab[[tr, piv]] = Ab[[piv, tr]]
        for row in range(m):
            if row != tr and Ab[row, col]: Ab[row] ^= Ab[tr]
        pivots.append((tr, col))
    # Check consistency
    for row in range(len(pivots), m):
        if Ab[row, -1]: return []  # inconsistent
    # Get particular solution
    x = np.zeros(n, dtype=np.uint8)
    pivot_cols = set()
    for r, c in pivots:
        x[c] = Ab[r, -1]
        pivot_cols.add(c)
    free_cols = [c for c in range(n) if c not in pivot_cols]
    return x, free_cols, Ab, pivots


def is_valid_assignment(z, n_input):
    """Check if monomial vector z is consistent: z_{a|b} = z_a AND z_b."""
    n = 1 << n_input
    for m in range(n):
        if bin(m).count('1') < 2: continue
        # Decompose m into its constituent single-bit factors
        bits_in_m = [i for i in range(n_input) if m & (1 << i)]
        expected = 1
        for b in bits_in_m:
            expected &= z[1 << b]
        if z[m] != expected:
            return False
    return True


def extract_input(z, n_input):
    """Extract input bits from monomial vector."""
    x = 0
    for i in range(n_input):
        if z[1 << i]:
            x |= (1 << i)
    return x


def solve_sha(bits, n_free, n_rounds, n_trials):
    sha, mask = make_sha(bits)
    n_input = n_free * bits
    n_space = 1 << n_input
    n_output = 8 * bits

    print(f"\n  {bits}-bit, {n_free} free, {n_input} input bits")

    successes = 0
    total_time = 0

    for trial in range(n_trials):
        random.seed(42 + trial)
        msg = [random.getrandbits(bits) & mask for _ in range(16)]
        target_hash = sha(msg, n_rounds)
        target_x = sum((msg[w] & mask) << (w * bits) for w in range(n_free))

        # Build ANF for this message
        all_anf = []
        for wi in range(8):
            for bi in range(bits):
                tt = []
                for x in range(n_space):
                    ws = [(x >> (w*bits)) & mask for w in range(n_free)]
                    m2 = ws + msg[n_free:]
                    h = sha(m2, n_rounds)
                    tt.append((h[wi] >> bi) & 1)
                all_anf.append(compute_anf(tt, n_input))

        # Hash target bits
        target_bits = []
        for wi in range(8):
            for bi in range(bits):
                target_bits.append((target_hash[wi] >> bi) & 1)

        # Build FULL linear system: A · z = hash
        # A[j, m] = anf_j[m], z[m] = monomial value, RHS = hash_j
        A = np.zeros((n_output, n_space), dtype=np.uint8)
        b = np.array(target_bits, dtype=np.uint8)

        for j in range(n_output):
            for m in range(n_space):
                A[j, m] = all_anf[j][m]

        # XL: multiply each equation by each variable
        xl_rows = [A]
        xl_rhs = [b]

        for var in range(n_input):
            var_mask = 1 << var
            A_mult = np.zeros((n_output, n_space), dtype=np.uint8)
            b_mult = np.zeros(n_output, dtype=np.uint8)

            for j in range(n_output):
                for m in range(n_space):
                    if all_anf[j][m]:
                        new_m = m | var_mask
                        if new_m < n_space:
                            A_mult[j, new_m] ^= 1
                # RHS: hash_j * z_{var_mask}
                # Move to LHS: ... - hash_j * z_{var_mask} = 0
                # → add hash_j to column var_mask
                if target_bits[j]:
                    A_mult[j, var_mask] ^= 1
                b_mult[j] = 0

            xl_rows.append(A_mult)
            xl_rhs.append(b_mult)

        A_full = np.vstack(xl_rows).astype(np.uint8)
        b_full = np.concatenate(xl_rhs).astype(np.uint8)

        t0 = time.time()
        result = gf2_solve_full(A_full, b_full)

        if not result:
            elapsed = time.time() - t0
            if trial < 3: print(f"    Trial {trial+1}: inconsistent system ({elapsed:.4f}s)")
            continue

        z_particular, free_cols, _, _ = result
        elapsed = time.time() - t0

        # Try the particular solution
        x_found = extract_input(z_particular, n_input)
        ws = [(x_found >> (w*bits)) & mask for w in range(n_free)]
        m2 = ws + msg[n_free:]
        correct = sha(m2, n_rounds) == target_hash

        if correct:
            successes += 1
            total_time += elapsed
            if trial < 5:
                print(f"    Trial {trial+1}: x={x_found} ✓ ({elapsed:.4f}s, {len(free_cols)} free vars)")
            continue

        # Particular solution didn't work — search free variables
        n_free_vars = len(free_cols)
        if n_free_vars > 20:
            if trial < 3:
                print(f"    Trial {trial+1}: {n_free_vars} free vars — too many to enumerate")
            continue

        found = False
        for bits_val in range(1 << n_free_vars):
            z_try = z_particular.copy()
            for idx, col in enumerate(free_cols):
                z_try[col] = (bits_val >> idx) & 1
            # Verify Ax = b
            if not np.array_equal((A_full @ z_try) % 2, b_full):
                continue
            # Check monomial consistency
            if not is_valid_assignment(z_try, n_input):
                continue
            x_found = extract_input(z_try, n_input)
            ws = [(x_found >> (w*bits)) & mask for w in range(n_free)]
            m2 = ws + msg[n_free:]
            if sha(m2, n_rounds) == target_hash:
                found = True
                successes += 1
                total_time += time.time() - t0
                if trial < 5:
                    print(f"    Trial {trial+1}: x={x_found} ✓ (searched {bits_val+1}/{1<<n_free_vars} "
                          f"free combos, {time.time()-t0:.4f}s)")
                break

        if not found and trial < 3:
            print(f"    Trial {trial+1}: not found in {1<<n_free_vars} free combos ✗")

    avg_t = total_time / max(successes, 1)
    print(f"\n  Result: {successes}/{n_trials} solved")
    print(f"  Avg solve time: {avg_t:.4f}s")
    return successes, n_trials


def main():
    print("═" * 72)
    print("  SHA-256 Direct Algebraic Inversion")
    print("  hash_j = Σ anf_j[m] · z_m  →  solve A·z = hash over GF(2)")
    print("═" * 72)

    results = []

    for bits in [4, 5, 6, 7, 8]:
        s, t = solve_sha(bits, 1, 16, 20)
        results.append((bits, 1, s, t))

    for bits in [4, 5]:
        s, t = solve_sha(bits, 2, 16, 20)
        results.append((bits, 2, s, t))

    print(f"\n{'═' * 72}")
    print(f"  RESULTS")
    print(f"{'═' * 72}")
    print(f"\n  {'Bits':>4s} │ {'Free':>4s} │ {'Input':>5s} │ {'Solved':>10s} │ Status")
    print(f"  {'─'*4}─┼─{'─'*4}─┼─{'─'*5}─┼─{'─'*10}─┼─{'─'*20}")
    for bits, free, s, t in results:
        ni = free * bits
        status = "★ INVERTED" if s == t else f"{s}/{t}"
        print(f"  {bits:>4d} │ {free:>4d} │ {ni:>5d} │ {s:>4d}/{t:<5d} │ {status}")

if __name__ == "__main__":
    main()
